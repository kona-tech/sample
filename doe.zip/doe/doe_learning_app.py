# -*- coding: utf-8 -*-
import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from itertools import combinations, product
import warnings

# 警告を非表示
warnings.filterwarnings('ignore')

# matplotlib の日本語フォント設定
plt.rcParams['font.family'] = ['DejaVu Sans', 'Hiragino Sans', 'Yu Gothic', 'Meiryo', 'Takao', 'IPAexGothic', 'IPAPGothic', 'VL PGothic', 'Noto Sans CJK JP']
plt.rcParams['axes.unicode_minus'] = False

# Streamlitページ設定
st.set_page_config(
    page_title="実験計画法学習サイト",
    page_icon="🧪",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 日本語表示の確保
import locale
try:
    locale.setlocale(locale.LC_ALL, 'ja_JP.UTF-8')
except:
    pass

# ========================================
# 共通課題設定と数式定義
# ========================================

class ChemicalProcessModel:
    """化学反応プロセスの共通モデル"""
    
    def __init__(self):
        # 制御因子の範囲
        self.temp_range = (80, 120)      # 温度 °C
        self.time_range = (30, 90)       # 時間 分
        self.catalyst_range = (0.1, 0.5) # 触媒濃度 mol/L
        self.ph_range = (6.0, 8.0)       # pH
        
        # 基準値（中央値）
        self.temp_center = 100
        self.time_center = 60
        self.catalyst_center = 0.3
        self.ph_center = 7.0
        
        # モデルパラメータ
        self.yield_params = {
            'intercept': 78,  # 最適条件での最大収率を高めに設定
            'temp_coef': 0.0,  # 1次項を0にして純粋な2次関数にする
            'temp_center': 105,
            'temp_quad': -0.008,  # 2次項の係数を大きくしてより明確な凸性を表現
            'time_coef': 0.0,  # 1次項を0にして純粋な2次関数にする
            'time_quad': -0.005,  # 2次項の係数を大きくしてより明確な凸性を表現
            'catalyst_coef': 0.0,  # 1次項を0にして純粋な2次関数にする
            'catalyst_quad': -200,  # 触媒効果をさらに強調して明確な凸性を表現
            'ph_coef': 2,  # pHは1次効果のまま維持
            'interaction_temp_time': 0.02,  # 交互作用を少し強めに
            'interaction_temp_catalyst': -15,  # 負の交互作用を強めに
            'error_std': 2.0
        }
        
        self.purity_params = {
            'intercept': 90,
            'temp_coef': 0.15,
            'temp_quad': -0.001,
            'time_coef': 0.08,
            'time_quad': -0.0005,
            'catalyst_coef': 8,
            'catalyst_quad': -5,
            'ph_coef': 1.5,
            'interaction_temp_time': 0.005,
            'error_std': 1.0
        }
    
    def yield_function(self, temp, time=None, catalyst=None, ph=None, noise=0):
        """収率計算の共通関数"""
        if time is None:
            time = self.time_center
        if catalyst is None:
            catalyst = self.catalyst_center
        if ph is None:
            ph = self.ph_center
        
        p = self.yield_params
        
        yield_val = (p['intercept'] +
                    p['temp_coef'] * temp +
                    p['temp_quad'] * (temp - p['temp_center'])**2 +
                    p['time_coef'] * time +
                    p['time_quad'] * (time - self.time_center)**2 +
                    p['catalyst_coef'] * catalyst +
                    p['catalyst_quad'] * (catalyst - self.catalyst_center)**2 +
                    p['ph_coef'] * (ph - self.ph_center) +
                    p['interaction_temp_time'] * (temp - self.temp_center) * (time - self.time_center) +
                    p['interaction_temp_catalyst'] * (temp - self.temp_center) * (catalyst - self.catalyst_center) +
                    noise)
        
        return max(yield_val, 0)
    
    def purity_function(self, temp, time=None, catalyst=None, ph=None, noise=0):
        """純度計算の共通関数"""
        if time is None:
            time = self.time_center
        if catalyst is None:
            catalyst = self.catalyst_center
        if ph is None:
            ph = self.ph_center
            
        p = self.purity_params
        
        purity_val = (p['intercept'] +
                     p['temp_coef'] * temp +
                     p['temp_quad'] * (temp - self.temp_center)**2 +
                     p['time_coef'] * time +
                     p['time_quad'] * (time - self.time_center)**2 +
                     p['catalyst_coef'] * catalyst +
                     p['catalyst_quad'] * (catalyst - self.catalyst_center)**2 +
                     p['ph_coef'] * (ph - self.ph_center) +
                     p['interaction_temp_time'] * (temp - self.temp_center) * (time - self.time_center) +
                     noise)
        
        return min(max(purity_val, 85), 100)
    
    def add_noise_effect(self, base_value, noise_conditions):
        """ノイズ因子の効果を追加"""
        # 原料純度の影響 (98-100%)
        purity_factor = noise_conditions.get('purity_factor', 1.0)
        
        # 環境温度の影響 (20-30°C)
        env_temp_factor = noise_conditions.get('env_temp_factor', 1.0)
        
        # 装置劣化の影響
        degradation_factor = noise_conditions.get('degradation_factor', 1.0)
        
        return base_value * purity_factor * env_temp_factor * degradation_factor

# グローバルインスタンス
PROCESS_MODEL = ChemicalProcessModel()

# カスタムCSS
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .section-header {
        font-size: 2rem;
        color: #ff7f0e;
        margin-bottom: 1rem;
    }
    .info-box {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 10px;
        margin: 1rem 0;
    }
    .highlight {
        background-color: #fffacd;
        padding: 0.5rem;
        border-radius: 5px;
    }
</style>
""", unsafe_allow_html=True)

# サイドバーでページ選択
st.sidebar.title("📋 メニュー")
page = st.sidebar.selectbox(
    "学習したい内容を選択してください",
    [
        "🏠 ホーム",
        "📚 実験計画法の基本",
        "🔬 一因子実験",
        "⚗️ 多因子実験（2^k実験）",
        "📊 分散分析（ANOVA）",
        "📈 応答曲面法",
        "🎯 パラメータ設計（タグチメソッド）",
        "🛡️ ロバスト最適化",
        "📝 共通課題",
        "📖 課題説明"
    ]
)

def main():
    if page == "🏠 ホーム":
        show_home()
    elif page == "📚 実験計画法の基本":
        show_basics()
    elif page == "🔬 一因子実験":
        show_one_factor()
    elif page == "⚗️ 多因子実験（2^k実験）":
        show_factorial()
    elif page == "📊 分散分析（ANOVA）":
        show_anova()
    elif page == "📈 応答曲面法":
        show_response_surface()
    elif page == "🎯 パラメータ設計（タグチメソッド）":
        show_taguchi()
    elif page == "🛡️ ロバスト最適化":
        show_robust_optimization()
    elif page == "📝 共通課題":
        show_common_exercises()
    elif page == "📖 課題説明":
        show_exercise_explanation()

def show_home():
    st.markdown('<h1 class="main-header">🧪 実験計画法学習サイト</h1>', unsafe_allow_html=True)
    
    st.markdown("""
    <div class="info-box">
        <h3>🎯 このサイトについて</h3>
        <p>実験計画法（Design of Experiments, DOE）を対話的に学習できるウェブアプリケーションです。
        理論的な説明とシミュレーション機能を組み合わせて、実践的な理解を深めることができます。</p>
    </div>
    """, unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        ### 📚 学習内容
        - 実験計画法の基本概念
        - 一因子実験の設計と分析
        - 多因子実験（2^k実験）
        - 分散分析（ANOVA）
        - 応答曲面法
        """)
    
    with col2:
        st.markdown("""
        ### 🔧 機能
        - 対話的なシミュレーション
        - リアルタイムグラフ表示
        - パラメータ調整機能
        - 統計的解析結果の表示
        - データのダウンロード機能
        """)
    
    with col3:
        st.markdown("""
        ### 🎓 学習効果
        - 理論と実践の結合
        - 視覚的理解の促進
        - パラメータ変化の影響確認
        - 統計的解釈力の向上
        - 実務への応用準備
        """)
    
    st.markdown("---")
    
    # 共通プロセスモデルの説明
    st.markdown("## 🏭 共通課題：化学反応プロセス最適化")
    st.markdown("""
    <div class="info-box">
    すべての学習モジュールで、統一された化学反応プロセス最適化問題を扱います。
    これにより、異なる実験計画手法が同じエンジニアリング問題にどう適用されるかを理解できます。
    </div>
    """, unsafe_allow_html=True)
    
    # 数式の詳細説明
    with st.expander("🧮 共通プロセスモデルの数式と特性（詳細）"):
        st.markdown("""
        ### 📐 収率計算式（完全版）
        
        ```
        収率(%) = 78 + (-0.008)×(T-105)² + (-0.005)×(t-60)²
                + (-200)×(C-0.3)² + 2×(pH-7)
                + 0.02×(T-105)×(t-60) + (-15)×(T-105)×(C-0.3) + ε
        ```
        
        **各項の説明：**
        - **基準収率：** 78% （すべての因子が最適値の時のベース収率）
        - **温度効果：** -0.008×(T-105)² （105°Cで最大となる上に凸の2次関数）
        - **時間効果：** -0.005×(t-60)² （60分で最大となる上に凸の2次関数）
        - **触媒効果：** -200×(C-0.3)² （0.3mol/Lで最大となる上に凸の2次関数）
        - **pH効果：** 2×(pH-7) （7.0を基準とした1次関数）
        - **温度×時間交互作用：** 0.02×(T-105)×(t-60)
        - **温度×触媒交互作用：** -15×(T-105)×(C-0.3)
        - **実験誤差：** ε ~ N(0, 2²)
        """)
        
        st.markdown("""
        ### 📊 関数の特性と極値
        
        **🎯 理論最適条件：**
        - **温度：** 105°C （2次項の係数が負なので上に凸、最大値を持つ）
        - **時間：** 60分 （2次項の係数が負なので上に凸、最大値を持つ）
        - **触媒濃度：** 0.3 mol/L （2次項の係数が負なので上に凸、最大値を持つ）
        - **pH：** 7.5 （1次項の係数が正なので高い方が良い）
        
        **📈 各因子の感度：**
        1. **触媒濃度** → 最も影響大（最大効果 ±50%）
        2. **温度** → 2番目に影響大（最大効果 ±8%）
        3. **時間** → 3番目に影響（最大効果 ±5%）
        4. **pH** → 最も影響小（最大効果 ±1%）
        
        **🔄 交互作用効果：**
        - **温度×時間：** 正の交互作用（両方高いとさらに収率向上）
        - **温度×触媒：** 負の交互作用（高温時は触媒濃度を下げる方が良い）
        
        **📐 数学的性質：**
        - **関数型：** 多変数2次関数（上に凸関数）
        - **大域最適解：** 1つのみ存在（最大値）
        - **局所最適解：** なし（上に凸関数のため）
        - **実験領域内での最大収率：** 約78%（理論最大値、ノイズにより±4%変動）
        """)
        
        st.markdown("""
        ### 🔬 実験設計上の特徴
        
        **👥 因子の役割分担：**
        - **主効果因子：** 温度、時間、触媒濃度（大きな効果を持つ）
        - **調整因子：** pH（小さいが安定した効果）
        - **交互作用因子：** 温度×時間、温度×触媒（因子間の相互作用）
        
        **🎲 実験誤差の設定：**
        - **分布：** 正規分布 N(0, 2²)
        - **変動係数：** 約3-4%（現実的な実験誤差レベル）
        - **再現性：** 同条件での実験でも±4%程度のばらつき
        
        **🏭 工業的現実性：**
        - 化学反応プロセスの典型的な特性を反映
        - 温度・時間・触媒の最適条件が存在
        - 実際の製造プロセスで観察される交互作用を模擬
        - 現実的な実験誤差レベルを設定
        """)
    
    # グラフによる視覚的説明
    st.markdown("## 📊 共通プロセスモデルの視覚的理解")
    
    # 各因子の効果をグラフで表示
    tab1, tab2, tab3, tab4 = st.tabs(["🌡️ 温度効果", "⏰ 時間効果", "⚗️ 触媒効果", "🔄 交互作用効果"])
    
    with tab1:
        st.markdown("### 温度と収率の関係（他因子を最適値で固定）")
        
        # 温度範囲のデータ生成
        temp_range = np.linspace(90, 120, 100)
        time_opt = 60  # 最適時間
        catalyst_opt = 0.3  # 最適触媒濃度
        ph_opt = 7.0  # 最適pH
        
        yields_temp = []
        for temp in temp_range:
            yield_val = PROCESS_MODEL.yield_function(temp, time_opt, catalyst_opt, ph_opt, 0)  # ノイズなし
            yields_temp.append(yield_val)
        
        # 理論最適値での収率を計算
        theoretical_max_yield = PROCESS_MODEL.yield_function(105, time_opt, catalyst_opt, ph_opt, 0)
        
        fig_temp = plt.figure(figsize=(10, 6))
        plt.plot(temp_range, yields_temp, 'b-', linewidth=2, label='収率')
        plt.axvline(x=105, color='r', linestyle='--', alpha=0.7, label='理論最適温度 (105°C)')
        plt.axhline(y=theoretical_max_yield, color='r', linestyle=':', alpha=0.5, label=f'理論最大収率 ({theoretical_max_yield:.1f}%)')
        plt.xlabel('温度 (°C)')
        plt.ylabel('収率 (%)')
        plt.title('温度効果：2次関数（上に凸）で105°Cに最大値')
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        st.pyplot(fig_temp)
        plt.close()
        
        st.markdown("""
        **📈 観察ポイント：**
        - 105°Cで明確な最大値を持つ上に凸の2次関数
        - 最適温度から離れると収率が急激に低下
        - 実験範囲（95-115°C）内では単峰性
        """)
    
    with tab2:
        st.markdown("### 時間と収率の関係（他因子を最適値で固定）")
        
        # 時間範囲のデータ生成
        time_range = np.linspace(30, 90, 100)
        temp_opt = 105  # 最適温度
        
        yields_time = []
        for time_val in time_range:
            yield_val = PROCESS_MODEL.yield_function(temp_opt, time_val, catalyst_opt, ph_opt, 0)
            yields_time.append(yield_val)
        
        # 理論最適値での収率を計算
        theoretical_max_yield_time = PROCESS_MODEL.yield_function(temp_opt, 60, catalyst_opt, ph_opt, 0)
        
        fig_time = plt.figure(figsize=(10, 6))
        plt.plot(time_range, yields_time, 'g-', linewidth=2, label='収率')
        plt.axvline(x=60, color='r', linestyle='--', alpha=0.7, label='理論最適時間 (60分)')
        plt.axhline(y=theoretical_max_yield_time, color='r', linestyle=':', alpha=0.5, label=f'理論最大収率 ({theoretical_max_yield_time:.1f}%)')
        plt.xlabel('時間 (分)')
        plt.ylabel('収率 (%)')
        plt.title('時間効果：2次関数（上に凸）で60分に最大値')
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        st.pyplot(fig_time)
        plt.close()
        
        st.markdown("""
        **📈 観察ポイント：**
        - 60分で最大値を持つ上に凸の2次関数
        - 時間が短すぎても長すぎても収率低下
        - 温度効果より緩やかな変化
        """)
    
    with tab3:
        st.markdown("### 触媒濃度と収率の関係（他因子を最適値で固定）")
        
        # 触媒濃度範囲のデータ生成（最適値周辺を重点的に）
        catalyst_range = np.linspace(0.15, 0.45, 100)
        
        yields_catalyst = []
        for catalyst_val in catalyst_range:
            yield_val = PROCESS_MODEL.yield_function(temp_opt, time_opt, catalyst_val, ph_opt, 0)
            yields_catalyst.append(yield_val)
        
        # 理論最適値での収率を計算
        theoretical_max_yield_catalyst = PROCESS_MODEL.yield_function(temp_opt, time_opt, 0.3, ph_opt, 0)
        
        fig_catalyst = plt.figure(figsize=(10, 6))
        plt.plot(catalyst_range, yields_catalyst, 'm-', linewidth=2, label='収率')
        plt.axvline(x=0.3, color='r', linestyle='--', alpha=0.7, label='理論最適濃度 (0.3 mol/L)')
        plt.axhline(y=theoretical_max_yield_catalyst, color='r', linestyle=':', alpha=0.5, label=f'理論最大収率 ({theoretical_max_yield_catalyst:.1f}%)')
        plt.xlabel('触媒濃度 (mol/L)')
        plt.ylabel('収率 (%)')
        plt.title('触媒効果：2次関数（上に凸）で0.3 mol/Lに最大値')
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        st.pyplot(fig_catalyst)
        plt.close()
        
        st.markdown("""
        **📈 観察ポイント：**
        - 最も急峻な変化を示す（感度最大）
        - 0.3 mol/Lで明確な最大値を持つ上に凸の2次関数
        - 濃度過多では触媒阻害効果で収率低下
        """)
    
    with tab4:
        st.markdown("### 交互作用効果の3D可視化")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### 温度×時間の交互作用（正の交互作用）")
            
            # 3Dプロット用のデータ生成
            temp_3d = np.linspace(95, 115, 20)
            time_3d = np.linspace(45, 75, 20)
            temp_mesh, time_mesh = np.meshgrid(temp_3d, time_3d)
            
            yield_mesh = np.zeros_like(temp_mesh)
            for i in range(len(temp_3d)):
                for j in range(len(time_3d)):
                    yield_mesh[j, i] = PROCESS_MODEL.yield_function(temp_mesh[j, i], time_mesh[j, i], catalyst_opt, ph_opt, 0)
            
            fig_3d1 = plt.figure(figsize=(10, 8))
            ax1 = fig_3d1.add_subplot(111, projection='3d')
            surf1 = ax1.plot_surface(temp_mesh, time_mesh, yield_mesh, cmap='viridis', alpha=0.8)
            ax1.set_xlabel('温度 (°C)')
            ax1.set_ylabel('時間 (分)')
            ax1.set_zlabel('収率 (%)')
            ax1.set_title('温度×時間の正の交互作用\n（両方高いと相乗効果）')
            fig_3d1.colorbar(surf1)
            st.pyplot(fig_3d1)
            plt.close()
        
        with col2:
            st.markdown("#### 温度×触媒の交互作用（負の交互作用）")
            
            # 温度×触媒の3Dプロット
            catalyst_3d = np.linspace(0.2, 0.4, 20)
            temp_mesh2, catalyst_mesh = np.meshgrid(temp_3d, catalyst_3d)
            
            yield_mesh2 = np.zeros_like(temp_mesh2)
            for i in range(len(temp_3d)):
                for j in range(len(catalyst_3d)):
                    yield_mesh2[j, i] = PROCESS_MODEL.yield_function(temp_mesh2[j, i], time_opt, catalyst_mesh[j, i], ph_opt, 0)
            
            fig_3d2 = plt.figure(figsize=(10, 8))
            ax2 = fig_3d2.add_subplot(111, projection='3d')
            surf2 = ax2.plot_surface(temp_mesh2, catalyst_mesh, yield_mesh2, cmap='plasma', alpha=0.8)
            ax2.set_xlabel('温度 (°C)')
            ax2.set_ylabel('触媒濃度 (mol/L)')
            ax2.set_zlabel('収率 (%)')
            ax2.set_title('温度×触媒の負の交互作用\n（高温時は触媒濃度を下げる）')
            fig_3d2.colorbar(surf2)
            st.pyplot(fig_3d2)
            plt.close()
        
        st.markdown("""
        **🔄 交互作用の特徴：**
        - **正の交互作用（温度×時間）：** 両因子を高水準にすると相乗効果で収率がさらに向上
        - **負の交互作用（温度×触媒）：** 高温時は触媒濃度を下げた方が収率が高くなる
        - これらの交互作用により、単純な主効果だけでは最適化できない複雑な応答曲面が形成される
        """)
    
    # 最適条件での収率分布
    st.markdown("### 🎯 最適条件での収率分布（実験誤差を含む）")
    
    # 理論最適値（ノイズなし）を表示
    theoretical_optimum_yield = PROCESS_MODEL.yield_function(105, 60, 0.3, 7.0, 0)
    st.info(f"""
    🎯 **理論最適条件での収率**  
    温度105°C, 時間60分, 触媒0.3mol/L, pH7.0  
    **理論最大収率: {theoretical_optimum_yield:.1f}%** （実験誤差なし）
    """)
    
    # 最適条件でのシミュレーション（ノイズあり）
    np.random.seed(42)
    n_simulations = 1000
    optimal_yields = []
    
    for _ in range(n_simulations):
        noise = np.random.normal(0, PROCESS_MODEL.yield_params['error_std'])
        yield_val = PROCESS_MODEL.yield_function(105, 60, 0.3, 7.0, noise)
        optimal_yields.append(yield_val)
    
    fig_dist = plt.figure(figsize=(12, 6))
    
    # ヒストグラム
    plt.subplot(1, 2, 1)
    plt.hist(optimal_yields, bins=50, alpha=0.7, color='skyblue', edgecolor='black')
    plt.axvline(x=np.mean(optimal_yields), color='red', linestyle='--', 
                label=f'平均: {np.mean(optimal_yields):.2f}%')
    plt.axvline(x=np.mean(optimal_yields) + 2*np.std(optimal_yields), color='orange', linestyle=':', 
                label=f'+2σ: {np.mean(optimal_yields) + 2*np.std(optimal_yields):.2f}%')
    plt.axvline(x=np.mean(optimal_yields) - 2*np.std(optimal_yields), color='orange', linestyle=':', 
                label=f'-2σ: {np.mean(optimal_yields) - 2*np.std(optimal_yields):.2f}%')
    plt.xlabel('収率 (%)')
    plt.ylabel('頻度')
    plt.title('最適条件での収率分布')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # 累積分布
    plt.subplot(1, 2, 2)
    sorted_yields = np.sort(optimal_yields)
    plt.plot(sorted_yields, np.arange(1, len(sorted_yields) + 1) / len(sorted_yields), 'b-', linewidth=2)
    plt.axvline(x=np.mean(optimal_yields), color='red', linestyle='--', label='平均')
    plt.axhline(y=0.5, color='gray', linestyle=':', alpha=0.5)
    plt.xlabel('収率 (%)')
    plt.ylabel('累積確率')
    plt.title('収率の累積分布関数')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    st.pyplot(fig_dist)
    plt.close()
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("理論最適収率", f"{np.mean(optimal_yields):.2f}%", f"±{2*np.std(optimal_yields):.2f}%")
    with col2:
        st.metric("95%信頼区間", f"{np.percentile(optimal_yields, 2.5):.1f}% - {np.percentile(optimal_yields, 97.5):.1f}%")
    with col3:
        st.metric("変動係数", f"{100*np.std(optimal_yields)/np.mean(optimal_yields):.1f}%")
    
    st.markdown("### 🚀 使い方")
    st.markdown("""
    1. **左側のメニュー**から学習したい項目を選択
    2. **理論説明**を読んで基本概念を理解
    3. **シミュレーション**でパラメータを調整して実験
    4. **結果の解釈**を通じて理解を深化
    """)

def show_basics():
    st.markdown('<h1 class="section-header">📚 実験計画法の基本</h1>', unsafe_allow_html=True)
    
    # 基本概念
    st.markdown("## 🎯 実験計画法とは")
    st.markdown("""
    <div class="info-box">
    実験計画法（Design of Experiments, DOE）は、効率的で信頼性の高い実験を設計し、
    得られたデータから最大限の情報を抽出するための統計的手法です。
    </div>
    """, unsafe_allow_html=True)
    
    # 基本用語
    st.markdown("## 📖 基本用語")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        **🎯 応答変数（Response Variable）**
        - 実験で測定する目的変数
        - 例：反応収率、強度、時間
        
        **⚙️ 因子（Factor）**
        - 応答に影響を与える可能性のある変数
        - 例：温度、圧力、濃度
        
        **📊 水準（Level）**
        - 因子が取り得る値
        - 例：温度100°C, 150°C, 200°C
        """)
    
    with col2:
        st.markdown("""
        **🔬 処理（Treatment）**
        - 因子の水準の組み合わせ
        - 実験の一つの条件設定
        
        **🔄 反復（Replication）**
        - 同一条件での実験の繰り返し
        - 実験誤差の推定に必要
        
        **🎲 ランダム化（Randomization）**
        - 実験順序の無作為化
        - 系統誤差を防ぐ
        """)
    
    # 実験計画の種類
    st.markdown("## 🏗️ 実験計画の種類")
    
    tab1, tab2, tab3, tab4 = st.tabs(["一因子実験", "多因子実験", "応答曲面法", "その他の計画"])
    
    with tab1:
        st.markdown("""
        ### 🔬 一因子実験（One-Factor Experiment）
        
        **特徴：**
        - 1つの因子のみを変化させる
        - 最も基本的な実験計画
        - 因子の主効果を調べる
        
        **適用例：**
        - 温度が化学反応収率に与える影響
        - 肥料の量が植物の成長に与える影響
        """)
        
        # 一因子実験の図示
        fig, ax = plt.subplots(figsize=(8, 4))
        levels = ['低', '中', '高']
        responses = [20, 35, 45]
        ax.bar(levels, responses, color=['lightblue', 'lightgreen', 'lightcoral'])
        ax.set_xlabel('因子の水準')
        ax.set_ylabel('応答値')
        ax.set_title('一因子実験の例')
        st.pyplot(fig)
    
    with tab2:
        st.markdown("""
        ### ⚗️ 多因子実験（Multi-Factor Experiment）
        
        **特徴：**
        - 複数の因子を同時に変化させる
        - 因子間の交互作用を調べられる
        - 効率的な実験が可能
        
        **2^k実験：**
        - k個の因子、各2水準
        - 2^k回の実験で完全実施
        """)
        
        # 2因子実験の図示
        fig, ax = plt.subplots(figsize=(8, 6))
        x = np.array([1, 2, 1, 2])
        y = np.array([1, 1, 2, 2])
        responses = np.array([10, 15, 20, 30])
        
        scatter = ax.scatter(x, y, s=responses*10, c=responses, cmap='viridis', alpha=0.7)
        ax.set_xlabel('因子A')
        ax.set_ylabel('因子B')
        ax.set_title('2因子実験の応答')
        ax.set_xticks([1, 2])
        ax.set_xticklabels(['低水準', '高水準'])
        ax.set_yticks([1, 2])
        ax.set_yticklabels(['低水準', '高水準'])
        plt.colorbar(scatter, label='応答値')
        st.pyplot(fig)
    
    with tab3:
        st.markdown("""
        ### 📈 応答曲面法（Response Surface Methodology）
        
        **特徴：**
        - 因子と応答の関係を曲面で表現
        - 最適条件の探索に有効
        - 2次モデルを使用
        
        **手順：**
        1. スクリーニング実験
        2. 最急上昇法
        3. 応答曲面実験
        4. 最適化
        """)
    
    with tab4:
        st.markdown("""
        ### 🎯 その他の実験計画
        
        **ラテン方格法：**
        - ブロック因子が2つある場合
        - 行と列でブロック化
        
        **分割実験：**
        - 因子の実施の難易度が異なる場合
        - 主区と副区に分割
        
        **直交配列実験：**
        - 多因子実験の部分実施
        - 直交性を保持して実験数を削減
        """)

def show_one_factor():
    st.markdown('<h1 class="section-header">🔬 一因子実験</h1>', unsafe_allow_html=True)
    
    st.markdown("## 📖 一因子実験とは")
    st.markdown("""
    <div class="info-box">
    一因子実験は、1つの因子（独立変数）が応答変数（従属変数）に与える影響を調べる最も基本的な実験計画です。
    因子の異なる水準（レベル）における応答の違いを統計的に検定します。
    </div>
    """, unsafe_allow_html=True)
    
    # 共通課題の説明
    st.markdown("## 🏭 共通課題：化学反応プロセス")
    st.markdown("""
    **目標：** 反応温度が収率に与える影響を調査し、最適な温度範囲を特定する
    
    **実験条件：**
    - 因子：反応温度（80-120°C）
    - 応答：収率（%）
    - その他固定条件：反応時間60分、触媒濃度0.3mol/L、pH7.0
    """)
    
    # 数式の表示
    with st.expander("🧮 使用する数式（共通プロセスモデル）"):
        st.markdown("""
        **収率計算式：**
        ```
        収率 = 60 + 0.8×T + (-0.004)×(T-105)² + 0.3×t + (-0.002)×(t-60)² 
             + 50×C + (-30)×(C-0.3)² + 2×(pH-7) 
             + 0.01×(T-100)×(t-60) + (-10)×(T-100)×(C-0.3) + ε
        ```
        ここで：
        - T: 温度 (°C)
        - t: 時間 (分) = 60 (固定)
        - C: 触媒濃度 (mol/L) = 0.3 (固定)
        - pH = 7.0 (固定)
        - ε: N(0, 2²) の誤差項
        """)
    
    # シミュレーション部分
    st.markdown("## 🎮 一因子実験シミュレーション")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### パラメータ設定")
        
        # 温度水準の設定
        st.markdown("**温度水準の設定:**")
        min_temp = st.number_input("最低温度 (°C)", value=80, min_value=80, max_value=110)
        max_temp = st.number_input("最高温度 (°C)", value=120, min_value=90, max_value=120)
        n_levels = st.slider("水準数", 3, 6, 5)
        
        temperatures = np.linspace(min_temp, max_temp, n_levels)
        st.write("**使用する温度水準:**", [f"{t:.0f}°C" for t in temperatures])
        
        # 各水準のサンプル数
        n_samples = st.slider("各水準のサンプル数", 3, 10, 4)
        
        # ランダムシード
        random_seed = st.number_input("乱数シード", value=42, step=1)
        
        # データ生成
        generate_button = st.button("実験実行", type="primary")
    
    with col2:
        if generate_button or 'one_factor_data' not in st.session_state:
            np.random.seed(int(random_seed))
            
            # 共通モデルを使用してデータ生成
            data = []
            for temp in temperatures:
                for rep in range(n_samples):
                    # 共通プロセスモデルを使用
                    noise = np.random.normal(0, PROCESS_MODEL.yield_params['error_std'])
                    yield_val = PROCESS_MODEL.yield_function(temp, noise=noise)
                    
                    data.append({
                        'Temperature': f"{temp:.0f}°C",
                        'Temperature_Value': temp,
                        'Yield': yield_val,
                        'Replicate': rep + 1
                    })
            
            df = pd.DataFrame(data)
            st.session_state.one_factor_data = df
        
        if 'one_factor_data' in st.session_state:
            df = st.session_state.one_factor_data
            
            # データの表示
            st.markdown("### 📊 実験結果")
            st.dataframe(df)
            
            # 箱ひげ図
            fig_box = px.box(df, x='Temperature', y='Yield', 
                           title='温度水準別収率の分布')
            fig_box.update_layout(height=400)
            st.plotly_chart(fig_box, use_container_width=True)
            
            # 散布図
            fig_scatter = px.strip(df, x='Temperature', y='Yield', 
                                 title='温度と収率の関係')
            fig_scatter.update_layout(height=400)
            st.plotly_chart(fig_scatter, use_container_width=True)
    
    # 統計解析
    if 'one_factor_data' in st.session_state:
        st.markdown("## 📈 統計解析結果")
        
        df = st.session_state.one_factor_data
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 📊 記述統計")
            desc_stats = df.groupby('Temperature')['Yield'].agg(['count', 'mean', 'std', 'min', 'max']).round(3)
            st.dataframe(desc_stats)
        
        with col2:
            st.markdown("### 🔍 一元配置分散分析（ANOVA）")
            
            # ANOVAの実行
            groups = [group['Yield'].values for name, group in df.groupby('Temperature')]
            f_stat, p_value = stats.f_oneway(*groups)
            
            # 効果サイズ（η²）の計算
            grand_mean = df['Yield'].mean()
            ss_between = sum([len(group) * (group.mean() - grand_mean)**2 for group in groups])
            ss_total = sum([(x - grand_mean)**2 for x in df['Yield']])
            eta_squared = ss_between / ss_total
            
            st.write(f"**F統計量:** {f_stat:.4f}")
            st.write(f"**p値:** {p_value:.4f}")
            st.write(f"**効果サイズ (η²):** {eta_squared:.4f}")
            
            if p_value < 0.05:
                st.success("🎉 温度効果は有意です（p < 0.05）")
            else:
                st.info("📝 温度効果は有意ではありません（p ≥ 0.05）")
        
        # 多重比較
        st.markdown("### 🔀 多重比較（Tukey HSD検定）")
        
        if len(set(df['Temperature'])) > 2:
            from scipy.stats import tukey_hsd
            
            try:
                # Tukey HSD検定
                groups_for_tukey = [group['Yield'].values for name, group in df.groupby('Temperature')]
                tukey_result = tukey_hsd(*groups_for_tukey)
                
                # 結果の表示
                temp_names = sorted(df['Temperature'].unique())
                comparison_results = []
                
                for i in range(len(temp_names)):
                    for j in range(i+1, len(temp_names)):
                        comparison_results.append({
                            '比較': f"{temp_names[i]} vs {temp_names[j]}",
                            'p値': tukey_result.pvalue[i, j],
                            '有意差': '有' if tukey_result.pvalue[i, j] < 0.05 else '無'
                        })
                
                comparison_df = pd.DataFrame(comparison_results)
                st.dataframe(comparison_df)
                
            except Exception as e:
                st.warning("多重比較の計算でエラーが発生しました。")
        
        # 最適温度の推定
        st.markdown("### 🎯 最適温度の推定")
        temp_means = df.groupby('Temperature_Value')['Yield'].mean()
        optimal_temp = temp_means.idxmax()
        max_yield = temp_means.max()
        
        st.success(f"**推定最適温度:** {optimal_temp:.0f}°C")
        st.info(f"**期待収率:** {max_yield:.2f}%")
        
        # 理論値との比較
        theoretical_optimum = PROCESS_MODEL.yield_params['temp_center']  # 105°C
        st.write(f"**理論最適温度:** {theoretical_optimum}°C")
        
        # データダウンロード
        st.markdown("### 💾 データダウンロード")
        csv = df.to_csv(index=False)
        st.download_button(
            label="CSVファイルをダウンロード",
            data=csv,
            file_name="one_factor_experiment_data.csv",
            mime="text/csv"
        )
    
    # 最適値の発見方法
    st.markdown("---")
    st.markdown("## 🎯 一因子実験による最適値の発見")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 📊 この手法で見つけた最適値
        
        **🌡️ 推定最適温度:** 105°C  
        **📈 期待収率:** 約78%
        
        **📋 発見方法:**
        1. 複数の温度水準で実験実施
        2. 各水準の平均収率を比較
        3. 最も高い収率を示す水準を特定
        4. ANOVAで統計的有意性を確認
        """)
    
    with col2:
        st.markdown("""
        ### ⚖️ 一因子実験の利点と限界
        
        **✅ 利点:**
        - シンプルで理解しやすい
        - 統計的検定が明確
        - 実施が容易
        
        **⚠️ 限界:**
        - 1つの因子しか調査できない
        - 交互作用を見つけられない
        - 他因子の影響を考慮できない
        - 真の最適値を見逃す可能性
        """)
    
    if 'one_factor_data' in st.session_state:
        st.markdown("""
        ### 🤔 この結果をどう解釈するか？
        
        **現在の結果:** 温度単独での最適化
        - 他の因子（時間、触媒濃度、pH）は固定値
        - 実際の最適条件は他因子との組み合わせで決まる
        
        **次のステップ:** 
        - 多因子実験で因子間の交互作用を調査
        - 応答曲面法で連続的な最適化を実施
        - より包括的な最適化戦略が必要
        """)
        
        # 理論値との比較
        st.info(f"""
        💡 **理論値との比較**  
        理論最適温度: 105°C ← 完全なプロセスモデルから導出  
        実験推定値: {optimal_temp:.0f}°C ← 一因子実験の結果  
        
        この一致は、温度が主要な最適化因子であることを示しています。
        ただし、他因子との相互作用により、実際の最適条件はより複雑です。
        """)

def show_factorial():
    st.markdown('<h1 class="section-header">⚗️ 多因子実験（2^k実験）</h1>', unsafe_allow_html=True)
    
    st.markdown("## 📖 2^k実験とは")
    st.markdown("""
    <div class="info-box">
    2^k実験は、k個の因子をそれぞれ2水準（高水準・低水準）で組み合わせた実験計画です。
    主効果だけでなく、因子間の交互作用も効率的に調べることができます。
    </div>
    """, unsafe_allow_html=True)
    
    # 共通課題の説明
    st.markdown("## 🏭 共通課題：化学反応プロセス")
    st.markdown("""
    **目標：** 4つの因子（温度、時間、触媒濃度、pH）が収率に与える主効果と交互作用を調査する
    
    **実験条件：**
    - 因子A：反応温度（低水準95°C、高水準105°C）
    - 因子B：反応時間（低水準45分、高水準75分）
    - 因子C：触媒濃度（低水準0.2mol/L、高水準0.4mol/L）
    - 因子D：pH（低水準6.5、高水準7.5）
    - 実験計画：2⁴完全実施計画（16回実験）
    """)
    
    # 数式の表示
    with st.expander("🧮 使用する数式（共通プロセスモデル）"):
        st.markdown("""
        **収率計算式（完全版）：**
        ```
        収率 = 60 + 0.8×T + (-0.004)×(T-105)² + 0.3×t + (-0.002)×(t-60)²
             + 50×C + (-30)×(C-0.3)² + 2×(pH-7)
             + 0.01×(T-100)×(t-60) + (-10)×(T-100)×(C-0.3) + ε
        ```
        
        **2水準での値：**
        - T: 95°C（低）, 105°C（高）
        - t: 45分（低）, 75分（高）  
        - C: 0.2mol/L（低）, 0.4mol/L（高）
        - pH: 6.5（低）, 7.5（高）
        - ε: N(0, 2²) の誤差項
        """)
    
    # シミュレーション部分
    st.markdown("## 🎮 2⁴実験シミュレーション")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### 実験設定")
        
        # 因子レベルの確認
        st.markdown("**因子水準：**")
        st.write("- **温度：** 95°C（低）/ 105°C（高）")
        st.write("- **時間：** 45分（低）/ 75分（高）") 
        st.write("- **触媒：** 0.2mol/L（低）/ 0.4mol/L（高）")
        st.write("- **pH：** 6.5（低）/ 7.5（高）")
        
        st.markdown("---")
        
        # 実験オプション
        include_replicates = st.checkbox("反復実験を含める", value=True)
        n_replicates = 2 if include_replicates else 1
        
        # ランダムシード
        random_seed = st.number_input("乱数シード", value=42, step=1)
        
        # データ生成
        generate_button = st.button("2⁴実験実行", type="primary")
    
    with col2:
        if generate_button or 'factorial_data' not in st.session_state:
            np.random.seed(int(random_seed))
            
            # 2^4実験条件の生成
            factor_levels = list(product([0, 1], repeat=4))
            factor_names = ['Temperature', 'Time', 'Catalyst', 'pH']
            
            # 因子水準の実際値
            level_values = {
                'Temperature': [95, 105],  # 低水準, 高水準
                'Time': [45, 75],
                'Catalyst': [0.2, 0.4],
                'pH': [6.5, 7.5]
            }
            
            data = []
            for run_no, levels in enumerate(factor_levels):
                for rep in range(n_replicates):
                    # 実際の因子値
                    temp = level_values['Temperature'][levels[0]]
                    time = level_values['Time'][levels[1]]
                    catalyst = level_values['Catalyst'][levels[2]]
                    ph = level_values['pH'][levels[3]]
                    
                    # 共通プロセスモデルを使用して収率計算
                    noise = np.random.normal(0, PROCESS_MODEL.yield_params['error_std'])
                    yield_val = PROCESS_MODEL.yield_function(temp, time, catalyst, ph, noise)
                    
                    # データの記録
                    data.append({
                        'Run': run_no + 1,
                        'Temperature': '高' if levels[0] == 1 else '低',
                        'Time': '高' if levels[1] == 1 else '低',
                        'Catalyst': '高' if levels[2] == 1 else '低',
                        'pH': '高' if levels[3] == 1 else '低',
                        'Temp_coded': levels[0],
                        'Time_coded': levels[1],
                        'Catalyst_coded': levels[2],
                        'pH_coded': levels[3],
                        'Temp_actual': temp,
                        'Time_actual': time,
                        'Catalyst_actual': catalyst,
                        'pH_actual': ph,
                        'Yield': yield_val,
                        'Replicate': rep + 1
                    })
            
            df = pd.DataFrame(data)
            st.session_state.factorial_data = df
            st.session_state.factor_names = factor_names
        
        if 'factorial_data' in st.session_state:
            df = st.session_state.factorial_data
            factor_names = st.session_state.factor_names
            
            # データの表示
            st.markdown("### 📊 2⁴実験データ")
            display_cols = ['Run', 'Temperature', 'Time', 'Catalyst', 'pH', 'Yield']
            if include_replicates:
                display_cols.append('Replicate')
            st.dataframe(df[display_cols])
            
            # 主効果の可視化
            st.markdown("### 📈 主効果の可視化")
            
            fig, axes = plt.subplots(2, 2, figsize=(12, 8))
            axes = axes.ravel()
            
            for i, factor in enumerate(factor_names):
                means = df.groupby(factor)['Yield'].mean()
                axes[i].bar(means.index, means.values, color=['lightblue', 'lightcoral'])
                axes[i].set_xlabel(factor)
                axes[i].set_ylabel('平均収率 (%)')
                axes[i].set_title(f'{factor}の主効果')
                
                # 効果の大きさを表示
                effect_size = means['高'] - means['低']
                axes[i].text(0.5, axes[i].get_ylim()[1]*0.9, 
                           f'効果: {effect_size:.2f}%', 
                           ha='center', fontweight='bold')
            
            plt.tight_layout()
            st.pyplot(fig)
            
            # 交互作用プロット
            st.markdown("### 🔄 主要な交互作用プロット")
            
            # Temperature × Time の交互作用
            interaction_data = []
            for temp in ['低', '高']:
                for time in ['低', '高']:
                    mean_yield = df[(df['Temperature'] == temp) & (df['Time'] == time)]['Yield'].mean()
                    interaction_data.append({
                        'Temperature': temp,
                        'Time': time,
                        'Yield': mean_yield
                    })
            
            interaction_df = pd.DataFrame(interaction_data)
            fig_interaction = px.line(interaction_df, x='Temperature', y='Yield', color='Time',
                                   title='温度×時間の交互作用', markers=True)
            st.plotly_chart(fig_interaction, use_container_width=True)
    
    # 統計解析
    if 'factorial_data' in st.session_state:
        st.markdown("## 📈 統計解析結果")
        
        df = st.session_state.factorial_data
        factor_names = st.session_state.factor_names
        k = 4  # 2^4実験
        
        # 効果の計算
        st.markdown("### 🔍 効果の推定")
        
        effects = {}
        
        # 主効果の計算
        for factor in factor_names:
            high_mean = df[df[factor] == '高']['Yield'].mean()
            low_mean = df[df[factor] == '低']['Yield'].mean()
            main_effect = high_mean - low_mean
            effects[factor] = main_effect
        
        # 2因子交互作用効果の計算
        if k >= 2:
            for i in range(k):
                for j in range(i+1, k):
                    factor_a = factor_names[i]
                    factor_b = factor_names[j]
                    
                    # 各組み合わせでの平均
                    high_high = df[(df[factor_a] == '高') & (df[factor_b] == '高')]['Yield'].mean()
                    high_low = df[(df[factor_a] == '高') & (df[factor_b] == '低')]['Yield'].mean()
                    low_high = df[(df[factor_a] == '低') & (df[factor_b] == '高')]['Yield'].mean()
                    low_low = df[(df[factor_a] == '低') & (df[factor_b] == '低')]['Yield'].mean()
                    
                    # 交互作用効果
                    interaction_effect = ((high_high - high_low) - (low_high - low_low)) / 2
                    effects[f"{factor_a}×{factor_b}"] = interaction_effect
        
        # 効果の表示
        effects_df = pd.DataFrame(list(effects.items()), columns=['効果', '推定値'])
        effects_df['推定値'] = effects_df['推定値'].round(3)
        st.dataframe(effects_df)
        
        # 正規確率プロット（効果の有意性確認）
        st.markdown("### 📊 効果の正規確率プロット")
        
        effect_values = list(effects.values())
        fig, ax = plt.subplots(figsize=(8, 6))
        stats.probplot(effect_values, dist="norm", plot=ax)
        ax.set_title("効果の正規確率プロット")
        ax.grid(True, alpha=0.3)
        
        # 効果にラベルを追加
        for i, (name, value) in enumerate(effects.items()):
            ax.annotate(name, (stats.norm.ppf((i+0.5)/(len(effect_values)+1)), value),
                       xytext=(5, 5), textcoords='offset points', fontsize=9)
        
        st.pyplot(fig)
        
        # データダウンロード
        st.markdown("### 💾 データダウンロード")
        csv = df.to_csv(index=False)
        st.download_button(
            label="CSVファイルをダウンロード",
            data=csv,
            file_name="factorial_experiment_data.csv",
            mime="text/csv"
        )
    
    # 最適値の発見方法
    st.markdown("---")
    st.markdown("## 🎯 2^k実験による最適値の発見")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 📊 この手法で見つけた最適値
        
        **🏆 推定最適条件:**
        - **温度:** 高水準（105°C）
        - **時間:** 高水準（75分）  
        - **触媒:** 高水準（0.4 mol/L）
        - **pH:** 高水準（7.5）
        
        **📋 発見方法:**
        1. 2^4 = 16通りの条件組み合わせで実験
        2. 主効果の大きさを比較
        3. 交互作用効果を分析
        4. 正規確率プロットで有意な効果を特定
        """)
    
    with col2:
        st.markdown("""
        ### ⚖️ 2^k実験の利点と限界
        
        **✅ 利点:**
        - 複数因子を同時に調査
        - 交互作用効果を検出
        - 効率的な実験計画
        - 統計的に信頼性の高い結果
        
        **⚠️ 限界:**
        - 2水準のみ（高・低）
        - 非線形効果を見逃す可能性
        - 最適点が水準間にある場合検出困難
        - 因子数が多いと実験数が爆発的に増加
        """)
    
    if 'factorial_data' in st.session_state:
        st.markdown("""
        ### 🤔 この結果をどう解釈するか？
        
        **現在の結果:** 4因子の主効果と交互作用を把握
        - 各因子の影響の大きさを定量化
        - 因子間の相互作用を発見
        - ただし、2水準間の最適点は不明
        
        **発見された重要な知見:**
        - 温度×時間の正の交互作用：両方高めると相乗効果
        - 温度×触媒の負の交互作用：高温時は触媒濃度を調整
        
        **次のステップ:** 
        - 応答曲面法で連続的な最適化
        - 交互作用を考慮した詳細な最適化
        """)
        
        st.info("""
        💡 **理論値との比較**  
        理論最適条件: 温度105°C, 時間60分, 触媒0.3mol/L, pH7.0  
        2^k実験結果: すべて高水準が最適  
        
        ⚠️ **注意:** 2^k実験では設定した水準内でしか最適化できません。
        真の最適点（例：時間60分, 触媒0.3mol/L）が高水準と低水準の間にある場合、
        この手法だけでは発見できません。より細かい最適化が必要です。
        """)
    
    st.warning("""
    🔍 **2^k実験の重要な教訓**  
    この手法は「スクリーニング」に最適です。多くの因子の中から重要なものを特定し、
    交互作用の存在を把握することが主目的です。真の最適点の発見には、
    より精密な手法（応答曲面法など）との組み合わせが必要です。
    """)

def show_anova():
    st.markdown('<h1 class="section-header">📊 分散分析（ANOVA）</h1>', unsafe_allow_html=True)
    
    st.markdown("## 📖 分散分析とは")
    
    # 共通課題の説明
    st.markdown("## 🏭 共通課題：化学反応プロセス")
    st.markdown("""
    **目標：** 異なる温度条件での収率を測定し、統計的に有意な差を検出する
    
    **実験条件：**
    - 因子：反応温度（5水準：90°C, 95°C, 100°C, 105°C, 110°C）
    - 他の因子：時間60分、触媒0.3mol/L、pH=7.0で固定
    - 各水準で6回繰り返し測定
    """)
    
    # 数式の表示
    with st.expander("🧮 使用する数式（共通プロセスモデル）"):
        st.markdown("""
        **収率計算式：**
        ```
        収率 = 60 + 0.8×T + (-0.004)×(T-105)² + ε
        ```
        
        **ANOVAの数式：**
        - 総平方和：SS_total = Σ(y_ij - ȳ)²
        - 群間平方和：SS_between = Σn_i(ȳ_i - ȳ)²  
        - 群内平方和：SS_within = ΣΣ(y_ij - ȳ_i)²
        - F統計量：F = MS_between / MS_within
        - ε: N(0, 2²) の誤差項
        """)
    
    st.markdown("## 📖 分散分析の理論")
    st.markdown("""
    <div class="info-box">
    分散分析（Analysis of Variance, ANOVA）は、3つ以上のグループ間で平均値に差があるかを検定する統計手法です。
    全変動を要因による変動と誤差による変動に分解して分析します。
    </div>
    """, unsafe_allow_html=True)
    
    # ANOVA の理論説明
    st.markdown("## 🧮 分散分析の理論")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 📐 基本的な考え方
        
        **全変動の分解:**
        - 全変動 = 群間変動 + 群内変動
        - SS_total = SS_between + SS_within
        
        **F統計量:**
        - F = MS_between / MS_within
        - MS = SS / df（平均平方）
        """)
    
    with col2:
        st.markdown("""
        ### 🔍 検定の仮説
        
        **帰無仮説 (H₀):**
        - 全ての群の平均が等しい
        - μ₁ = μ₂ = ... = μₖ
        
        **対立仮説 (H₁):**
        - 少なくとも1つの群の平均が異なる
        """)
    
    # インタラクティブ ANOVA デモ
    st.markdown("## 🎮 分散分析デモンストレーション")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### パラメータ設定")
        
        # グループ数
        n_groups = st.slider("グループ数", 2, 6, 3)
        
        # 各グループの設定
        group_means = []
        group_sds = []
        group_sizes = []
        
        for i in range(n_groups):
            st.markdown(f"**グループ {i+1}:**")
            mean = st.number_input(f"平均", value=float(50 + i*10), key=f"anova_mean_{i}")
            sd = st.number_input(f"標準偏差", value=5.0, min_value=0.1, key=f"anova_sd_{i}")
            size = st.number_input(f"サンプル数", value=10, min_value=3, key=f"anova_size_{i}")
            
            group_means.append(mean)
            group_sds.append(sd)
            group_sizes.append(int(size))
        
        # ランダムシード
        random_seed = st.number_input("乱数シード", value=42, step=1)
        
        generate_button = st.button("データ生成", type="primary")
    
    with col2:
        if generate_button or 'anova_data' not in st.session_state:
            np.random.seed(int(random_seed))
            
            # データ生成
            data = []
            for i in range(n_groups):
                group_data = np.random.normal(group_means[i], group_sds[i], group_sizes[i])
                for value in group_data:
                    data.append({
                        'Group': f'グループ{i+1}',
                        'Value': value
                    })
            
            df_anova = pd.DataFrame(data)
            st.session_state.anova_data = df_anova
            st.session_state.group_params = {
                'means': group_means,
                'sds': group_sds,
                'sizes': group_sizes
            }
        
        if 'anova_data' in st.session_state:
            df_anova = st.session_state.anova_data
            
            # データの可視化
            st.markdown("### 📊 データの分布")
            
            # 箱ひげ図
            fig_box = px.box(df_anova, x='Group', y='Value', 
                           title='各グループの分布（箱ひげ図）')
            st.plotly_chart(fig_box, use_container_width=True)
            
            # ヒストグラム
            fig_hist = px.histogram(df_anova, x='Value', color='Group', 
                                  marginal='box', title='各グループのヒストグラム')
            st.plotly_chart(fig_hist, use_container_width=True)
    
    # ANOVA計算と結果表示
    if 'anova_data' in st.session_state:
        df_anova = st.session_state.anova_data
        
        st.markdown("## 📈 分散分析の結果")
        
        # 記述統計
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 📊 記述統計")
            desc_stats = df_anova.groupby('Group')['Value'].agg([
                'count', 'mean', 'std', 'var'
            ]).round(4)
            st.dataframe(desc_stats)
        
        with col2:
            st.markdown("### 🧮 分散分析表")
            
            # ANOVA計算
            groups = [group['Value'].values for name, group in df_anova.groupby('Group')]
            f_stat, p_value = stats.f_oneway(*groups)
            
            # 手動でANOVA表を作成
            grand_mean = df_anova['Value'].mean()
            n_total = len(df_anova)
            k = len(groups)
            
            # 群間平方和
            ss_between = sum([len(group) * (group.mean() - grand_mean)**2 for group in groups])
            df_between = k - 1
            ms_between = ss_between / df_between
            
            # 群内平方和
            ss_within = sum([sum((x - group.mean())**2) for group in groups])
            df_within = n_total - k
            ms_within = ss_within / df_within
            
            # 全平方和
            ss_total = sum([(x - grand_mean)**2 for x in df_anova['Value']])
            df_total = n_total - 1
            
            # ANOVA表
            anova_table = pd.DataFrame({
                '変動要因': ['群間', '群内', '全体'],
                '平方和': [ss_between, ss_within, ss_total],
                '自由度': [df_between, df_within, df_total],
                '平均平方': [ms_between, ms_within, ''],
                'F値': [f_stat, '', ''],
                'p値': [p_value, '', '']
            })
            
            st.dataframe(anova_table.round(4))
        
        # 結果の解釈
        st.markdown("### 🔍 結果の解釈")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if p_value < 0.05:
                st.success(f"🎉 **有意差あり** (p = {p_value:.4f} < 0.05)")
                st.write("少なくとも1つのグループの平均が他と異なります")
            else:
                st.info(f"📝 **有意差なし** (p = {p_value:.4f} ≥ 0.05)")
                st.write("全てのグループの平均に差があるとは言えません")
        
        with col2:
            # 効果サイズ（η²）
            eta_squared = ss_between / ss_total
            st.write(f"**効果サイズ (η²):** {eta_squared:.4f}")
            
            if eta_squared < 0.01:
                effect_size = "小"
            elif eta_squared < 0.06:
                effect_size = "中"
            else:
                effect_size = "大"
            
            st.write(f"**効果の大きさ:** {effect_size}")
        
        # 分散分析の前提条件チェック
        st.markdown("### ✅ 前提条件のチェック")
        
        tab1, tab2, tab3 = st.tabs(["正規性", "等分散性", "独立性"])
        
        with tab1:
            st.markdown("#### 🔍 正規性の検定（Shapiro-Wilk検定）")
            
            normality_results = []
            for name, group in df_anova.groupby('Group'):
                if len(group) >= 3:
                    stat, p_val = stats.shapiro(group['Value'])
                    normality_results.append({
                        'グループ': name,
                        'W統計量': stat,
                        'p値': p_val,
                        '正規性': '満たす' if p_val > 0.05 else '満たさない'
                    })
            
            norm_df = pd.DataFrame(normality_results)
            st.dataframe(norm_df.round(4))
        
        with tab2:
            st.markdown("#### 🔍 等分散性の検定（Levene検定）")
            
            levene_stat, levene_p = stats.levene(*groups)
            st.write(f"**Levene統計量:** {levene_stat:.4f}")
            st.write(f"**p値:** {levene_p:.4f}")
            
            if levene_p > 0.05:
                st.success("✅ 等分散性の仮定を満たします")
            else:
                st.warning("⚠️ 等分散性の仮定を満たしません")
        
        with tab3:
            st.markdown("#### 📝 独立性について")
            st.write("""
            独立性は実験設計によって保証される前提条件です：
            - サンプルが互いに独立して選ばれている
            - 一つの観測値が他に影響を与えない
            - ランダムサンプリングが行われている
            """)
        
        # データダウンロード
        st.markdown("### 💾 データダウンロード")
        csv = df_anova.to_csv(index=False)
        st.download_button(
            label="CSVファイルをダウンロード",
            data=csv,
            file_name="anova_data.csv",
            mime="text/csv"
        )
    
    # 最適値の発見方法
    st.markdown("---")
    st.markdown("## 🎯 分散分析による最適値の発見")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 📊 この手法で見つけた最適値
        
        **🌡️ 推定最適温度:** 105°C  
        **📈 期待収率:** 約78%
        
        **📋 発見方法:**
        1. 複数の温度水準（90-110°C）で実験
        2. 各水準での繰り返し測定
        3. 群間変動と群内変動を分離・比較
        4. F検定で統計的有意性を判定
        5. 多重比較で水準間の差を詳細分析
        """)
    
    with col2:
        st.markdown("""
        ### ⚖️ ANOVA手法の利点と限界
        
        **✅ 利点:**
        - 統計的に厳密な検定
        - 実験誤差を適切に考慮
        - 多重比較で詳細な差を検出
        - 効果サイズ（η²）で実用的意義を評価
        
        **⚠️ 限界:**
        - 1つの因子のみ調査可能
        - 因子間の交互作用を検出できない
        - 非線形関係を見逃す可能性
        - 水準間の最適点は不明
        """)
    
    if 'anova_data' in st.session_state:
        df_anova = st.session_state.anova_data
        temp_means = df_anova.groupby('Temperature_Value')['Yield'].mean()
        optimal_temp = temp_means.idxmax()
        
        st.markdown("""
        ### 🤔 この結果をどう解釈するか？
        
        **現在の結果:** 温度の主効果のみを分析
        - 他の因子（時間、触媒濃度、pH）は固定
        - 温度変化による収率への影響を定量化
        - 統計的有意性と実用的意義を両方評価
        
        **ANOVAが教えてくれること:**
        - 温度差による収率変動が偶然ではない
        - どの温度水準間に有意差があるか
        - 効果の大きさ（実用的重要性）
        
        **次のステップ:** 
        - 他の重要因子も同様に分析
        - 多因子ANOVAで交互作用を調査
        - より包括的な最適化手法の適用
        """)
        
        st.info(f"""
        💡 **理論値との比較**  
        理論最適温度: 105°C ← 完全なプロセスモデルから導出  
        ANOVA推定値: {optimal_temp:.0f}°C ← 分散分析の結果  
        
        この一致は、ANOVAが単一因子の最適化に有効であることを示します。
        ただし、実際のプロセス最適化では他因子との相互作用も重要です。
        """)
    
    st.success("""
    ✅ **ANOVAの価値**  
    ANOVAは「差があるかどうか」を統計的に厳密に判定する手法です。
    実験データに含まれる誤差を適切に考慮し、観察された差が偶然によるものか、
    真の効果によるものかを区別できます。これは実験計画法の基礎となる重要な考え方です。
    """)

def show_response_surface():
    st.markdown('<h1 class="section-header">📈 応答曲面法</h1>', unsafe_allow_html=True)
    
    st.markdown("## 📖 応答曲面法とは")
    
    # 共通課題の説明
    st.markdown("## 🏭 共通課題：化学反応プロセス")
    st.markdown("""
    **目標：** 温度と時間の2因子で収率を最大化する最適条件を探索する
    
    **実験条件：**
    - 主因子：反応温度（95-115°C）、反応時間（45-75分）
    - 固定因子：触媒0.3mol/L、pH=7.0
    - 実験計画：中心複合計画（CCD）
    """)
    
    # 数式の表示
    with st.expander("🧮 使用する数式（共通プロセスモデル）"):
        st.markdown("""
        **収率計算式（完全版）：**
        ```
        収率 = 60 + 0.8×T + (-0.004)×(T-105)² + 0.3×t + (-0.002)×(t-60)²
             + 50×C + (-30)×(C-0.3)² + 2×(pH-7)
             + 0.01×(T-100)×(t-60) + (-10)×(T-100)×(C-0.3) + ε
        ```
        
        **RSMでの2次モデル：**
        ```
        y = β₀ + β₁x₁ + β₂x₂ + β₁₁x₁² + β₂₂x₂² + β₁₂x₁x₂ + ε
        ```
        
        - x₁: 温度（コード化値）
        - x₂: 時間（コード化値）
        - ε: N(0, 2²) の誤差項
        """)
    
    st.markdown("## 📖 応答曲面法の理論")
    st.markdown("""
    <div class="info-box">
    応答曲面法（Response Surface Methodology, RSM）は、複数の独立変数と応答変数の関係を
    曲面で表現し、最適条件を探索する手法です。通常、2次回帰モデルを使用します。
    </div>
    """, unsafe_allow_html=True)
    
    # RSMの手順説明
    st.markdown("## 🔧 応答曲面法の手順")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 1️⃣ スクリーニング段階
        - 重要な因子を特定
        - 2^k実験や部分実施計画を使用
        
        ### 2️⃣ 最急上昇法
        - 最適領域への移動
        - 1次モデルの勾配を利用
        """)
    
    with col2:
        st.markdown("""
        ### 3️⃣ 応答曲面実験
        - 中心複合計画（CCD）の使用
        - 2次モデルの構築
        
        ### 4️⃣ 最適化
        - 応答曲面の解析
        - 最適条件の決定
        """)
    
    # インタラクティブデモ
    st.markdown("## 🎮 応答曲面法デモンストレーション")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### パラメータ設定")
        
        # 真の応答関数の設定
        st.markdown("#### 真の応答関数: y = β₀ + β₁x₁ + β₂x₂ + β₁₁x₁² + β₂₂x₂² + β₁₂x₁x₂")
        
        beta_0 = st.number_input("β₀ (切片)", value=50.0)
        beta_1 = st.number_input("β₁ (x₁の1次効果)", value=10.0)
        beta_2 = st.number_input("β₂ (x₂の1次効果)", value=8.0)
        beta_11 = st.number_input("β₁₁ (x₁の2次効果)", value=-3.0)
        beta_22 = st.number_input("β₂₂ (x₂の2次効果)", value=-2.0)
        beta_12 = st.number_input("β₁₂ (交互作用効果)", value=1.0)
        
        # 実験設計の選択
        design_type = st.selectbox(
            "実験設計",
            ["中心複合計画 (CCD)", "Box-Behnken計画", "格子点法"]
        )
        
        # 誤差設定
        error_std = st.slider("誤差の標準偏差", 0.1, 5.0, 1.0)
        
        # 因子の範囲
        x1_range = st.slider("因子1の範囲", -3.0, 3.0, (-2.0, 2.0))
        x2_range = st.slider("因子2の範囲", -3.0, 3.0, (-2.0, 2.0))
        
        # ランダムシード
        random_seed = st.number_input("乱数シード", value=42, step=1)
        
        generate_button = st.button("実験実行", type="primary")
    
    with col2:
        if generate_button or 'rsm_data' not in st.session_state:
            np.random.seed(int(random_seed))
            
            # 実験点の生成
            if design_type == "中心複合計画 (CCD)":
                # CCD設計点
                design_points = [
                    [-1, -1], [1, -1], [-1, 1], [1, 1],  # 2^k点
                    [-1.414, 0], [1.414, 0], [0, -1.414], [0, 1.414],  # 軸点
                    [0, 0], [0, 0], [0, 0]  # 中心点（反復）
                ]
            elif design_type == "Box-Behnken計画":
                # Box-Behnken設計点
                design_points = [
                    [-1, -1], [1, -1], [-1, 1], [1, 1],
                    [-1, 0], [1, 0], [0, -1], [0, 1],
                    [0, 0], [0, 0], [0, 0]
                ]
            else:  # 格子点法
                x1_levels = np.linspace(-1, 1, 3)
                x2_levels = np.linspace(-1, 1, 3)
                design_points = [[x1, x2] for x1 in x1_levels for x2 in x2_levels]
            
            # 応答値の計算
            data = []
            for x1_coded, x2_coded in design_points:
                # コード化された値を実際の値に変換
                x1_actual = (x1_coded * (x1_range[1] - x1_range[0])/2) + (x1_range[1] + x1_range[0])/2
                x2_actual = (x2_coded * (x2_range[1] - x2_range[0])/2) + (x2_range[1] + x2_range[0])/2
                
                # 真の応答値の計算
                y_true = (beta_0 + beta_1*x1_coded + beta_2*x2_coded + 
                         beta_11*x1_coded**2 + beta_22*x2_coded**2 + beta_12*x1_coded*x2_coded)
                
                # 誤差の追加
                y_observed = y_true + np.random.normal(0, error_std)
                
                data.append({
                    'x1_coded': x1_coded,
                    'x2_coded': x2_coded,
                    'x1_actual': x1_actual,
                    'x2_actual': x2_actual,
                    'y_true': y_true,
                    'y_observed': y_observed
                })
            
            df_rsm = pd.DataFrame(data)
            st.session_state.rsm_data = df_rsm
            st.session_state.rsm_params = {
                'beta_0': beta_0, 'beta_1': beta_1, 'beta_2': beta_2,
                'beta_11': beta_11, 'beta_22': beta_22, 'beta_12': beta_12,
                'x1_range': x1_range, 'x2_range': x2_range
            }
        
        if 'rsm_data' in st.session_state:
            df_rsm = st.session_state.rsm_data
            
            # 実験データの表示
            st.markdown("### 📊 実験データ")
            st.dataframe(df_rsm.round(3))
    
    # 応答曲面の可視化と解析
    if 'rsm_data' in st.session_state:
        df_rsm = st.session_state.rsm_data
        params = st.session_state.rsm_params
        
        st.markdown("## 📈 応答曲面の解析")
        
        # 2次回帰モデルの構築
        X = df_rsm[['x1_coded', 'x2_coded']].copy()
        X['x1_squared'] = X['x1_coded'] ** 2
        X['x2_squared'] = X['x2_coded'] ** 2
        X['x1_x2'] = X['x1_coded'] * X['x2_coded']
        X['intercept'] = 1
        
        y = df_rsm['y_observed']
        
        # 回帰分析
        from sklearn.linear_model import LinearRegression
        model = LinearRegression(fit_intercept=False)
        model.fit(X, y)
        
        # 予測値
        y_pred = model.predict(X)
        r2_score = model.score(X, y)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 🧮 回帰係数")
            coef_names = ['切片', 'x₁', 'x₂', 'x₁²', 'x₂²', 'x₁x₂']
            coef_df = pd.DataFrame({
                '項': coef_names,
                '推定値': model.coef_,
                '真値': [params['beta_0'], params['beta_1'], params['beta_2'], 
                        params['beta_11'], params['beta_22'], params['beta_12']]
            }).round(3)
            st.dataframe(coef_df)
            
            st.write(f"**決定係数 (R²):** {r2_score:.4f}")
        
        with col2:
            st.markdown("### 🎯 最適化結果")
            
            # 最適点の計算（勾配 = 0の点）
            # ∂y/∂x₁ = β₁ + 2β₁₁x₁ + β₁₂x₂ = 0
            # ∂y/∂x₂ = β₂ + 2β₂₂x₂ + β₁₂x₁ = 0
            
            b1, b2, b11, b22, b12 = model.coef_[1:6]
            
            # 連立方程式の解
            A = np.array([[2*b11, b12], [b12, 2*b22]])
            b = np.array([-b1, -b2])
            
            try:
                optimal_point = np.linalg.solve(A, b)
                x1_opt, x2_opt = optimal_point
                
                # 実際の値に変換
                x1_opt_actual = (x1_opt * (params['x1_range'][1] - params['x1_range'][0])/2) + (params['x1_range'][1] + params['x1_range'][0])/2
                x2_opt_actual = (x2_opt * (params['x2_range'][1] - params['x2_range'][0])/2) + (params['x2_range'][1] + params['x2_range'][0])/2
                
                # 最適応答値
                y_opt = model.coef_[0] + b1*x1_opt + b2*x2_opt + b11*x1_opt**2 + b22*x2_opt**2 + b12*x1_opt*x2_opt
                
                st.write(f"**最適点 (コード化値):**")
                st.write(f"x₁ = {x1_opt:.3f}")
                st.write(f"x₂ = {x2_opt:.3f}")
                st.write(f"**最適点 (実際値):**")
                st.write(f"因子1 = {x1_opt_actual:.3f}")
                st.write(f"因子2 = {x2_opt_actual:.3f}")
                st.write(f"**予測応答値:** {y_opt:.3f}")
                
                # 最適点の性質（最大・最小・鞍点）
                hessian = np.array([[2*b11, b12], [b12, 2*b22]])
                eigenvalues = np.linalg.eigvals(hessian)
                
                if all(ev > 0 for ev in eigenvalues):
                    nature = "最小点"
                elif all(ev < 0 for ev in eigenvalues):
                    nature = "最大点"
                else:
                    nature = "鞍点"
                
                st.write(f"**最適点の性質:** {nature}")
                
            except np.linalg.LinAlgError:
                st.warning("最適点の計算ができませんでした（特異行列）")
        
        # 応答曲面の3D可視化
        st.markdown("### 🎨 応答曲面の可視化")
        
        # 格子点の生成
        x1_grid = np.linspace(-2, 2, 30)
        x2_grid = np.linspace(-2, 2, 30)
        X1_grid, X2_grid = np.meshgrid(x1_grid, x2_grid)
        
        # 予測値の計算
        grid_points = np.column_stack([
            X1_grid.ravel(),
            X2_grid.ravel(),
            X1_grid.ravel()**2,
            X2_grid.ravel()**2,
            X1_grid.ravel() * X2_grid.ravel(),
            np.ones(X1_grid.size)
        ])
        
        Y_pred_grid = model.predict(grid_points).reshape(X1_grid.shape)
        
        # 3D表面プロット
        fig_3d = go.Figure(data=[go.Surface(
            x=X1_grid, y=X2_grid, z=Y_pred_grid,
            colorscale='Viridis',
            name='予測応答曲面'
        )])
        
        # 実験点の追加
        fig_3d.add_trace(go.Scatter3d(
            x=df_rsm['x1_coded'],
            y=df_rsm['x2_coded'],
            z=df_rsm['y_observed'],
            mode='markers',
            marker=dict(size=8, color='red'),
            name='実験点'
        ))
        
        fig_3d.update_layout(
            title='応答曲面（3D）',
            scene=dict(
                xaxis_title='因子1（コード化値）',
                yaxis_title='因子2（コード化値）',
                zaxis_title='応答値'
            ),
            height=600
        )
        
        st.plotly_chart(fig_3d, use_container_width=True)
        
        # 等高線プロット
        fig_contour = go.Figure(data=go.Contour(
            x=x1_grid,
            y=x2_grid,
            z=Y_pred_grid,
            colorscale='Viridis',
            contours=dict(showlabels=True)
        ))
        
        # 実験点の追加
        fig_contour.add_trace(go.Scatter(
            x=df_rsm['x1_coded'],
            y=df_rsm['x2_coded'],
            mode='markers',
            marker=dict(size=10, color='red'),
            name='実験点'
        ))
        
        fig_contour.update_layout(
            title='応答曲面の等高線プロット',
            xaxis_title='因子1（コード化値）',
            yaxis_title='因子2（コード化値）',
            height=500
        )
        
        st.plotly_chart(fig_contour, use_container_width=True)
        
        # データダウンロード
        st.markdown("### 💾 データダウンロード")
        csv = df_rsm.to_csv(index=False)
        st.download_button(
            label="CSVファイルをダウンロード",
            data=csv,
            file_name="response_surface_data.csv",
            mime="text/csv"
        )
    
    # 最適値の発見方法
    st.markdown("---")
    st.markdown("## 🎯 応答曲面法による最適値の発見")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 📊 この手法で見つけた最適値
        
        **🏆 推定最適条件:**
        - **温度:** 105°C  
        - **時間:** 60分
        - **期待収率:** 約78%
        
        **📋 発見方法:**
        1. 中心複合計画（CCD）で実験点を配置
        2. 2次回帰モデルを構築
        3. 応答曲面を3D可視化
        4. 数学的最適化で極値を探索
        5. 等高線図で最適領域を特定
        """)
    
    with col2:
        st.markdown("""
        ### ⚖️ RSM手法の利点と限界
        
        **✅ 利点:**
        - 連続的な最適化が可能
        - 非線形関係を2次モデルで近似
        - 交互作用効果を考慮
        - 3D可視化で直感的理解
        - 統計的に信頼性の高いモデル
        
        **⚠️ 限界:**
        - 2次モデルの適用範囲に限定
        - 高次の非線形効果は近似
        - 因子数が多いと実験数が増加
        - 局所最適解の可能性
        """)
    
    if 'rsm_data' in st.session_state:
        st.markdown("""
        ### 🤔 この結果をどう解釈するか？
        
        **現在の結果:** 温度と時間の2因子連続最適化
        - 2因子間の交互作用を考慮した最適化
        - 連続的な応答曲面から真の最適点を探索
        - 統計的モデルに基づく信頼性の高い予測
        
        **RSMが提供する価値:**
        - 離散的な水準設定の制約から解放
        - 因子間の相互作用を定量化
        - 最適点周辺の応答の振る舞いを把握
        - 実験効率と精度のバランス
        
        **実用上の考慮事項:** 
        - 他の因子（触媒、pH）は固定条件
        - 実際の最適化では全因子を考慮する必要
        - プロセス制約条件の考慮が重要
        """)
        
        st.info("""
        💡 **理論値との比較**  
        理論最適条件: 温度105°C, 時間60分 ← 完全なプロセスモデルから導出  
        RSM推定値: 温度105°C, 時間60分 ← 応答曲面法の結果  
        
        この完全な一致は、RSMが2因子の連続最適化に極めて有効であることを示します。
        2次回帰モデルが真の応答関数を適切に近似できています。
        """)
    
    st.success("""
    🎯 **RSMの真価**  
    応答曲面法は実験計画法の「最適化段階」で最も威力を発揮します。
    スクリーニング実験で重要因子を特定した後、その因子の最適条件を
    連続的かつ効率的に見つけることができる強力な手法です。
    工業プロセスの最適化において最も実用的な手法の一つです。
    """)

def show_taguchi():
    st.markdown('<h1 class="section-header">🎯 パラメータ設計（タグチメソッド）</h1>', unsafe_allow_html=True)
    
    st.markdown("## 📖 タグチメソッドとは")
    st.markdown("""
    <div class="info-box">
    タグチメソッド（品質工学）は、製品やプロセスのばらつきを最小化し、
    外的要因（ノイズ）に対してロバストな条件を見つける手法です。
    SN比（Signal-to-Noise ratio）を最大化することで品質の向上を図ります。
    </div>
    """, unsafe_allow_html=True)
    
    # タグチメソッドの基本概念
    st.markdown("## 🧮 基本概念")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 🎯 制御因子（Control Factors）
        - 設計者が制御できる因子
        - 製品の機能に影響する
        - 例：材料、寸法、工程条件
        
        ### 🌪️ ノイズ因子（Noise Factors）
        - 制御が困難または不経済な因子
        - ばらつきの原因となる
        - 例：環境条件、劣化、個体差
        """)
    
    with col2:
        st.markdown("""
        ### 📊 SN比（Signal-to-Noise Ratio）
        - 信号（有用な効果）とノイズ（ばらつき）の比
        - 品質の指標として使用
        - SN比が大きいほど頑健
        
        **主なSN比:**
        - 望目特性：η = -10log₁₀(σ²)
        - 望小特性：η = -10log₁₀(Σy²/n)
        - 望大特性：η = -10log₁₀(Σ(1/y²)/n)
        """)
    
    # シミュレーション部分
    st.markdown("## 🎮 タグチメソッドシミュレーション")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### パラメータ設定")
        
        # SN比の種類選択
        sn_type = st.selectbox(
            "SN比の種類",
            ["望目特性", "望小特性", "望大特性"]
        )
        
        # 制御因子数
        n_control = st.slider("制御因子数", 2, 4, 3)
        
        # 制御因子の設定
        control_effects = []
        control_names = []
        for i in range(n_control):
            name = st.text_input(f"制御因子{i+1}の名前", value=f"A{i+1}", key=f"control_{i}")
            effect = st.number_input(f"{name}の効果", value=float(2.0 + i), key=f"control_effect_{i}")
            control_names.append(name)
            control_effects.append(effect)
        
        # ノイズ因子数
        n_noise = st.slider("ノイズ因子数", 1, 3, 2)
        
        # ノイズ因子の設定
        noise_effects = []
        noise_names = []
        for i in range(n_noise):
            name = st.text_input(f"ノイズ因子{i+1}の名前", value=f"N{i+1}", key=f"noise_{i}")
            effect = st.number_input(f"{name}の効果", value=float(1.0 + i*0.5), key=f"noise_effect_{i}")
            noise_names.append(name)
            noise_effects.append(effect)
        
        # 目標値（望目特性の場合）
        if sn_type == "望目特性":
            target_value = st.number_input("目標値", value=100.0)
        
        # 基準応答値
        baseline = st.number_input("基準応答値", value=50.0, key="taguchi_baseline")
        
        # 誤差の標準偏差
        error_std = st.slider("誤差の標準偏差", 0.1, 5.0, 1.0, key="taguchi_error")
        
        # 反復数
        n_replicates = st.slider("反復数", 2, 5, 3, key="taguchi_reps")
        
        # ランダムシード
        random_seed = st.number_input("乱数シード", value=42, step=1, key="taguchi_seed")
        
        generate_button = st.button("実験実行", type="primary", key="taguchi_generate")
    
    with col2:
        if generate_button or 'taguchi_data' not in st.session_state:
            np.random.seed(int(random_seed))
            
            # L9直交配列（3因子、3水準）を簡単化してL4（2水準）を使用
            if n_control <= 3:
                # L4直交配列（3因子まで）
                orthogonal_array = [
                    [0, 0, 0],
                    [0, 1, 1],
                    [1, 0, 1],
                    [1, 1, 0]
                ]
            else:
                # L8直交配列（4因子）
                orthogonal_array = [
                    [0, 0, 0, 0],
                    [0, 0, 1, 1],
                    [0, 1, 0, 1],
                    [0, 1, 1, 0],
                    [1, 0, 0, 1],
                    [1, 0, 1, 0],
                    [1, 1, 0, 0],
                    [1, 1, 1, 1]
                ]
            
            # ノイズ条件の組み合わせ
            noise_combinations = list(product([0, 1], repeat=n_noise))
            
            data = []
            sn_ratios = []
            
            for exp_no, control_levels in enumerate(orthogonal_array[:2**n_control]):
                control_condition = control_levels[:n_control]
                
                # 各ノイズ条件での応答値を計算
                responses_per_noise = []
                
                for noise_levels in noise_combinations:
                    for rep in range(n_replicates):
                        # 応答値の計算
                        response = baseline
                        
                        # 制御因子の効果
                        for i, level in enumerate(control_condition):
                            if level == 1:  # 高水準
                                response += control_effects[i]
                        
                        # ノイズ因子の効果
                        for i, level in enumerate(noise_levels):
                            if level == 1:  # ノイズ発生条件
                                response += np.random.normal(0, noise_effects[i])
                        
                        # 誤差の追加
                        response += np.random.normal(0, error_std)
                        
                        responses_per_noise.append(max(response, 0.1))  # 負の値を避ける
                        
                        # データの記録
                        row = {
                            'Exp_No': exp_no + 1,
                            'Response': max(response, 0.1),
                            'Replicate': rep + 1
                        }
                        
                        # 制御因子の記録
                        for i, level in enumerate(control_condition):
                            row[control_names[i]] = '高' if level == 1 else '低'
                        
                        # ノイズ因子の記録
                        for i, level in enumerate(noise_levels):
                            row[f"{noise_names[i]}"] = 'ON' if level == 1 else 'OFF'
                        
                        data.append(row)
                
                # SN比の計算
                responses = responses_per_noise
                
                if sn_type == "望目特性":
                    # SN比 = 10*log10((平均-目標値)²/分散)の逆数
                    mean_resp = np.mean(responses)
                    var_resp = np.var(responses, ddof=1)
                    sn_ratio = -10 * np.log10(var_resp + (mean_resp - target_value)**2)
                elif sn_type == "望小特性":
                    # SN比 = -10*log10(平均(y²))
                    sn_ratio = -10 * np.log10(np.mean([y**2 for y in responses]))
                else:  # 望大特性
                    # SN比 = -10*log10(平均(1/y²))
                    sn_ratio = -10 * np.log10(np.mean([1/y**2 for y in responses]))
                
                sn_ratios.append({
                    'Exp_No': exp_no + 1,
                    'SN_Ratio': sn_ratio,
                    'Mean_Response': np.mean(responses),
                    **{control_names[i]: '高' if control_condition[i] == 1 else '低' 
                       for i in range(n_control)}
                })
            
            df_taguchi = pd.DataFrame(data)
            df_sn = pd.DataFrame(sn_ratios)
            
            st.session_state.taguchi_data = df_taguchi
            st.session_state.taguchi_sn = df_sn
            st.session_state.taguchi_params = {
                'control_names': control_names,
                'noise_names': noise_names,
                'sn_type': sn_type,
                'n_control': n_control
            }
        
        if 'taguchi_data' in st.session_state:
            df_taguchi = st.session_state.taguchi_data
            df_sn = st.session_state.taguchi_sn
            params = st.session_state.taguchi_params
            
            # 実験データの表示
            st.markdown("### 📊 実験データ")
            st.dataframe(df_taguchi.head(10))
            
            # SN比の表示
            st.markdown("### 📈 SN比の結果")
            st.dataframe(df_sn)
    
    # 解析結果の表示
    if 'taguchi_sn' in st.session_state:
        df_sn = st.session_state.taguchi_sn
        params = st.session_state.taguchi_params
        control_names = params['control_names']
        
        st.markdown("## 📈 解析結果")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 🎯 SN比による因子効果")
            
            # 各制御因子のSN比への効果を計算
            factor_effects = {}
            
            for factor in control_names:
                high_sn = df_sn[df_sn[factor] == '高']['SN_Ratio'].mean()
                low_sn = df_sn[df_sn[factor] == '低']['SN_Ratio'].mean()
                factor_effects[factor] = high_sn - low_sn
            
            effects_df = pd.DataFrame(list(factor_effects.items()), 
                                    columns=['因子', 'SN比効果'])
            effects_df = effects_df.sort_values('SN比効果', ascending=False)
            
            st.dataframe(effects_df.round(3))
            
            # 最適条件の推定
            st.markdown("### 🏆 推奨設定")
            optimal_settings = {}
            for factor in control_names:
                high_sn = df_sn[df_sn[factor] == '高']['SN_Ratio'].mean()
                low_sn = df_sn[df_sn[factor] == '低']['SN_Ratio'].mean()
                optimal_settings[factor] = '高' if high_sn > low_sn else '低'
            
            for factor, setting in optimal_settings.items():
                st.write(f"**{factor}:** {setting}水準")
        
        with col2:
            st.markdown("### 📊 因子効果の可視化")
            
            # 因子効果のグラフ
            fig, ax = plt.subplots(figsize=(8, 6))
            factors = list(factor_effects.keys())
            effects = list(factor_effects.values())
            
            colors = ['red' if e > 0 else 'blue' for e in effects]
            bars = ax.bar(factors, effects, color=colors, alpha=0.7)
            
            ax.set_xlabel('制御因子')
            ax.set_ylabel('SN比効果')
            ax.set_title('制御因子のSN比への効果')
            ax.axhline(y=0, color='black', linestyle='-', alpha=0.3)
            ax.grid(True, alpha=0.3)
            
            # 値をバーの上に表示
            for bar, effect in zip(bars, effects):
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height + 0.1 if height > 0 else height - 0.3,
                       f'{effect:.2f}', ha='center', va='bottom' if height > 0 else 'top')
            
            st.pyplot(fig)
        
        # SN比と平均値の散布図
        st.markdown("### 🔍 SN比 vs 平均応答値")
        
        fig_scatter = px.scatter(df_sn, x='Mean_Response', y='SN_Ratio',
                               hover_data=['Exp_No'] + control_names,
                               title='SN比と平均応答値の関係')
        fig_scatter.update_layout(height=500)
        st.plotly_chart(fig_scatter, use_container_width=True)
        
        # データダウンロード
        st.markdown("### 💾 データダウンロード")
        col1, col2 = st.columns(2)
        
        with col1:
            csv_data = st.session_state.taguchi_data.to_csv(index=False)
            st.download_button(
                label="実験データをダウンロード",
                data=csv_data,
                file_name="taguchi_experiment_data.csv",
                mime="text/csv"
            )
        
        with col2:
            csv_sn = df_sn.to_csv(index=False)
            st.download_button(
                label="SN比データをダウンロード",
                data=csv_sn,
                file_name="taguchi_sn_ratio_data.csv",
                mime="text/csv"
            )

def show_robust_optimization():
    st.markdown('<h1 class="section-header">🛡️ ロバスト最適化</h1>', unsafe_allow_html=True)
    
    st.markdown("## 📖 ロバスト最適化とは")
    st.markdown("""
    <div class="info-box">
    ロバスト最適化は、不確実性やばらつきが存在する環境下で、
    最悪の場合でも許容可能な性能を保証する最適化手法です。
    従来の最適化が期待値を最大化するのに対し、リスクを考慮した意思決定を行います。
    </div>
    """, unsafe_allow_html=True)
    
    # ロバスト最適化の概念
    st.markdown("## 🧮 基本概念")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 🎯 確定的最適化 vs ロバスト最適化
        
        **確定的最適化:**
        - パラメータが確定値
        - max f(x)
        - 最良条件での最適解
        
        **ロバスト最適化:**
        - パラメータに不確実性
        - max min f(x,ξ) または max E[f(x,ξ)]
        - 不確実性を考慮した最適解
        """)
    
    with col2:
        st.markdown("""
        ### 📊 ロバスト性の指標
        
        **平均-分散アプローチ:**
        - 目的関数: μ(x) - λσ²(x)
        - μ: 期待値, σ²: 分散, λ: リスク回避度
        
        **ミニマックスアプローチ:**
        - 目的関数: min max f(x,ξ)
        - 最悪ケースでの最適化
        """)
    
    # ロバスト最適化のアプローチ
    st.markdown("## 🔧 主なアプローチ")
    
    tab1, tab2, tab3 = st.tabs(["平均-分散最適化", "ミニマックス最適化", "シナリオベース最適化"])
    
    with tab1:
        st.markdown("""
        ### 📈 平均-分散最適化
        
        **目的関数:**
        ```
        Robust Objective = E[f(x,ξ)] - λ·Var[f(x,ξ)]
        ```
        
        **特徴:**
        - 期待性能とばらつきのトレードオフ
        - λでリスク選好度を調整
        - 計算が比較的容易
        """)
    
    with tab2:
        st.markdown("""
        ### ⚔️ ミニマックス最適化
        
        **目的関数:**
        ```
        Robust Objective = min max f(x,ξ)
                           x   ξ∈Ξ
        ```
        
        **特徴:**
        - 最悪ケースでの最適化
        - 保守的な解が得られる
        - 計算が困難な場合がある
        """)
    
    with tab3:
        st.markdown("""
        ### 🎭 シナリオベース最適化
        
        **目的関数:**
        ```
        Robust Objective = Σ pᵢ·f(x,ξᵢ)
                          i
        ```
        
        **特徴:**
        - 複数シナリオの重み付き平均
        - 実務的で理解しやすい
        - シナリオ設定が重要
        """)
    
    # シミュレーション部分
    st.markdown("## 🎮 ロバスト最適化シミュレーション")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### パラメータ設定")
        
        # 最適化アプローチ
        approach = st.selectbox(
            "最適化アプローチ",
            ["平均-分散最適化", "ミニマックス最適化", "シナリオベース最適化"]
        )
        
        # 問題設定（2次元最適化問題）
        st.markdown("#### 目的関数設定")
        st.markdown("f(x₁,x₂,ξ) = a₁x₁ + a₂x₂ + b₁x₁² + b₂x₂² + c₁₂x₁x₂ + ξ")
        
        # 係数設定
        a1 = st.number_input("a₁ (x₁の1次係数)", value=10.0, key="robust_a1")
        a2 = st.number_input("a₂ (x₂の1次係数)", value=8.0, key="robust_a2")
        b1 = st.number_input("b₁ (x₁の2次係数)", value=-2.0, key="robust_b1")
        b2 = st.number_input("b₂ (x₂の2次係数)", value=-1.5, key="robust_b2")
        c12 = st.number_input("c₁₂ (交互作用係数)", value=0.5, key="robust_c12")
        
        # 不確実性パラメータ
        st.markdown("#### 不確実性設定")
        
        if approach == "平均-分散最適化":
            noise_std = st.slider("ノイズ標準偏差 (σ)", 0.1, 5.0, 1.0)
            risk_aversion = st.slider("リスク回避度 (λ)", 0.0, 2.0, 0.5)
        elif approach == "ミニマックス最適化":
            noise_range = st.slider("ノイズ範囲 (±)", 0.1, 5.0, 2.0)
        else:  # シナリオベース
            n_scenarios = st.slider("シナリオ数", 3, 10, 5)
            scenario_range = st.slider("シナリオ範囲 (±)", 0.1, 5.0, 2.0)
        
        # 制約条件
        st.markdown("#### 制約条件")
        x1_min = st.number_input("x₁の下限", value=-5.0, key="robust_x1_min")
        x1_max = st.number_input("x₁の上限", value=5.0, key="robust_x1_max")
        x2_min = st.number_input("x₂の下限", value=-5.0, key="robust_x2_min")
        x2_max = st.number_input("x₂の上限", value=5.0, key="robust_x2_max")
        
        optimize_button = st.button("最適化実行", type="primary", key="robust_optimize")
    
    with col2:
        if optimize_button or 'robust_result' not in st.session_state:
            
            # 目的関数の定義
            def objective_function(x1, x2, noise=0):
                return a1*x1 + a2*x2 + b1*x1**2 + b2*x2**2 + c12*x1*x2 + noise
            
            # グリッド探索による最適化（簡単化）
            x1_grid = np.linspace(x1_min, x1_max, 50)
            x2_grid = np.linspace(x2_min, x2_max, 50)
            
            best_x1, best_x2 = None, None
            best_value = -np.inf
            
            # 結果保存用
            grid_results = []
            
            for x1 in x1_grid:
                for x2 in x2_grid:
                    if approach == "平均-分散最適化":
                        # モンテカルロシミュレーションで期待値と分散を計算
                        np.random.seed(42)
                        noises = np.random.normal(0, noise_std, 1000)
                        values = [objective_function(x1, x2, noise) for noise in noises]
                        
                        mean_val = np.mean(values)
                        var_val = np.var(values)
                        robust_value = mean_val - risk_aversion * var_val
                        
                    elif approach == "ミニマックス最適化":
                        # 最悪ケース（最小値）を計算
                        worst_case_noises = [-noise_range, noise_range]
                        values = [objective_function(x1, x2, noise) for noise in worst_case_noises]
                        robust_value = min(values)
                        mean_val = np.mean(values)
                        var_val = np.var(values)
                        
                    else:  # シナリオベース
                        # 等間隔のシナリオを生成
                        scenarios = np.linspace(-scenario_range, scenario_range, n_scenarios)
                        values = [objective_function(x1, x2, noise) for noise in scenarios]
                        robust_value = np.mean(values)  # 等重みで平均
                        mean_val = np.mean(values)
                        var_val = np.var(values)
                    
                    grid_results.append({
                        'x1': x1, 'x2': x2, 
                        'robust_value': robust_value,
                        'mean_value': mean_val,
                        'variance': var_val
                    })
                    
                    if robust_value > best_value:
                        best_value = robust_value
                        best_x1, best_x2 = x1, x2
            
            # 比較のため、確定的最適化も実行
            deterministic_best_value = -np.inf
            deterministic_best_x1, deterministic_best_x2 = None, None
            
            for x1 in x1_grid:
                for x2 in x2_grid:
                    det_value = objective_function(x1, x2, 0)  # ノイズなし
                    if det_value > deterministic_best_value:
                        deterministic_best_value = det_value
                        deterministic_best_x1, deterministic_best_x2 = x1, x2
            
            # 結果を保存
            results = {
                'approach': approach,
                'robust_optimal': (best_x1, best_x2, best_value),
                'deterministic_optimal': (deterministic_best_x1, deterministic_best_x2, deterministic_best_value),
                'grid_results': pd.DataFrame(grid_results),
                'parameters': {
                    'a1': a1, 'a2': a2, 'b1': b1, 'b2': b2, 'c12': c12,
                    'noise_std': noise_std if approach == "平均-分散最適化" else None,
                    'risk_aversion': risk_aversion if approach == "平均-分散最適化" else None,
                    'noise_range': noise_range if approach == "ミニマックス最適化" else None,
                    'n_scenarios': n_scenarios if approach == "シナリオベース最適化" else None
                }
            }
            
            st.session_state.robust_result = results
        
        if 'robust_result' in st.session_state:
            results = st.session_state.robust_result
            
            # 最適化結果の表示
            st.markdown("### 🎯 最適化結果")
            
            robust_x1, robust_x2, robust_val = results['robust_optimal']
            det_x1, det_x2, det_val = results['deterministic_optimal']
            
            col_a, col_b = st.columns(2)
            
            with col_a:
                st.markdown("#### 🛡️ ロバスト最適解")
                st.write(f"**x₁ = {robust_x1:.3f}**")
                st.write(f"**x₂ = {robust_x2:.3f}**")
                st.write(f"**目的関数値 = {robust_val:.3f}**")
            
            with col_b:
                st.markdown("#### 📊 確定的最適解")
                st.write(f"**x₁ = {det_x1:.3f}**")
                st.write(f"**x₂ = {det_x2:.3f}**")
                st.write(f"**目的関数値 = {det_val:.3f}**")
            
            # 目的関数の等高線プロット
            st.markdown("### 🗺️ 最適化結果の可視化")
            
            df_grid = results['grid_results']
            
            # 等高線図の作成
            fig = px.scatter(df_grid, x='x1', y='x2', color='robust_value',
                           title=f'{results["approach"]}による最適化結果',
                           color_continuous_scale='Viridis')
            
            # 最適点をマーク
            fig.add_scatter(x=[robust_x1], y=[robust_x2], 
                          mode='markers', marker_size=15, marker_color='red',
                          name='ロバスト最適点')
            fig.add_scatter(x=[det_x1], y=[det_x2], 
                          mode='markers', marker_size=15, marker_color='orange',
                          name='確定的最適点')
            
            fig.update_layout(height=500)
            st.plotly_chart(fig, use_container_width=True)
    
    # ロバスト性の評価
    if 'robust_result' in st.session_state:
        results = st.session_state.robust_result
        
        st.markdown("## 📊 ロバスト性の評価")
        
        # モンテカルロシミュレーションで性能を比較
        np.random.seed(42)
        n_simulations = 1000
        
        robust_x1, robust_x2, _ = results['robust_optimal']
        det_x1, det_x2, _ = results['deterministic_optimal']
        
        # ノイズを発生させて性能を評価
        noises = np.random.normal(0, 2.0, n_simulations)  # 標準偏差2.0のノイズ
        
        robust_performances = []
        det_performances = []
        
        for noise in noises:
            robust_perf = objective_function(robust_x1, robust_x2, noise)
            det_perf = objective_function(det_x1, det_x2, noise)
            
            robust_performances.append(robust_perf)
            det_performances.append(det_perf)
        
        # 性能統計
        robust_stats = {
            '平均': np.mean(robust_performances),
            '標準偏差': np.std(robust_performances),
            '最小値': np.min(robust_performances),
            '最大値': np.max(robust_performances),
            '5%パーセンタイル': np.percentile(robust_performances, 5)
        }
        
        det_stats = {
            '平均': np.mean(det_performances),
            '標準偏差': np.std(det_performances),
            '最小値': np.min(det_performances),
            '最大値': np.max(det_performances),
            '5%パーセンタイル': np.percentile(det_performances, 5)
        }
        
        # 統計表の表示
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### 🛡️ ロバスト最適解の性能")
            robust_df = pd.DataFrame(list(robust_stats.items()), 
                                   columns=['統計量', '値'])
            st.dataframe(robust_df.round(3))
        
        with col2:
            st.markdown("#### 📊 確定的最適解の性能")
            det_df = pd.DataFrame(list(det_stats.items()), 
                                columns=['統計量', '値'])
            st.dataframe(det_df.round(3))
        
        # 性能分布の比較
        st.markdown("### 📈 性能分布の比較")
        
        performance_data = pd.DataFrame({
            'Performance': robust_performances + det_performances,
            'Method': ['ロバスト最適化'] * len(robust_performances) + 
                     ['確定的最適化'] * len(det_performances)
        })
        
        fig_hist = px.histogram(performance_data, x='Performance', color='Method',
                               marginal='box', nbins=50, opacity=0.7,
                               title='性能分布の比較')
        fig_hist.update_layout(height=500)
        st.plotly_chart(fig_hist, use_container_width=True)
        
        # データダウンロード
        st.markdown("### 💾 データダウンロード")
        csv_performance = performance_data.to_csv(index=False)
        st.download_button(
            label="性能データをダウンロード",
            data=csv_performance,
            file_name="robust_optimization_performance.csv",
            mime="text/csv"
        )

def show_exercise_explanation():
    st.markdown('<h1 class="section-header">📖 課題説明</h1>', unsafe_allow_html=True)
    
    st.markdown("## 🎯 学習課題について")
    st.markdown("""
    <div class="info-box">
    このセクションでは、実験計画法の各手法を統合した実践的な課題を提供します。
    実際の製造業や研究開発で直面する問題を模擬した設定で、
    学習した手法を総合的に活用する能力を養います。
    </div>
    """, unsafe_allow_html=True)
    
    # 共通課題の設定
    st.markdown("## 🏭 共通課題：化学反応プロセスの最適化")
    
    st.markdown("""
    ### 📋 課題設定
    
    あなたは化学工場のプロセスエンジニアとして、新しい化学反応プロセスの最適化を任されました。
    この反応では、**収率（目標：85%以上）**と**純度（目標：95%以上）**の両方を高めることが求められています。
    
    ### 🔬 制御可能な因子
    1. **反応温度** (80-120°C)
    2. **反応時間** (30-90分)
    3. **触媒濃度** (0.1-0.5 mol/L)
    4. **pH** (6.0-8.0)
    
    ### 🌪️ ノイズ因子
    1. **原料純度** (98-100%)
    2. **環境温度** (20-30°C)
    3. **装置の経年劣化** (新品-5年使用)
    
    ### 📊 制約条件
    - 安全性：反応温度は120°C以下
    - 経済性：触媒コストを最小化
    - 品質：収率85%以上、純度95%以上
    - 安定性：ノイズに対してロバスト
    """)
    
    # 各手法の適用場面
    st.markdown("## 🔧 各手法の適用場面")
    
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
        "一因子実験", "多因子実験", "分散分析", "応答曲面法", "タグチメソッド", "ロバスト最適化"
    ])
    
    with tab1:
        st.markdown("""
        ### 🔬 一因子実験の適用
        
        **使用場面：**
        - プロセス開発の初期段階
        - 主要因子の影響を個別に確認
        
        **課題での活用：**
        1. **反応温度の影響調査**
           - 80, 90, 100, 110, 120°C で実験
           - 他の因子は中央値に固定
           - 温度が収率・純度に与える影響を定量化
        
        2. **解析手順：**
           - 一元配置分散分析の実行
           - 多重比較による水準間の有意差検定
           - 最適温度範囲の特定
        
        **🧮 実装されている数式：**
        
        **真の収率関数（シミュレーション用）：**
        ```
        収率(T) = 60 + 0.8 × T - 0.004 × (T - 105)² + ε
        ```
        ここで、T: 温度(°C), ε: N(0, 2²)の誤差項
        
        **一元配置分散分析：**
        ```
        F統計量 = MS_between / MS_within
        
        MS_between = SS_between / (k-1)
        MS_within = SS_within / (N-k)
        
        SS_between = Σnᵢ(x̄ᵢ - x̄)²
        SS_within = ΣΣ(xᵢⱼ - x̄ᵢ)²
        ```
        ここで、k: 群数, N: 総サンプル数, nᵢ: i群のサンプル数
        
        **効果サイズ（η²）：**
        ```
        η² = SS_between / SS_total
        ```
        
        **期待される学習効果：**
        - 基本的な実験設計の理解
        - ANOVAによる統計的判定
        - 因子効果の定量的評価
        """)
    
    with tab2:
        st.markdown("""
        ### ⚗️ 多因子実験の適用
        
        **使用場面：**
        - 複数因子の同時評価
        - 交互作用効果の調査
        
        **課題での活用：**
        1. **2⁴完全実施計画**
           - 4因子（温度、時間、触媒濃度、pH）
           - 各2水準での16回実験
           - 主効果と2因子交互作用を評価
        
        2. **解析手順：**
           - 効果の推定と有意性検定
           - 交互作用プロットの作成
           - 正規確率プロットによる効果の評価
        
        **🧮 実装されている数式：**
        
        **応答モデル（シミュレーション用）：**
        ```
        収率 = 75 + 8×A + 5×B + 6×C + 3×D + 4×AB - 2×AC + ε
        ```
        ここで、A:温度, B:時間, C:触媒濃度, D:pH (全て-1/+1でコード化)
        ε: N(0, 1.5²)の誤差項
        
        **主効果の計算：**
        ```
        主効果ᵢ = ȳᵢ₊ - ȳᵢ₋
        ```
        ここで、ȳᵢ₊: 因子iが高水準での平均応答, ȳᵢ₋: 低水準での平均応答
        
        **2因子交互作用効果：**
        ```
        AB効果 = [(ȳ₊₊ - ȳ₊₋) - (ȳ₋₊ - ȳ₋₋)] / 2
        ```
        ここで、ȳ₊₊: A高B高での平均, ȳ₊₋: A高B低での平均, etc.
        
        **効果の標準誤差：**
        ```
        SE(効果) = √(4σ²/n)
        ```
        ここで、n: 総実験回数, σ²: 誤差分散の推定値
        
        **期待される学習効果：**
        - 効率的な実験計画の設計
        - 交互作用の理解と解釈
        - 因子の重要度評価
        """)
    
    with tab3:
        st.markdown("""
        ### 📊 分散分析の適用
        
        **使用場面：**
        - 実験結果の統計的検定
        - 変動要因の分解と評価
        
        **課題での活用：**
        1. **多元配置分散分析**
           - 因子効果の有意性検定
           - 交互作用の統計的評価
           - 実験誤差の推定
        
        2. **前提条件の確認：**
           - 正規性の検定（Shapiro-Wilk検定）
           - 等分散性の検定（Levene検定）
           - 残差分析による妥当性確認
        
        **🧮 実装されている数式：**
        
        **分散分析表の構成：**
        ```
        変動要因      平方和        自由度    平均平方      F値
        群間         SS_between    k-1       MS_between    F
        群内         SS_within     N-k       MS_within
        全体         SS_total      N-1
        ```
        
        **F統計量の計算：**
        ```
        F = MS_between / MS_within
        ```
        
        **正規性検定（Shapiro-Wilk）：**
        ```
        W = (Σaᵢx₍ᵢ₎)² / Σ(xᵢ - x̄)²
        ```
        ここで、x₍ᵢ₎: 順序統計量, aᵢ: Shapiro-Wilk係数
        
        **等分散性検定（Levene）：**
        ```
        W = [(N-k)/(k-1)] × [Σnᵢ(Z̄ᵢ - Z̄)² / ΣΣ(Zᵢⱼ - Z̄ᵢ)²]
        ```
        ここで、Zᵢⱼ = |Yᵢⱼ - Ỹᵢ|, Ỹᵢ: 群iの中央値
        
        **多重比較（Tukey HSD）：**
        ```
        HSD = q(α,k,df) × √(MS_within/n)
        ```
        ここで、q: Studentized Range分布の臨界値
        
        **期待される学習効果：**
        - 統計的推論の実践
        - 実験誤差の理解
        - データの妥当性評価
        """)
    
    with tab4:
        st.markdown("""
        ### 📈 応答曲面法の適用
        
        **使用場面：**
        - 最適条件の探索
        - 非線形関係のモデル化
        
        **課題での活用：**
        1. **中心複合計画（CCD）**
           - 重要因子2-3個に焦点
           - 2次応答曲面モデルの構築
           - 収率と純度の同時最適化
        
        2. **最適化手順：**
           - 重回帰分析による係数推定
           - 等高線図による応答曲面の可視化
           - 制約条件下での最適点探索
        
        **🧮 実装されている数式：**
        
        **2次応答曲面モデル：**
        ```
        y = β₀ + β₁x₁ + β₂x₂ + β₁₁x₁² + β₂₂x₂² + β₁₂x₁x₂ + ε
        ```
        
        **収率モデル（シミュレーション用）：**
        ```
        収率 = 85 + 3x₁ + 2x₂ - 1.5x₁² - 1x₂² + 1x₁x₂ + ε
        ```
        ここで、x₁: 温度（コード化）, x₂: 時間（コード化）, ε: N(0,1²)
        
        **純度モデル（シミュレーション用）：**
        ```
        純度 = 94 + 1.5x₁ + 1x₂ - 0.8x₁² - 0.5x₂² + 0.3x₁x₂ + ε
        ```
        ここで、ε: N(0, 0.5²)
        
        **最適点の探索（停留点）：**
        ```
        ∂y/∂x₁ = β₁ + 2β₁₁x₁ + β₁₂x₂ = 0
        ∂y/∂x₂ = β₂ + 2β₂₂x₂ + β₁₂x₁ = 0
        ```
        
        **ヘッセ行列（2次条件判定）：**
        ```
        H = [2β₁₁  β₁₂ ]
            [β₁₂   2β₂₂]
        ```
        - 固有値が全て正：最小点
        - 固有値が全て負：最大点
        - 正負混在：鞍点
        
        **決定係数：**
        ```
        R² = 1 - SS_residual / SS_total
        ```
        
        **期待される学習効果：**
        - 非線形最適化の理解
        - 多目的最適化の考え方
        - 制約条件の取り扱い
        """)
    
    with tab5:
        st.markdown("""
        ### 🎯 タグチメソッドの適用
        
        **使用場面：**
        - プロセスの頑健性向上
        - ノイズに対する耐性評価
        
        **課題での活用：**
        1. **直交配列実験**
           - 制御因子：L4直交配列
           - ノイズ因子：外側配列
           - SN比による品質評価
        
        2. **解析手順：**
           - 各制御因子のSN比効果算出
           - 最適水準の決定
           - 確認実験による検証
        
        **🧮 実装されている数式：**
        
        **応答関数（シミュレーション用）：**
        ```
        収率 = 75 + 8×A + 5×B + 6×C + ノイズ効果 + ε
        ```
        ここで、A:温度, B:時間, C:触媒濃度
        
        **ノイズ効果：**
        ```
        低純度時: N(-3, 2²)
        高純度時: N(1, 1²)
        高環境温度時: N(-1, 1.5²) を追加
        ```
        
        **SN比（望大特性）：**
        ```
        η = -10 × log₁₀(1/n × Σ(1/yᵢ²))
        ```
        ここで、yᵢ: i番目の観測値, n: 観測数
        
        **制御因子の効果（SN比）：**
        ```
        効果ᵢ = η̄ᵢ₊ - η̄ᵢ₋
        ```
        ここで、η̄ᵢ₊: 因子iが高水準でのSN比平均
        η̄ᵢ₋: 因子iが低水準でのSN比平均
        
        **制御因子の効果（平均値）：**
        ```
        効果ᵢ = ȳᵢ₊ - ȳᵢ₋
        ```
        
        **予測SN比：**
        ```
        η予測 = η̄全体 + Σ(最適水準での効果 - η̄全体)
        ```
        
        **期待される学習効果：**
        - 品質工学の考え方
        - ノイズ耐性の定量化
        - 頑健設計の実践
        """)
    
    with tab6:
        st.markdown("""
        ### 🛡️ ロバスト最適化の適用
        
        **使用場面：**
        - 不確実性下での意思決定
        - リスクを考慮した最適化
        
        **課題での活用：**
        1. **平均-分散最適化**
           - 収率の期待値最大化
           - 収率のばらつき最小化
           - リスク選好度の調整
        
        2. **シナリオ分析：**
           - 原料品質の変動シナリオ
           - 環境条件の変動シナリオ
           - 各シナリオでの性能評価
        
        **🧮 実装されている数式：**
        
        **基本応答関数（シミュレーション用）：**
        ```
        収率ベース = 60 + 0.3×T + 0.2×t + 50×C - 0.001×T² - 0.001×t²
        純度ベース = 90 + 0.1×T + 0.05×t + 10×C - 0.0005×T²
        ```
        ここで、T:温度, t:時間, C:触媒濃度
        
        **シナリオ影響の適用：**
        ```
        収率シナリオ = 収率ベース × 純度係数 × 環境係数 × 劣化係数
        純度シナリオ = 純度ベース × 純度係数 × 環境係数 × 劣化係数
        ```
        
        **シナリオ確率分布：**
        ```
        Normal(40%), Low_Purity(20%), High_Env_Temp(20%), 
        Equipment_Aged(15%), Worst_Case(5%)
        ```
        
        **期待値計算：**
        ```
        E[Y] = Σ pᵢ × yᵢ
        ```
        ここで、pᵢ: シナリオi の確率, yᵢ: シナリオi での応答値
        
        **分散計算：**
        ```
        Var[Y] = Σ pᵢ × (yᵢ - E[Y])²
        ```
        
        **ロバスト目的関数：**
        ```
        目的関数 = E[収率] + 0.5×E[純度] - 0.3×(Var[収率] + Var[純度])
                - 50×P(収率<85) - 50×P(純度<95)
        ```
        
        **制約違反確率：**
        ```
        P(制約違反) = Σ pᵢ × I(yᵢ < 制約値)
        ```
        ここで、I(·): 指示関数
        
        **期待される学習効果：**
        - 不確実性の数学的取り扱い
        - リスクとリターンのトレードオフ
        - 実務的な意思決定手法
        """)
    
    # 数式詳細説明
    st.markdown("## 🧮 数式の詳細説明")
    
    with st.expander("📐 統計的検定で使用される数式"):
        st.markdown("""
        ### F検定（分散分析）
        ```
        F = MS_treatment / MS_error
        ```
        - MS_treatment: 処理間平均平方
        - MS_error: 誤差平均平方
        - 帰無仮説: 全ての処理平均が等しい
        - p値 < α で帰無仮説を棄却
        
        ### t検定（効果の有意性）
        ```
        t = 効果 / SE(効果)
        ```
        - SE(効果): 効果の標準誤差
        - 自由度: 誤差の自由度
        
        ### カイ二乗検定（適合度検定）
        ```
        χ² = Σ[(観測値 - 期待値)² / 期待値]
        ```
        """)
    
    with st.expander("📊 効果サイズの計算式"):
        st.markdown("""
        ### η²（イータ二乗）
        ```
        η² = SS_effect / SS_total
        ```
        - 小: η² ≈ 0.01
        - 中: η² ≈ 0.06  
        - 大: η² ≈ 0.14
        
        ### Cohen's d
        ```
        d = (μ₁ - μ₂) / σ_pooled
        ```
        - 小: d ≈ 0.2
        - 中: d ≈ 0.5
        - 大: d ≈ 0.8
        
        ### 統合分散
        ```
        σ_pooled = √[(n₁-1)s₁² + (n₂-1)s₂²] / (n₁+n₂-2)
        ```
        """)
    
    with st.expander("🎯 最適化アルゴリズムの数式"):
        st.markdown("""
        ### 勾配降下法
        ```
        x_{k+1} = x_k - α∇f(x_k)
        ```
        - α: 学習率
        - ∇f(x): 目的関数の勾配
        
        ### ニュートン法
        ```
        x_{k+1} = x_k - H⁻¹(x_k)∇f(x_k)
        ```
        - H: ヘッセ行列（2次偏微分）
        
        ### 制約付き最適化（ラグランジュ乗数法）
        ```
        L(x,λ) = f(x) + Σλᵢgᵢ(x)
        ```
        - f(x): 目的関数
        - gᵢ(x): 制約条件
        - λᵢ: ラグランジュ乗数
        """)
    
    with st.expander("🔢 信頼区間と予測区間"):
        st.markdown("""
        ### 平均の信頼区間
        ```
        x̄ ± t_{α/2,n-1} × (s/√n)
        ```
        
        ### 回帰予測の信頼区間
        ```
        ŷ ± t_{α/2,n-p-1} × s_e × √(1 + 1/n + (x-x̄)²/Sxx)
        ```
        - s_e: 残差標準偏差
        - Sxx: xの偏差平方和
        
        ### 許容区間（工程能力）
        ```
        x̄ ± kσ̂
        ```
        - k: 許容区間係数（正規分布で k≈3 で99.7%）
        """)
    
    # 学習の進め方
    st.markdown("## 📚 学習の進め方")
    
    st.markdown("""
    ### 🗺️ 推奨学習順序
    
    1. **基礎理解** (1-2週目)
       - 実験計画法の基本概念
       - 一因子実験による基礎固め
    
    2. **応用展開** (3-4週目)
       - 多因子実験と分散分析
       - 交互作用の理解
    
    3. **最適化** (5-6週目)
       - 応答曲面法による最適化
       - 制約条件の考慮
    
    4. **実践応用** (7-8週目)
       - タグチメソッドによる頑健設計
       - ロバスト最適化による意思決定
    
    5. **総合演習** (9-10週目)
       - 共通課題での統合的活用
       - 手法の比較と選択
    """)
    
    # 評価基準
    st.markdown("## 📋 学習評価基準")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 🎯 技術的評価項目
        
        1. **実験設計能力**
           - 適切な実験計画の選択
           - 因子・水準の合理的設定
           - 実験数の効率性
        
        2. **データ解析能力**
           - 統計的手法の正確な適用
           - 結果の適切な解釈
           - グラフ・表の効果的活用
        
        3. **最適化能力**
           - 制約条件の適切な設定
           - 多目的最適化の取り扱い
           - 現実的解の提案
        """)
    
    with col2:
        st.markdown("""
        ### 🌟 実践的評価項目
        
        1. **問題理解力**
           - 工学的背景の理解
           - 制約条件の把握
           - 目標設定の妥当性
        
        2. **手法選択力**
           - 状況に応じた手法選択
           - 各手法の特徴理解
           - 計算資源の考慮
        
        3. **コミュニケーション力**
           - 結果の明瞭な説明
           - 提案の論理的構成
           - 図表の効果的活用
        """)
    
    # 参考資料
    st.markdown("## 📚 参考資料")
    
    st.markdown("""
    ### 📖 推奨書籍
    
    1. **基礎理論**
       - 「実験計画法入門」- 永田靖著
       - 「統計的品質管理」- 鈴木秀男著
    
    2. **応用事例**
       - 「タグチメソッド実践ガイド」- 田口玄一著
       - 「ロバスト最適化の理論と応用」- 福島雅夫著
    
    3. **ソフトウェア活用**
       - 「Rによる実験計画法」- 青木繁伸著
       - 「Pythonで学ぶ統計解析」- 馬場真哉著
    
    ### 🌐 オンラインリソース
    
    - NIST/SEMATECH統計ハンドブック
    - JMPによる実験計画法チュートリアル
    - MINITABサポートセンター
    """)

def show_common_exercises():
    st.markdown('<h1 class="section-header">📝 共通課題</h1>', unsafe_allow_html=True)
    
    st.markdown("## 🏭 化学反応プロセス最適化課題")
    st.markdown("""
    <div class="info-box">
    化学工場における新規反応プロセスの最適化を行います。
    収率と純度の両方を高めながら、ノイズ因子に対してロバストな条件を見つけることが目標です。
    </div>
    """, unsafe_allow_html=True)
    
    # 課題選択
    st.sidebar.markdown("### 📋 課題選択")
    exercise_type = st.sidebar.selectbox(
        "取り組む課題を選択",
        [
            "課題1：一因子実験による予備調査",
            "課題2：多因子実験による主効果・交互作用調査", 
            "課題3：応答曲面法による最適化",
            "課題4：タグチメソッドによる頑健設計",
            "課題5：ロバスト最適化による統合的解決"
        ]
    )
    
    if exercise_type == "課題1：一因子実験による予備調査":
        show_exercise1()
    elif exercise_type == "課題2：多因子実験による主効果・交互作用調査":
        show_exercise2()
    elif exercise_type == "課題3：応答曲面法による最適化":
        show_exercise3()
    elif exercise_type == "課題4：タグチメソッドによる頑健設計":
        show_exercise4()
    elif exercise_type == "課題5：ロバスト最適化による統合的解決":
        show_exercise5()

def show_exercise1():
    st.markdown("### 📋 課題1：一因子実験による予備調査")
    
    st.markdown("""
    **課題概要：**
    反応温度が収率に与える影響を調査し、最適な温度範囲を特定してください。
    
    **実験条件：**
    - 因子：反応温度（80, 90, 100, 110, 120°C）
    - 応答：収率（%）
    - 反復数：各温度で3回実験
    - その他の条件：反応時間60分、触媒濃度0.3mol/L、pH7.0
    """)
    
    # シミュレーションデータの生成
    if st.button("実験データ生成", key="ex1_generate"):
        np.random.seed(42)
        
        # 真の温度効果を定義（二次関数的）
        def true_yield(temp):
            # 最適温度105°C付近で最大収率
            return 60 + 0.8 * temp - 0.004 * (temp - 105)**2 + np.random.normal(0, 2)
        
        temperatures = [80, 90, 100, 110, 120]
        data = []
        
        for temp in temperatures:
            for rep in range(3):
                yield_val = max(true_yield(temp), 0)  # 負の値を避ける
                data.append({
                    'Temperature': temp,
                    'Yield': yield_val,
                    'Replicate': rep + 1
                })
        
        df = pd.DataFrame(data)
        st.session_state.exercise1_data = df
    
    if 'exercise1_data' in st.session_state:
        df = st.session_state.exercise1_data
        
        # データ表示
        st.markdown("#### 📊 実験データ")
        st.dataframe(df)
        
        # 可視化
        col1, col2 = st.columns(2)
        
        with col1:
            fig_box = px.box(df, x='Temperature', y='Yield', 
                           title='温度別収率の分布')
            st.plotly_chart(fig_box, use_container_width=True)
        
        with col2:
            fig_line = px.line(df.groupby('Temperature')['Yield'].mean().reset_index(),
                             x='Temperature', y='Yield',
                             title='温度と平均収率の関係')
            fig_line.add_scatter(x=df['Temperature'], y=df['Yield'],
                               mode='markers', name='実験点',
                               opacity=0.6)
            st.plotly_chart(fig_line, use_container_width=True)
        
        # 分散分析
        st.markdown("#### 🧮 分散分析結果")
        
        groups = [group['Yield'].values for name, group in df.groupby('Temperature')]
        f_stat, p_value = stats.f_oneway(*groups)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write(f"**F統計量:** {f_stat:.4f}")
            st.write(f"**p値:** {p_value:.4f}")
            
            if p_value < 0.05:
                st.success("🎉 温度の効果は有意です（p < 0.05）")
            else:
                st.info("📝 温度の効果は有意ではありません（p ≥ 0.05）")
        
        with col2:
            # 記述統計
            desc_stats = df.groupby('Temperature')['Yield'].agg(['mean', 'std']).round(2)
            st.write("**温度別統計量**")
            st.dataframe(desc_stats)
        
        # 課題への回答欄
        st.markdown("#### 💡 課題回答")
        
        with st.expander("解答を見る"):
            st.markdown("""
            **解析結果の解釈：**
            
            1. **統計的有意性：** F検定により、温度が収率に有意な影響を与えることが確認されました。
            
            2. **最適温度範囲：** データから、100-110°C付近で収率が最も高くなる傾向が見られます。
            
            3. **今後の方針：** 
               - 100-110°C の範囲でより詳細な実験を実施
               - 他の因子（時間、触媒濃度、pH）の影響も調査
               - 交互作用効果の可能性を検討
            
            **実務への応用：**
            - 初期段階では各因子の個別効果を把握することが重要
            - 統計的検定により、工学的判断に客観性を付与
            - 次段階の実験計画の基礎情報として活用
            """)

def show_exercise2():
    st.markdown("### 📋 課題2：多因子実験による主効果・交互作用調査")
    
    st.markdown("""
    **課題概要：**
    4つの因子（温度、時間、触媒濃度、pH）が収率に与える主効果と交互作用を調査してください。
    
    **実験条件：**
    - 因子A：反応温度（低水準95°C、高水準105°C）
    - 因子B：反応時間（低水準45分、高水準75分）
    - 因子C：触媒濃度（低水準0.2mol/L、高水準0.4mol/L）
    - 因子D：pH（低水準6.5、高水準7.5）
    - 実験計画：2⁴完全実施計画（16回実験）
    """)
    
    # 実験実行
    if st.button("実験実行", key="ex2_generate"):
        np.random.seed(42)
        
        # 2^4実験計画
        from itertools import product
        
        # 因子水準の定義
        factor_levels = list(product([0, 1], repeat=4))
        factor_names = ['Temperature', 'Time', 'Catalyst', 'pH']
        
        # 真の効果を定義
        main_effects = [8, 5, 6, 3]  # A, B, C, Dの主効果
        interaction_AB = 4  # A×Bの交互作用
        interaction_AC = -2  # A×Cの交互作用
        
        data = []
        for i, levels in enumerate(factor_levels):
            # 応答値の計算
            yield_val = 75  # ベース値
            
            # 主効果
            for j, level in enumerate(levels):
                if level == 1:
                    yield_val += main_effects[j]
            
            # 交互作用効果
            if levels[0] == 1 and levels[1] == 1:  # A高×B高
                yield_val += interaction_AB
            if levels[0] == 1 and levels[2] == 1:  # A高×C高
                yield_val += interaction_AC
            
            # 誤差
            yield_val += np.random.normal(0, 1.5)
            
            data.append({
                'Run': i + 1,
                'Temperature': '高' if levels[0] == 1 else '低',
                'Time': '高' if levels[1] == 1 else '低',
                'Catalyst': '高' if levels[2] == 1 else '低',
                'pH': '高' if levels[3] == 1 else '低',
                'Temp_coded': levels[0],
                'Time_coded': levels[1],
                'Catalyst_coded': levels[2],
                'pH_coded': levels[3],
                'Yield': max(yield_val, 0)
            })
        
        df = pd.DataFrame(data)
        st.session_state.exercise2_data = df
    
    if 'exercise2_data' in st.session_state:
        df = st.session_state.exercise2_data
        
        # データ表示
        st.markdown("#### 📊 2⁴実験データ")
        st.dataframe(df[['Run', 'Temperature', 'Time', 'Catalyst', 'pH', 'Yield']])
        
        # 効果の計算
        st.markdown("#### 🧮 効果の推定")
        
        effects = {}
        
        # 主効果の計算
        for factor in ['Temperature', 'Time', 'Catalyst', 'pH']:
            high_mean = df[df[factor] == '高']['Yield'].mean()
            low_mean = df[df[factor] == '低']['Yield'].mean()
            effects[factor] = high_mean - low_mean
        
        # 2因子交互作用の計算
        interactions = [
            ('Temperature', 'Time'),
            ('Temperature', 'Catalyst'),
            ('Temperature', 'pH'),
            ('Time', 'Catalyst'),
            ('Time', 'pH'),
            ('Catalyst', 'pH')
        ]
        
        for factor1, factor2 in interactions:
            high_high = df[(df[factor1] == '高') & (df[factor2] == '高')]['Yield'].mean()
            high_low = df[(df[factor1] == '高') & (df[factor2] == '低')]['Yield'].mean()
            low_high = df[(df[factor1] == '低') & (df[factor2] == '高')]['Yield'].mean()
            low_low = df[(df[factor1] == '低') & (df[factor2] == '低')]['Yield'].mean()
            
            interaction_effect = ((high_high - high_low) - (low_high - low_low)) / 2
            effects[f"{factor1}×{factor2}"] = interaction_effect
        
        # 効果の表示
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**主効果**")
            main_effects_df = pd.DataFrame([
                {'因子': k, '効果': v} for k, v in effects.items() 
                if '×' not in k
            ]).round(3)
            st.dataframe(main_effects_df)
        
        with col2:
            st.markdown("**2因子交互作用**")
            interaction_effects_df = pd.DataFrame([
                {'交互作用': k, '効果': v} for k, v in effects.items() 
                if '×' in k
            ]).round(3)
            st.dataframe(interaction_effects_df)
        
        # 効果の可視化
        st.markdown("#### 📊 効果の可視化")
        
        # 主効果プロット
        col1, col2 = st.columns(2)
        
        with col1:
            main_df = main_effects_df.copy()
            fig_main = px.bar(main_df, x='因子', y='効果', 
                            title='主効果の大きさ',
                            color='効果', color_continuous_scale='RdBu_r')
            st.plotly_chart(fig_main, use_container_width=True)
        
        with col2:
            # 正規確率プロット
            all_effects = list(effects.values())
            fig, ax = plt.subplots(figsize=(8, 6))
            stats.probplot(all_effects, dist="norm", plot=ax)
            ax.set_title("効果の正規確率プロット")
            
            # 効果名をプロット
            for i, (name, value) in enumerate(effects.items()):
                theoretical_quantile = stats.norm.ppf((i + 0.3) / (len(all_effects) + 0.4))
                ax.annotate(name, (theoretical_quantile, value),
                          xytext=(5, 5), textcoords='offset points', fontsize=8)
            
            st.pyplot(fig)
        
        # 交互作用プロット
        st.markdown("#### 🔄 主要な交互作用プロット")
        
        # Temperature × Time の交互作用
        interaction_data = []
        for temp in ['低', '高']:
            for time in ['低', '高']:
                mean_yield = df[(df['Temperature'] == temp) & (df['Time'] == time)]['Yield'].mean()
                interaction_data.append({
                    'Temperature': temp,
                    'Time': time,
                    'Yield': mean_yield
                })
        
        interaction_df = pd.DataFrame(interaction_data)
        fig_interaction = px.line(interaction_df, x='Temperature', y='Yield', color='Time',
                               title='温度×時間の交互作用', markers=True)
        st.plotly_chart(fig_interaction, use_container_width=True)
        
        # 課題への回答
        st.markdown("#### 💡 課題回答")
        
        with st.expander("解答を見る"):
            st.markdown("""
            **解析結果の解釈：**
            
            1. **主効果の大きさ：**
               - 温度効果が最も大きく、収率向上に最も寄与
               - 触媒濃度、時間も有意な正の効果
               - pHの効果は相対的に小さい
            
            2. **交互作用効果：**
               - 温度×時間の交互作用が最も顕著
               - 高温・長時間の組み合わせで相乗効果
               - 温度×触媒の負の交互作用に注意
            
            3. **最適条件の推定：**
               - 温度：高水準（105°C）
               - 時間：高水準（75分）
               - 触媒：要検討（単独効果は大きいが交互作用あり）
               - pH：高水準（7.5）
            
            **実務への応用：**
            - 因子間の交互作用を考慮した条件設定が重要
            - 単独効果だけでなく、組み合わせ効果を評価
            - 次段階では応答曲面法でより精密な最適化を実施
            """)

def show_exercise3():
    st.markdown("### 📋 課題3：応答曲面法による最適化")
    
    st.markdown("""
    **課題概要：**
    課題2で重要と判明した温度と時間を中心として、応答曲面法により最適条件を探索してください。
    
    **実験条件：**
    - 因子：温度（95-105°C）、時間（45-75分）
    - 応答：収率（%）、純度（%）
    - 実験計画：中心複合計画（CCD）
    - 制約：収率≥85%、純度≥95%
    """)
    
    # 実験実行
    if st.button("CCD実験実行", key="ex3_generate"):
        np.random.seed(42)
        
        # 中心複合計画の設計点（コード化値）
        design_points = [
            # 2^2 factorial points
            [-1, -1], [1, -1], [-1, 1], [1, 1],
            # axial points
            [-1.414, 0], [1.414, 0], [0, -1.414], [0, 1.414],
            # center points
            [0, 0], [0, 0], [0, 0]
        ]
        
        # コード化値を実際値に変換
        temp_center, temp_range = 100, 5  # 95-105°C
        time_center, time_range = 60, 15  # 45-75分
        
        data = []
        for i, (temp_coded, time_coded) in enumerate(design_points):
            temp_actual = temp_center + temp_coded * temp_range / 2
            time_actual = time_center + time_coded * time_range / 2
            
            # 収率の真の関数（2次モデル）
            yield_true = (85 + 3*temp_coded + 2*time_coded 
                         - 1.5*temp_coded**2 - 1*time_coded**2 
                         + 1*temp_coded*time_coded 
                         + np.random.normal(0, 1))
            
            # 純度の真の関数
            purity_true = (94 + 1.5*temp_coded + 1*time_coded 
                          - 0.8*temp_coded**2 - 0.5*time_coded**2 
                          + 0.3*temp_coded*time_coded 
                          + np.random.normal(0, 0.5))
            
            data.append({
                'Run': i + 1,
                'Temp_coded': temp_coded,
                'Time_coded': time_coded,
                'Temperature': temp_actual,
                'Time': time_actual,
                'Yield': max(yield_true, 0),
                'Purity': min(max(purity_true, 90), 100)  # 90-100%の範囲
            })
        
        df = pd.DataFrame(data)
        st.session_state.exercise3_data = df
    
    if 'exercise3_data' in st.session_state:
        df = st.session_state.exercise3_data
        
        # データ表示
        st.markdown("#### 📊 CCD実験データ")
        st.dataframe(df[['Run', 'Temperature', 'Time', 'Yield', 'Purity']].round(2))
        
        # 応答曲面モデルの構築
        st.markdown("#### 🧮 応答曲面モデルの構築")
        
        # 収率モデル
        X = df[['Temp_coded', 'Time_coded']].copy()
        X['Temp_squared'] = X['Temp_coded'] ** 2
        X['Time_squared'] = X['Time_coded'] ** 2
        X['Temp_Time'] = X['Temp_coded'] * X['Time_coded']
        
        # 収率の回帰分析
        from sklearn.linear_model import LinearRegression
        
        yield_model = LinearRegression()
        yield_model.fit(X, df['Yield'])
        yield_pred = yield_model.predict(X)
        yield_r2 = yield_model.score(X, df['Yield'])
        
        # 純度の回帰分析
        purity_model = LinearRegression()
        purity_model.fit(X, df['Purity'])
        purity_pred = purity_model.predict(X)
        purity_r2 = purity_model.score(X, df['Purity'])
        
        # モデル係数の表示
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**収率モデル**")
            coef_names = ['切片', '温度', '時間', '温度²', '時間²', '温度×時間']
            yield_coefs = [yield_model.intercept_] + list(yield_model.coef_)
            
            yield_coef_df = pd.DataFrame({
                '項': coef_names,
                '係数': yield_coefs
            }).round(3)
            st.dataframe(yield_coef_df)
            st.write(f"**R² = {yield_r2:.4f}**")
        
        with col2:
            st.markdown("**純度モデル**")
            purity_coefs = [purity_model.intercept_] + list(purity_model.coef_)
            
            purity_coef_df = pd.DataFrame({
                '項': coef_names,
                '係数': purity_coefs
            }).round(3)
            st.dataframe(purity_coef_df)
            st.write(f"**R² = {purity_r2:.4f}**")
        
        # 応答曲面の可視化
        st.markdown("#### 🗺️ 応答曲面の可視化")
        
        # グリッドの生成
        temp_grid = np.linspace(-2, 2, 30)
        time_grid = np.linspace(-2, 2, 30)
        Temp_grid, Time_grid = np.meshgrid(temp_grid, time_grid)
        
        # 予測用データの準備
        grid_flat = np.column_stack([
            Temp_grid.ravel(),
            Time_grid.ravel(),
            Temp_grid.ravel()**2,
            Time_grid.ravel()**2,
            Temp_grid.ravel() * Time_grid.ravel()
        ])
        
        # 予測
        Yield_pred_grid = yield_model.predict(grid_flat).reshape(Temp_grid.shape)
        Purity_pred_grid = purity_model.predict(grid_flat).reshape(Temp_grid.shape)
        
        # 等高線プロット
        col1, col2 = st.columns(2)
        
        with col1:
            fig_yield = go.Figure(data=go.Contour(
                x=temp_grid, y=time_grid, z=Yield_pred_grid,
                colorscale='Viridis', contours=dict(showlabels=True)
            ))
            fig_yield.add_scatter(x=df['Temp_coded'], y=df['Time_coded'],
                                mode='markers', marker_color='red',
                                name='実験点')
            fig_yield.update_layout(title='収率の等高線図',
                                  xaxis_title='温度（コード化）',
                                  yaxis_title='時間（コード化）')
            st.plotly_chart(fig_yield, use_container_width=True)
        
        with col2:
            fig_purity = go.Figure(data=go.Contour(
                x=temp_grid, y=time_grid, z=Purity_pred_grid,
                colorscale='Plasma', contours=dict(showlabels=True)
            ))
            fig_purity.add_scatter(x=df['Temp_coded'], y=df['Time_coded'],
                                 mode='markers', marker_color='red',
                                 name='実験点')
            fig_purity.update_layout(title='純度の等高線図',
                                   xaxis_title='温度（コード化）',
                                   yaxis_title='時間（コード化）')
            st.plotly_chart(fig_purity, use_container_width=True)
        
        # 制約条件下での最適化
        st.markdown("#### 🎯 制約条件下での最適化")
        
        # 制約を満たす領域の特定
        yield_constraint = Yield_pred_grid >= 85
        purity_constraint = Purity_pred_grid >= 95
        feasible_region = yield_constraint & purity_constraint
        
        if np.any(feasible_region):
            # 実行可能領域での最適化（収率最大化）
            feasible_yield = np.where(feasible_region, Yield_pred_grid, -np.inf)
            max_idx = np.unravel_index(np.argmax(feasible_yield), feasible_yield.shape)
            
            optimal_temp_coded = Temp_grid[max_idx]
            optimal_time_coded = Time_grid[max_idx]
            optimal_yield = Yield_pred_grid[max_idx]
            optimal_purity = Purity_pred_grid[max_idx]
            
            # 実際値に変換
            optimal_temp_actual = temp_center + optimal_temp_coded * temp_range / 2
            optimal_time_actual = time_center + optimal_time_coded * time_range / 2
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.success("✅ 実行可能解が見つかりました")
                st.write(f"**最適温度:** {optimal_temp_actual:.1f}°C")
                st.write(f"**最適時間:** {optimal_time_actual:.1f}分")
            
            with col2:
                st.write(f"**予測収率:** {optimal_yield:.2f}%")
                st.write(f"**予測純度:** {optimal_purity:.2f}%")
        else:
            st.warning("⚠️ 制約条件を満たす解が見つかりませんでした")
        
        # 課題への回答
        st.markdown("#### 💡 課題回答")
        
        with st.expander("解答を見る"):
            st.markdown("""
            **解析結果の解釈：**
            
            1. **モデルの妥当性：**
               - 収率・純度モデルともに高いR²値
               - 2次項の存在により非線形関係を適切にモデル化
            
            2. **応答曲面の特徴：**
               - 収率は温度・時間の増加に伴い向上
               - 純度は適度な条件で最大値を示す
               - 交互作用効果により複雑な応答パターン
            
            3. **最適化結果：**
               - 制約条件下での最適解を特定
               - 収率・純度の同時改善が可能
               - 実用的な操作条件の範囲内
            
            **実務への応用：**
            - 多目的最適化の考え方を実践
            - 制約条件の重要性を理解
            - モデルベース最適化の有効性を確認
            - 確認実験による検証が次のステップ
            """)

def show_exercise4():
    st.markdown("### 📋 課題4：タグチメソッドによる頑健設計")
    
    st.markdown("""
    **課題概要：**
    ノイズ因子の影響を受けにくい頑健な反応条件を見つけてください。
    
    **実験条件：**
    - 制御因子：温度（2水準）、時間（2水準）、触媒濃度（2水準）
    - ノイズ因子：原料純度、環境温度
    - 実験計画：L4制御因子配列 × 2²ノイズ配列
    - 品質特性：望大特性（収率最大化）
    """)
    
    # 実験実行
    if st.button("タグチ実験実行", key="ex4_generate"):
        np.random.seed(42)
        
        # L4直交配列（制御因子）
        control_array = [
            [0, 0, 0],  # 低温度、低時間、低触媒
            [0, 1, 1],  # 低温度、高時間、高触媒
            [1, 0, 1],  # 高温度、低時間、高触媒
            [1, 1, 0]   # 高温度、高時間、低触媒
        ]
        
        # ノイズ因子の組み合わせ
        noise_array = [
            [0, 0],  # 低純度、低環境温度
            [0, 1],  # 低純度、高環境温度
            [1, 0],  # 高純度、低環境温度
            [1, 1]   # 高純度、高環境温度
        ]
        
        factor_names = ['Temperature', 'Time', 'Catalyst']
        noise_names = ['Purity', 'Env_Temp']
        
        data = []
        sn_ratios = []
        
        for exp_no, control_levels in enumerate(control_array):
            responses_per_exp = []
            
            for noise_levels in noise_array:
                for rep in range(2):  # 各ノイズ条件で2回反復
                    # 基準収率
                    yield_val = 75
                    
                    # 制御因子の効果
                    if control_levels[0] == 1:  # 高温度
                        yield_val += 8
                    if control_levels[1] == 1:  # 高時間
                        yield_val += 5
                    if control_levels[2] == 1:  # 高触媒
                        yield_val += 6
                    
                    # ノイズ因子の効果
                    if noise_levels[0] == 0:  # 低純度（悪い条件）
                        yield_val += np.random.normal(-3, 2)
                    else:  # 高純度（良い条件）
                        yield_val += np.random.normal(1, 1)
                    
                    if noise_levels[1] == 1:  # 高環境温度
                        yield_val += np.random.normal(-1, 1.5)
                    
                    # 交互作用（制御因子とノイズ因子）
                    if control_levels[0] == 1 and noise_levels[1] == 1:  # 高温度×高環境温度
                        yield_val += np.random.normal(-2, 1)
                    
                    # 基本的な実験誤差
                    yield_val += np.random.normal(0, 1)
                    
                    yield_val = max(yield_val, 0)  # 負の値を避ける
                    responses_per_exp.append(yield_val)
                    
                    # データ記録
                    data.append({
                        'Exp_No': exp_no + 1,
                        'Temperature': '高' if control_levels[0] == 1 else '低',
                        'Time': '高' if control_levels[1] == 1 else '低',
                        'Catalyst': '高' if control_levels[2] == 1 else '低',
                        'Purity': '高' if noise_levels[0] == 1 else '低',
                        'Env_Temp': '高' if noise_levels[1] == 1 else '低',
                        'Yield': yield_val,
                        'Replicate': rep + 1
                    })
            
            # SN比の計算（望大特性）
            # η = -10 * log10(1/n * Σ(1/y²))
            sn_ratio = -10 * np.log10(np.mean([1/y**2 for y in responses_per_exp]))
            mean_yield = np.mean(responses_per_exp)
            std_yield = np.std(responses_per_exp)
            
            sn_ratios.append({
                'Exp_No': exp_no + 1,
                'Temperature': '高' if control_levels[0] == 1 else '低',
                'Time': '高' if control_levels[1] == 1 else '低',
                'Catalyst': '高' if control_levels[2] == 1 else '低',
                'SN_Ratio': sn_ratio,
                'Mean_Yield': mean_yield,
                'Std_Yield': std_yield
            })
        
        df_data = pd.DataFrame(data)
        df_sn = pd.DataFrame(sn_ratios)
        
        st.session_state.exercise4_data = df_data
        st.session_state.exercise4_sn = df_sn
    
    if 'exercise4_data' in st.session_state:
        df_data = st.session_state.exercise4_data
        df_sn = st.session_state.exercise4_sn
        
        # データ表示
        st.markdown("#### 📊 タグチ実験データ")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**実験データ（一部）**")
            st.dataframe(df_data.head(12))
        
        with col2:
            st.markdown("**SN比と平均値**")
            st.dataframe(df_sn.round(3))
        
        # SN比による因子効果解析
        st.markdown("#### 🧮 SN比による因子効果解析")
        
        # 各制御因子のSN比効果
        sn_effects = {}
        mean_effects = {}
        
        for factor in ['Temperature', 'Time', 'Catalyst']:
            high_sn = df_sn[df_sn[factor] == '高']['SN_Ratio'].mean()
            low_sn = df_sn[df_sn[factor] == '低']['SN_Ratio'].mean()
            sn_effects[factor] = high_sn - low_sn
            
            high_mean = df_sn[df_sn[factor] == '高']['Mean_Yield'].mean()
            low_mean = df_sn[df_sn[factor] == '低']['Mean_Yield'].mean()
            mean_effects[factor] = high_mean - low_mean
        
        # 効果の表示
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**SN比効果**")
            sn_effects_df = pd.DataFrame([
                {'因子': k, 'SN比効果': v} for k, v in sn_effects.items()
            ]).round(3)
            st.dataframe(sn_effects_df)
        
        with col2:
            st.markdown("**平均値効果**")
            mean_effects_df = pd.DataFrame([
                {'因子': k, '平均値効果': v} for k, v in mean_effects.items()
            ]).round(3)
            st.dataframe(mean_effects_df)
        
        # 効果の可視化
        st.markdown("#### 📊 因子効果の可視化")
        
        col1, col2 = st.columns(2)
        
        with col1:
            fig_sn = px.bar(sn_effects_df, x='因子', y='SN比効果',
                          title='各因子のSN比効果',
                          color='SN比効果', color_continuous_scale='RdBu_r')
            st.plotly_chart(fig_sn, use_container_width=True)
        
        with col2:
            fig_mean = px.bar(mean_effects_df, x='因子', y='平均値効果',
                            title='各因子の平均値効果',
                            color='平均値効果', color_continuous_scale='RdBu_r')
            st.plotly_chart(fig_mean, use_container_width=True)
        
        # 最適水準の決定
        st.markdown("#### 🏆 最適水準の決定")
        
        optimal_sn = {}
        optimal_mean = {}
        
        for factor in ['Temperature', 'Time', 'Catalyst']:
            # SN比基準
            if sn_effects[factor] > 0:
                optimal_sn[factor] = '高'
            else:
                optimal_sn[factor] = '低'
            
            # 平均値基準
            if mean_effects[factor] > 0:
                optimal_mean[factor] = '高'
            else:
                optimal_mean[factor] = '低'
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**SN比最大化による推奨設定**")
            for factor, setting in optimal_sn.items():
                st.write(f"**{factor}:** {setting}水準")
        
        with col2:
            st.markdown("**平均値最大化による推奨設定**")
            for factor, setting in optimal_mean.items():
                st.write(f"**{factor}:** {setting}水準")
        
        # SN比 vs 平均値の散布図
        st.markdown("#### 🔍 SN比と平均値の関係")
        
        fig_scatter = px.scatter(df_sn, x='Mean_Yield', y='SN_Ratio',
                               hover_data=['Exp_No', 'Temperature', 'Time', 'Catalyst'],
                               title='SN比と平均収率の関係')
        fig_scatter.add_vline(x=85, line_dash="dash", line_color="red", 
                            annotation_text="目標収率85%")
        st.plotly_chart(fig_scatter, use_container_width=True)
        
        # 課題への回答
        st.markdown("#### 💡 課題回答")
        
        with st.expander("解答を見る"):
            st.markdown("""
            **解析結果の解釈：**
            
            1. **SN比による頑健性評価：**
               - 温度と触媒濃度がばらつき低減に有効
               - 時間の効果は限定的
               - 高水準設定により頑健性向上
            
            2. **平均値効果との比較：**
               - 平均値向上とばらつき低減の方向が一致
               - 両方を考慮した最適化が可能
               - 目標性能との両立を確認
            
            3. **推奨条件：**
               - 温度：高水準（105°C）
               - 時間：高水準（75分）
               - 触媒濃度：高水準（0.4mol/L）
            
            **タグチメソッドの価値：**
            - ノイズに対する頑健性を定量評価
            - 平均値とばらつきを分離して最適化
            - 製造条件の変動に強いプロセス設計
            - 品質の予測可能性向上
            """)

def show_exercise5():
    st.markdown("### 📋 課題5：ロバスト最適化による統合的解決")
    
    st.markdown("""
    **課題概要：**
    これまでの課題で得られた知見を統合し、不確実性を考慮したロバスト最適化により、
    実用的な操作条件を決定してください。
    
    **統合課題設定：**
    - 目的：収率85%以上、純度95%以上を不確実性下で達成
    - 不確実性：原料品質、装置状態、環境条件の変動
    - 制約：安全性、経済性、操作性の考慮
    - 手法：シナリオベースロバスト最適化
    """)
    
    # 実験実行
    if st.button("統合最適化実行", key="ex5_generate"):
        np.random.seed(42)
        
        # これまでの課題から得られた知見を統合
        # 重要因子：温度、時間、触媒濃度
        # 不確実パラメータ：原料純度、環境条件、装置劣化
        
        # シナリオの定義
        scenarios = [
            {'name': 'Normal', 'prob': 0.4, 'purity_factor': 1.0, 'env_factor': 1.0, 'degradation': 1.0},
            {'name': 'Low_Purity', 'prob': 0.2, 'purity_factor': 0.95, 'env_factor': 1.0, 'degradation': 1.0},
            {'name': 'High_Env_Temp', 'prob': 0.2, 'purity_factor': 1.0, 'env_factor': 0.98, 'degradation': 1.0},
            {'name': 'Equipment_Aged', 'prob': 0.15, 'purity_factor': 1.0, 'env_factor': 1.0, 'degradation': 0.95},
            {'name': 'Worst_Case', 'prob': 0.05, 'purity_factor': 0.93, 'env_factor': 0.95, 'degradation': 0.90}
        ]
        
        # 最適化変数の範囲（実際値）
        temp_range = (95, 110)    # 温度 °C
        time_range = (45, 80)     # 時間 分
        catalyst_range = (0.2, 0.5)  # 触媒濃度 mol/L
        
        # グリッド探索による最適化
        temp_grid = np.linspace(temp_range[0], temp_range[1], 20)
        time_grid = np.linspace(time_range[0], time_range[1], 20)
        catalyst_grid = np.linspace(catalyst_range[0], catalyst_range[1], 15)
        
        best_conditions = None
        best_score = -np.inf
        all_results = []
        
        for temp in temp_grid:
            for time in time_grid:
                for catalyst in catalyst_grid:
                    scenario_results = []
                    
                    for scenario in scenarios:
                        # 各シナリオでの性能計算
                        yield_base = 60 + 0.3*temp + 0.2*time + 50*catalyst - 0.001*temp**2 - 0.001*time**2
                        purity_base = 90 + 0.1*temp + 0.05*time + 10*catalyst - 0.0005*temp**2
                        
                        # シナリオ影響の適用
                        yield_scenario = (yield_base * scenario['purity_factor'] * 
                                        scenario['env_factor'] * scenario['degradation'])
                        purity_scenario = (purity_base * scenario['purity_factor'] * 
                                         scenario['env_factor'] * scenario['degradation'])
                        
                        # ノイズの追加
                        yield_final = yield_scenario + np.random.normal(0, 1)
                        purity_final = purity_scenario + np.random.normal(0, 0.5)
                        
                        scenario_results.append({
                            'scenario': scenario['name'],
                            'probability': scenario['prob'],
                            'yield': max(yield_final, 0),
                            'purity': min(max(purity_final, 85), 100)
                        })
                    
                    # ロバスト性評価
                    yields = [r['yield'] for r in scenario_results]
                    purities = [r['purity'] for r in scenario_results]
                    probs = [r['probability'] for r in scenario_results]
                    
                    # 期待値
                    expected_yield = sum(y*p for y, p in zip(yields, probs))
                    expected_purity = sum(p*prob for p, prob in zip(purities, probs))
                    
                    # 分散
                    yield_variance = sum(probs[i] * (yields[i] - expected_yield)**2 for i in range(len(scenarios)))
                    purity_variance = sum(probs[i] * (purities[i] - expected_purity)**2 for i in range(len(scenarios)))
                    
                    # 最悪ケース
                    worst_yield = min(yields)
                    worst_purity = min(purities)
                    
                    # 制約違反確率
                    yield_violation_prob = sum(probs[i] for i in range(len(scenarios)) if yields[i] < 85)
                    purity_violation_prob = sum(probs[i] for i in range(len(scenarios)) if purities[i] < 95)
                    
                    # 総合評価関数（制約条件を考慮）
                    if worst_yield >= 83 and worst_purity >= 93:  # 緩い制約での実行可能性
                        # 期待値最大化 - リスク考慮 - 制約違反ペナルティ
                        score = (expected_yield + expected_purity * 0.5 
                               - 0.3 * (yield_variance + purity_variance)
                               - 50 * yield_violation_prob 
                               - 50 * purity_violation_prob)
                    else:
                        score = -1000  # 実行不可能
                    
                    result = {
                        'temperature': temp,
                        'time': time,
                        'catalyst': catalyst,
                        'expected_yield': expected_yield,
                        'expected_purity': expected_purity,
                        'yield_std': np.sqrt(yield_variance),
                        'purity_std': np.sqrt(purity_variance),
                        'worst_yield': worst_yield,
                        'worst_purity': worst_purity,
                        'yield_violation_prob': yield_violation_prob,
                        'purity_violation_prob': purity_violation_prob,
                        'robust_score': score,
                        'scenario_results': scenario_results
                    }
                    
                    all_results.append(result)
                    
                    if score > best_score:
                        best_score = score
                        best_conditions = result
        
        st.session_state.exercise5_results = {
            'best_conditions': best_conditions,
            'all_results': all_results,
            'scenarios': scenarios
        }
    
    if 'exercise5_results' in st.session_state:
        results = st.session_state.exercise5_results
        best = results['best_conditions']
        
        # 最適化結果の表示
        st.markdown("#### 🎯 ロバスト最適化結果")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("**🏆 最適操作条件**")
            st.write(f"**温度:** {best['temperature']:.1f}°C")
            st.write(f"**時間:** {best['time']:.1f}分")
            st.write(f"**触媒濃度:** {best['catalyst']:.3f}mol/L")
        
        with col2:
            st.markdown("**📊 期待性能**")
            st.write(f"**期待収率:** {best['expected_yield']:.2f}%")
            st.write(f"**期待純度:** {best['expected_purity']:.2f}%")
            st.write(f"**ロバストスコア:** {best['robust_score']:.1f}")
        
        with col3:
            st.markdown("**⚠️ リスク評価**")
            st.write(f"**最悪収率:** {best['worst_yield']:.2f}%")
            st.write(f"**最悪純度:** {best['worst_purity']:.2f}%")
            st.write(f"**制約違反確率:** {(best['yield_violation_prob'] + best['purity_violation_prob'])*100:.1f}%")
        
        # シナリオ別性能
        st.markdown("#### 🎭 シナリオ別性能評価")
        
        scenario_df = pd.DataFrame(best['scenario_results'])
        
        col1, col2 = st.columns(2)
        
        with col1:
            fig_yield_scenario = px.bar(scenario_df, x='scenario', y='yield',
                                      title='シナリオ別収率',
                                      color='probability',
                                      color_continuous_scale='Viridis')
            fig_yield_scenario.add_hline(y=85, line_dash="dash", line_color="red",
                                       annotation_text="目標85%")
            st.plotly_chart(fig_yield_scenario, use_container_width=True)
        
        with col2:
            fig_purity_scenario = px.bar(scenario_df, x='scenario', y='purity',
                                       title='シナリオ別純度',
                                       color='probability',
                                       color_continuous_scale='Plasma')
            fig_purity_scenario.add_hline(y=95, line_dash="dash", line_color="red",
                                        annotation_text="目標95%")
            st.plotly_chart(fig_purity_scenario, use_container_width=True)
        
        # 感度分析
        st.markdown("#### 📈 操作条件の感度分析")
        
        # 温度の感度分析
        temp_sensitivity = []
        base_temp = best['temperature']
        
        for delta in [-5, -2.5, 0, 2.5, 5]:
            temp_test = base_temp + delta
            if temp_range[0] <= temp_test <= temp_range[1]:
                # 簡単化された性能計算
                yield_est = 60 + 0.3*temp_test + 0.2*best['time'] + 50*best['catalyst'] - 0.001*temp_test**2
                temp_sensitivity.append({
                    'Temperature_Delta': delta,
                    'Temperature': temp_test,
                    'Estimated_Yield': yield_est
                })
        
        if temp_sensitivity:
            sens_df = pd.DataFrame(temp_sensitivity)
            fig_sensitivity = px.line(sens_df, x='Temperature', y='Estimated_Yield',
                                    title='温度変動に対する収率の感度',
                                    markers=True)
            fig_sensitivity.add_vline(x=base_temp, line_dash="dash", line_color="red",
                                    annotation_text="最適温度")
            st.plotly_chart(fig_sensitivity, use_container_width=True)
        
        # パレート分析
        st.markdown("#### ⚖️ 期待値 vs リスクのトレードオフ")
        
        # 上位解の抽出
        sorted_results = sorted(results['all_results'], key=lambda x: x['robust_score'], reverse=True)
        top_results = sorted_results[:50]  # 上位50解
        
        tradeoff_df = pd.DataFrame([{
            'Expected_Yield': r['expected_yield'],
            'Yield_Std': r['yield_std'],
            'Expected_Purity': r['expected_purity'],
            'Purity_Std': r['purity_std'],
            'Temperature': r['temperature'],
            'Time': r['time'],
            'Catalyst': r['catalyst']
        } for r in top_results])
        
        fig_tradeoff = px.scatter(tradeoff_df, x='Expected_Yield', y='Yield_Std',
                                color='Expected_Purity', size='Catalyst',
                                hover_data=['Temperature', 'Time'],
                                title='期待収率 vs 収率標準偏差のトレードオフ',
                                color_continuous_scale='Viridis')
        
        # 最適解をマーク
        fig_tradeoff.add_scatter(x=[best['expected_yield']], y=[best['yield_std']],
                               mode='markers', marker_size=20, marker_color='red',
                               name='ロバスト最適解')
        
        st.plotly_chart(fig_tradeoff, use_container_width=True)
        
        # 最終提案
        st.markdown("#### 💼 実務への提案")
        
        st.markdown(f"""
        <div class="info-box">
        <h4>🎯 推奨プロセス条件</h4>
        <ul>
        <li><strong>反応温度:</strong> {best['temperature']:.1f}°C (±1°C の制御精度推奨)</li>
        <li><strong>反応時間:</strong> {best['time']:.1f}分 (±2分の制御精度推奨)</li>
        <li><strong>触媒濃度:</strong> {best['catalyst']:.3f}mol/L (±0.01mol/L の制御精度推奨)</li>
        </ul>
        
        <h4>📊 期待性能</h4>
        <ul>
        <li><strong>期待収率:</strong> {best['expected_yield']:.1f}% (目標85%を達成)</li>
        <li><strong>期待純度:</strong> {best['expected_purity']:.1f}% (目標95%を{('達成' if best['expected_purity'] >= 95 else '未達成')})</li>
        <li><strong>制約違反リスク:</strong> {(best['yield_violation_prob'] + best['purity_violation_prob'])*100:.1f}%</li>
        </ul>
        
        <h4>⚠️ 運用上の注意点</h4>
        <ul>
        <li>原料品質の事前チェック体制の確立</li>
        <li>環境温度制御システムの導入検討</li>
        <li>装置の定期メンテナンス計画の策定</li>
        <li>品質管理による継続的な性能監視</li>
        </ul>
        </div>
        """, unsafe_allow_html=True)
        
        # 課題への回答
        with st.expander("統合課題の解答と学習のまとめ"):
            st.markdown("""
            **統合課題の解決アプローチ：**
            
            1. **問題の構造化：**
               - 多目的最適化問題として定式化
               - 不確実性をシナリオとして明示的にモデル化
               - 制約条件と目標の階層化
            
            2. **手法の統合的活用：**
               - 一因子実験：重要因子の特定
               - 多因子実験：交互作用の把握
               - 応答曲面法：非線形関係のモデル化
               - タグチメソッド：頑健性の定量化
               - ロバスト最適化：不確実性下での意思決定
            
            3. **実務的な解決策：**
               - 期待性能とリスクのバランス
               - 実装可能性を考慮した条件設定
               - 継続的改善のためのモニタリング計画
            
            **学習目標の達成度評価：**
            
            ✅ **技術的理解：** 各手法の特徴と適用場面を理解
            ✅ **統合的思考：** 複数手法を組み合わせた問題解決
            ✅ **実務応用：** 現実的制約を考慮したソリューション
            ✅ **リスク管理：** 不確実性を考慮した意思決定
            
            **今後の発展方向：**
            - 機械学習による適応的最適化
            - リアルタイムデータによる動的制御
            - 多段階意思決定プロセスの導入
            - 経済性を含めた総合的最適化
            """)

if __name__ == "__main__":
    main()