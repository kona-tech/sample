# -*- coding: utf-8 -*-
import streamlit as st
import locale

# 日本語表示の確保
try:
    locale.setlocale(locale.LC_ALL, 'ja_JP.UTF-8')
except:
    pass

# Streamlitページ設定
st.set_page_config(
    page_title="実験計画法学習サイト",
    page_icon="🧪",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 共通設定とCSSの読み込み
from utils.common import setup_custom_css

# コンポーネントのインポート
from components.home import show_home
from components.basics import show_basics
from components.one_factor import show_one_factor
from components.factorial import show_factorial
from components.anova import show_anova
from components.response_surface import show_response_surface
from components.taguchi import show_taguchi
from components.robust_optimization import show_robust_optimization
from components.orthogonal_array import show_orthogonal_array
from components.common_exercises import show_common_exercises
from components.exercise_explanation import show_exercise_explanation

# カスタムCSS設定
setup_custom_css()

# サイドバーでページ選択
st.sidebar.title("📋 メニュー")
page = st.sidebar.selectbox(
    "学習したい内容を選択してください",
    [
        "🏠 ホーム",
        "📚 実験計画法の基本",
        "🔬 一因子実験",
        "⚗️ 多因子実験（2^k実験）",
        "📊 分散分析（ANOVA）",
        "📈 応答曲面法",
        "🎯 パラメータ設計（タグチメソッド）",
        "🛡️ ロバスト最適化",
        "📋 直交表実験",
        "📝 共通課題",
        "📖 課題説明"
    ]
)

def main():
    if page == "🏠 ホーム":
        show_home()
    elif page == "📚 実験計画法の基本":
        show_basics()
    elif page == "🔬 一因子実験":
        show_one_factor()
    elif page == "⚗️ 多因子実験（2^k実験）":
        show_factorial()
    elif page == "📊 分散分析（ANOVA）":
        show_anova()
    elif page == "📈 応答曲面法":
        show_response_surface()
    elif page == "🎯 パラメータ設計（タグチメソッド）":
        show_taguchi()
    elif page == "🛡️ ロバスト最適化":
        show_robust_optimization()
    elif page == "📋 直交表実験":
        show_orthogonal_array()
    elif page == "📝 共通課題":
        show_common_exercises()
    elif page == "📖 課題説明":
        show_exercise_explanation()

if __name__ == "__main__":
    main()