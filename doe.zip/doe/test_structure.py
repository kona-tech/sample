#!/usr/bin/env python3
"""Test the multi-page structure"""

def test_imports():
    """Test that all imports work correctly"""
    
    print("Testing utils import...")
    from utils.common import PROCESS_MODEL, setup_custom_css
    print("✅ utils.common import successful")
    
    print("\nTesting component imports...")
    from components.home import show_home
    print("✅ components.home import successful")
    
    from components.basics import show_basics
    print("✅ components.basics import successful")
    
    from components.one_factor import show_one_factor
    print("✅ components.one_factor import successful")
    
    from components.factorial import show_factorial
    print("✅ components.factorial import successful")
    
    from components.anova import show_anova
    print("✅ components.anova import successful")
    
    from components.response_surface import show_response_surface
    print("✅ components.response_surface import successful")
    
    from components.taguchi import show_taguchi
    print("✅ components.taguchi import successful")
    
    from components.robust_optimization import show_robust_optimization
    print("✅ components.robust_optimization import successful")
    
    from components.orthogonal_array import show_orthogonal_array
    print("✅ components.orthogonal_array import successful")
    
    from components.common_exercises import show_common_exercises
    print("✅ components.common_exercises import successful")
    
    from components.exercise_explanation import show_exercise_explanation
    print("✅ components.exercise_explanation import successful")
    
    print("\nTesting exercise component imports...")
    from components.exercise1 import show_exercise1
    print("✅ components.exercise1 import successful")
    
    from components.exercise2 import show_exercise2
    print("✅ components.exercise2 import successful")
    
    from components.exercise3 import show_exercise3
    print("✅ components.exercise3 import successful")
    
    from components.exercise4 import show_exercise4
    print("✅ components.exercise4 import successful")
    
    from components.exercise5 import show_exercise5
    print("✅ components.exercise5 import successful")
    
    print("\n🎉 All imports successful!")

def test_process_model():
    """Test the process model functionality"""
    print("\nTesting process model...")
    from utils.common import PROCESS_MODEL
    
    # Test yield calculation
    yield_result = PROCESS_MODEL.yield_function(100, 60, 0.3, 7.0, 0)
    print(f"✅ Process model yield calculation: {yield_result:.2f}%")
    
    # Test purity calculation
    purity_result = PROCESS_MODEL.purity_function(100, 60, 0.3, 7.0, 0)
    print(f"✅ Process model purity calculation: {purity_result:.2f}%")

if __name__ == "__main__":
    test_imports()
    test_process_model()
    print("\n🚀 Multi-page structure test completed successfully!")