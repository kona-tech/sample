import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
from itertools import product
from scipy import stats
from utils.common import PROCESS_MODEL

def show_exercise2():
    st.markdown('<h1 class="section-header">📋 演習2: 因子間相互作用の調査</h1>', unsafe_allow_html=True)
    
    st.markdown("## 🎯 演習の目的")
    st.markdown("""
    <div class="info-box">
    **目的:** 複数の制御因子間の交互作用効果を検出し、因子の組み合わせ効果を理解する
    
    **使用する手法:** 2^k多因子実験（部分実施計画）
    
    **想定シナリオ:** 演習1で重要と判明した因子を中心に、因子間の相互作用を調査し、
    単独では得られない最適化の機会を発見する。
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("## 🔧 実験設計")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 🎮 2^3実験の実行
        **選択因子（3因子）:**
        - **A: 反応温度** (95°C ↔ 105°C)
        - **B: 反応時間** (45分 ↔ 75分)  
        - **C: 触媒濃度** (0.2 ↔ 0.4 mol/L)
        
        **実験点数:** 2³ = 8通り + 中心点
        """)
        
        n_replicates = st.slider("繰り返し数", 2, 5, 3)
        include_center = st.checkbox("中心点を含める", value=True)
        random_seed = st.number_input("乱数シード", value=42, step=1)
        
        run_experiment = st.button("2³実験実行", type="primary")
    
    with col2:
        if run_experiment or 'exercise2_data' not in st.session_state:
            np.random.seed(int(random_seed))
            
            # 2^3実験設計
            factors = list(product([0, 1], repeat=3))
            factor_values = {
                'temp': [95, 105],    # A: 温度
                'time': [45, 75],     # B: 時間  
                'catalyst': [0.2, 0.4] # C: 触媒濃度
            }
            
            data = []
            for run_no, (a, b, c) in enumerate(factors):
                for rep in range(n_replicates):
                    temp = factor_values['temp'][a]
                    time = factor_values['time'][b]
                    catalyst = factor_values['catalyst'][c]
                    ph = 7.0  # 固定
                    
                    # 収率計算
                    noise = np.random.normal(0, PROCESS_MODEL.yield_params['error_std'])
                    yield_val = PROCESS_MODEL.yield_function(temp, time, catalyst, ph, noise)
                    
                    data.append({
                        'Run': run_no + 1,
                        'A_Temp': '高' if a == 1 else '低',
                        'B_Time': '高' if b == 1 else '低',
                        'C_Catalyst': '高' if c == 1 else '低',
                        'A_coded': a,
                        'B_coded': b, 
                        'C_coded': c,
                        'Temp_actual': temp,
                        'Time_actual': time,
                        'Catalyst_actual': catalyst,
                        'Yield': yield_val,
                        'Replicate': rep + 1
                    })
            
            # 中心点の追加
            if include_center:
                for rep in range(n_replicates):
                    temp, time, catalyst, ph = 100, 60, 0.3, 7.0
                    noise = np.random.normal(0, PROCESS_MODEL.yield_params['error_std'])
                    yield_val = PROCESS_MODEL.yield_function(temp, time, catalyst, ph, noise)
                    
                    data.append({
                        'Run': 'Center',
                        'A_Temp': '中心',
                        'B_Time': '中心',
                        'C_Catalyst': '中心',
                        'A_coded': 0,
                        'B_coded': 0,
                        'C_coded': 0,
                        'Temp_actual': temp,
                        'Time_actual': time,
                        'Catalyst_actual': catalyst,
                        'Yield': yield_val,
                        'Replicate': rep + 1
                    })
            
            df_exp2 = pd.DataFrame(data)
            st.session_state.exercise2_data = df_exp2
        
        if 'exercise2_data' in st.session_state:
            df_exp2 = st.session_state.exercise2_data
            
            st.markdown("### 📊 実験データ")
            display_cols = ['Run', 'A_Temp', 'B_Time', 'C_Catalyst', 'Yield']
            st.dataframe(df_exp2[display_cols].head(10))
    
    # 効果の分析
    if 'exercise2_data' in st.session_state:
        df_exp2 = st.session_state.exercise2_data
        df_factorial = df_exp2[df_exp2['Run'] != 'Center'].copy()  # 中心点を除く
        
        st.markdown("## 📈 因子効果の分析")
        
        # 主効果の計算
        effects = {}
        factors = ['A_Temp', 'B_Time', 'C_Catalyst']
        
        for factor in factors:
            high_mean = df_factorial[df_factorial[factor] == '高']['Yield'].mean()
            low_mean = df_factorial[df_factorial[factor] == '低']['Yield'].mean()
            effects[factor] = high_mean - low_mean
        
        # 交互作用効果の計算
        factor_pairs = [('A_Temp', 'B_Time'), ('A_Temp', 'C_Catalyst'), ('B_Time', 'C_Catalyst')]
        
        for f1, f2 in factor_pairs:
            # 2因子交互作用
            high_high = df_factorial[(df_factorial[f1] == '高') & (df_factorial[f2] == '高')]['Yield'].mean()
            high_low = df_factorial[(df_factorial[f1] == '高') & (df_factorial[f2] == '低')]['Yield'].mean()
            low_high = df_factorial[(df_factorial[f1] == '低') & (df_factorial[f2] == '高')]['Yield'].mean()
            low_low = df_factorial[(df_factorial[f1] == '低') & (df_factorial[f2] == '低')]['Yield'].mean()
            
            interaction = ((high_high - high_low) - (low_high - low_low)) / 2
            effects[f"{f1}×{f2}"] = interaction
        
        # 効果の表示
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 🔍 因子効果の大きさ")
            effects_df = pd.DataFrame(list(effects.items()), columns=['効果', '推定値'])
            effects_df['絶対値'] = np.abs(effects_df['推定値'])
            effects_df = effects_df.sort_values('絶対値', ascending=False)
            st.dataframe(effects_df.round(3))
        
        with col2:
            st.markdown("### 📊 効果の可視化")
            fig, ax = plt.subplots(figsize=(10, 6))
            
            effect_names = effects_df['効果'].values
            effect_values = effects_df['推定値'].values
            colors = ['red' if abs(v) > 2 else 'blue' for v in effect_values]
            
            bars = ax.bar(range(len(effect_names)), effect_values, color=colors, alpha=0.7)
            ax.set_xticks(range(len(effect_names)))
            ax.set_xticklabels(effect_names, rotation=45, ha='right')
            ax.set_ylabel('効果の大きさ')
            ax.set_title('因子効果の比較')
            ax.axhline(y=0, color='black', linestyle='-', alpha=0.3)
            ax.grid(True, alpha=0.3)
            
            # 閾値ライン
            ax.axhline(y=2, color='red', linestyle='--', alpha=0.5, label='重要効果の閾値')
            ax.axhline(y=-2, color='red', linestyle='--', alpha=0.5)
            ax.legend()
            
            st.pyplot(fig)
            plt.close()
        
        # 交互作用プロット
        st.markdown("### 🔄 交互作用プロットの詳細分析")
        
        # 最も大きな交互作用を特定
        interaction_effects = {k: v for k, v in effects.items() if '×' in k}
        if interaction_effects:
            max_interaction = max(interaction_effects.items(), key=lambda x: abs(x[1]))
            st.info(f"**最大交互作用:** {max_interaction[0]} (効果: {max_interaction[1]:.2f})")
            
            # 交互作用プロットの作成
            factors_in_interaction = max_interaction[0].split('×')
            f1, f2 = factors_in_interaction
            
            interaction_data = []
            for val1 in ['低', '高']:
                for val2 in ['低', '高']:
                    mean_yield = df_factorial[(df_factorial[f1] == val1) & 
                                            (df_factorial[f2] == val2)]['Yield'].mean()
                    interaction_data.append({
                        f1: val1,
                        f2: val2, 
                        'Yield': mean_yield
                    })
            
            interaction_df = pd.DataFrame(interaction_data)
            fig_interaction = px.line(interaction_df, x=f1, y='Yield', color=f2,
                                    title=f'{f1}と{f2}の交互作用',
                                    markers=True)
            st.plotly_chart(fig_interaction, use_container_width=True)
    
    # 最適条件の推定
    if 'exercise2_data' in st.session_state:
        st.markdown("## 🎯 最適条件の推定")
        
        # 各組み合わせでの平均収率
        combination_means = df_factorial.groupby(['A_Temp', 'B_Time', 'C_Catalyst'])['Yield'].mean()
        optimal_combination = combination_means.idxmax()
        max_yield = combination_means.max()
        
        st.success(f"""
        **推定最適条件:**
        - **温度:** {optimal_combination[0]}水準 ({'105°C' if optimal_combination[0] == '高' else '95°C'})
        - **時間:** {optimal_combination[1]}水準 ({'75分' if optimal_combination[1] == '高' else '45分'})
        - **触媒:** {optimal_combination[2]}水準 ({'0.4' if optimal_combination[2] == '高' else '0.2'} mol/L)
        
        **期待収率:** {max_yield:.2f}%
        """)
        
        # 結果の解釈
        st.markdown("### 🤔 結果の解釈")
        
        important_effects = [k for k, v in effects.items() if abs(v) > 2.0]
        
        if important_effects:
            st.markdown("**重要な効果（|効果| > 2.0）:**")
            for effect in important_effects:
                value = effects[effect]
                if '×' in effect:
                    st.write(f"- **{effect}**: {value:.2f} (交互作用効果)")
                else:
                    st.write(f"- **{effect}**: {value:.2f} (主効果)")
        else:
            st.info("重要な効果（|効果| > 2.0）は検出されませんでした。")
    
    # 学習ポイント
    st.markdown("---") 
    st.markdown("## 📚 学習ポイント")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### ✅ 2^k実験の特徴
        
        **効率性:**
        - 少ない実験数で多くの情報を取得
        - 主効果と交互作用を同時に推定
        - 体系的な実験設計
        
        **交互作用の発見:**
        - 因子の組み合わせ効果を定量化
        - 単独実験では見つからない最適化機会
        - 複雑な因子関係の理解
        """)
    
    with col2:
        st.markdown("""
        ### 🔄 次のステップ
        
        **この結果を活用して:**
        - 重要因子を応答曲面法でさらに詳細調査
        - 連続的な最適化の実施
        - より精密な最適条件の決定
        
        **実際の応用:**
        - 製品開発での因子スクリーニング
        - プロセス改善での交互作用調査
        - 品質向上のための要因解析
        """)
    
    st.info("""
    💡 **交互作用の重要性**  
    交互作用効果は、因子を単独で調査していては発見できません。
    2^k実験により、因子間の相乗効果や拮抗効果を効率的に検出し、
    より効果的な最適化戦略を立案することができます。
    """)