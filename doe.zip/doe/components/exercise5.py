import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go
from utils.common import PROCESS_MODEL

def show_exercise5():
    st.markdown('<h1 class="section-header">📋 演習5: 総合最適化</h1>', unsafe_allow_html=True)
    
    st.markdown("## 🎯 演習の目的")
    st.markdown("""
    <div class="info-box">
    **目的:** これまでの学習を統合し、複数の目的関数（収率・純度）を同時に最適化する
    
    **使用する手法:** 多目的最適化 + 実験計画法の統合的活用
    
    **想定シナリオ:** 実際の化学プロセスでは、収率だけでなく純度も重要。
    両者は往々にしてトレードオフ関係にあるため、バランスの取れた最適条件を見つける必要がある。
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("## 🎯 多目的最適化の課題")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 📊 目的関数
        
        **主目的関数:**
        1. **収率最大化** → max Yield(%)
        2. **純度最大化** → max Purity(%)
        
        **制約条件:**
        - 収率 ≥ 85%（品質基準）
        - 純度 ≥ 95%（規格基準）
        - 温度 ≤ 120°C（安全基準）
        - 経済性考慮（触媒コスト）
        """)
    
    with col2:
        st.markdown("""
        ### ⚖️ トレードオフの理解
        
        **一般的な関係:**
        - 高温・長時間 → 収率↑ 純度↓
        - 高濃度触媒 → 収率↑ コスト↑
        - 最適pH → 複雑な非線形関係
        
        **解決アプローチ:**
        - パレート最適解の探索
        - 重み付き目的関数
        - 制約条件下での最適化
        """)
    
    # 多目的最適化実験
    st.markdown("## 🎮 多目的最適化実験")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### 最適化設定")
        
        # 目的関数の重み
        st.markdown("#### 目的関数の重み設定")
        w_yield = st.slider("収率の重み", 0.0, 1.0, 0.6, 0.1)
        w_purity = st.slider("純度の重み", 0.0, 1.0, 0.4, 0.1)
        
        # 正規化
        total_weight = w_yield + w_purity
        if total_weight > 0:
            w_yield = w_yield / total_weight
            w_purity = w_purity / total_weight
        
        st.write(f"**正規化後:** 収率 {w_yield:.1f} : 純度 {w_purity:.1f}")
        
        # 制約条件
        st.markdown("#### 制約条件")
        min_yield = st.slider("最低収率要求 (%)", 75, 95, 85)
        min_purity = st.slider("最低純度要求 (%)", 90, 98, 95)
        max_temp = st.slider("最高温度制限 (°C)", 110, 125, 120)
        
        # 探索範囲
        st.markdown("#### 探索範囲")
        temp_range = st.slider("温度範囲 (°C)", 80, 120, (90, 115))
        time_range = st.slider("時間範囲 (分)", 30, 90, (40, 80))
        catalyst_range = st.slider("触媒範囲 (mol/L)", 0.1, 0.5, (0.15, 0.45))
        ph_range = st.slider("pH範囲", 6.0, 8.0, (6.5, 7.5))
        
        optimize_button = st.button("多目的最適化実行", type="primary")
    
    with col2:
        if optimize_button or 'exercise5_data' not in st.session_state:
            np.random.seed(42)
            
            # グリッドサーチによる多目的最適化（簡略化）
            n_points = 1000  # サンプル点数
            
            # ランダムサンプリングによる探索
            temp_samples = np.random.uniform(temp_range[0], temp_range[1], n_points)
            time_samples = np.random.uniform(time_range[0], time_range[1], n_points)
            catalyst_samples = np.random.uniform(catalyst_range[0], catalyst_range[1], n_points)
            ph_samples = np.random.uniform(ph_range[0], ph_range[1], n_points)
            
            results = []
            feasible_results = []
            
            for i in range(n_points):
                temp = temp_samples[i]
                time = time_samples[i]
                catalyst = catalyst_samples[i]
                ph = ph_samples[i]
                
                # 収率と純度の計算
                yield_val = PROCESS_MODEL.yield_function(temp, time, catalyst, ph, 0)  # ノイズなし
                purity_val = PROCESS_MODEL.purity_function(temp, time, catalyst, ph, 0)  # ノイズなし
                
                # 重み付き目的関数
                weighted_objective = w_yield * (yield_val / 100) + w_purity * (purity_val / 100)
                
                # 制約条件のチェック
                constraints_satisfied = (
                    yield_val >= min_yield and
                    purity_val >= min_purity and
                    temp <= max_temp
                )
                
                result = {
                    'Temp': temp,
                    'Time': time,
                    'Catalyst': catalyst,
                    'pH': ph,
                    'Yield': yield_val,
                    'Purity': purity_val,
                    'Weighted_Objective': weighted_objective,
                    'Feasible': constraints_satisfied
                }
                
                results.append(result)
                if constraints_satisfied:
                    feasible_results.append(result)
            
            df_results = pd.DataFrame(results)
            df_feasible = pd.DataFrame(feasible_results) if feasible_results else pd.DataFrame()
            
            st.session_state.exercise5_data = df_results
            st.session_state.exercise5_feasible = df_feasible
            st.session_state.exercise5_weights = {'yield': w_yield, 'purity': w_purity}
            st.session_state.exercise5_constraints = {
                'min_yield': min_yield, 'min_purity': min_purity, 'max_temp': max_temp
            }
        
        if 'exercise5_data' in st.session_state:
            df_results = st.session_state.exercise5_data
            df_feasible = st.session_state.exercise5_feasible
            weights = st.session_state.exercise5_weights
            constraints = st.session_state.exercise5_constraints
            
            # 最適化結果の表示
            st.markdown("### 🎯 最適化結果")
            
            if len(df_feasible) > 0:
                # 制約条件を満たす解の中での最適解
                best_idx = df_feasible['Weighted_Objective'].idxmax()
                best_solution = df_feasible.iloc[best_idx]
                
                st.success(f"""
                **最適解（制約条件満足）:**
                - **温度:** {best_solution['Temp']:.1f}°C
                - **時間:** {best_solution['Time']:.1f}分
                - **触媒濃度:** {best_solution['Catalyst']:.3f} mol/L
                - **pH:** {best_solution['pH']:.2f}
                
                **性能指標:**
                - **収率:** {best_solution['Yield']:.2f}%
                - **純度:** {best_solution['Purity']:.2f}%
                - **重み付き目的関数:** {best_solution['Weighted_Objective']:.4f}
                """)
                
                st.info(f"**制約条件を満たす解の数:** {len(df_feasible)} / {len(df_results)}")
            
            else:
                st.error("制約条件を満たす解が見つかりませんでした。制約条件を緩和してください。")
                
                # 全解の中での最適解を参考表示
                best_idx = df_results['Weighted_Objective'].idxmax()
                best_solution = df_results.iloc[best_idx]
                
                st.warning(f"""
                **参考：制約なし最適解**
                - **温度:** {best_solution['Temp']:.1f}°C
                - **時間:** {best_solution['Time']:.1f}分
                - **触媒濃度:** {best_solution['Catalyst']:.3f} mol/L
                - **pH:** {best_solution['pH']:.2f}
                - **収率:** {best_solution['Yield']:.2f}%
                - **純度:** {best_solution['Purity']:.2f}%
                """)
    
    # パレート解析
    if 'exercise5_data' in st.session_state and len(st.session_state.exercise5_feasible) > 0:
        st.markdown("## 📊 パレート解析とトレードオフ")
        
        df_results = st.session_state.exercise5_data
        df_feasible = st.session_state.exercise5_feasible
        
        # パレート散布図
        st.markdown("### 🎨 収率-純度のトレードオフ可視化")
        
        # 全データポイント
        fig = px.scatter(df_results, x='Yield', y='Purity',
                        color='Feasible',
                        color_discrete_map={True: 'green', False: 'red'},
                        opacity=0.6,
                        title='収率と純度のトレードオフ関係')
        
        # 最適解をハイライト
        if len(df_feasible) > 0:
            best_solution = df_feasible.loc[df_feasible['Weighted_Objective'].idxmax()]
            fig.add_scatter(x=[best_solution['Yield']], y=[best_solution['Purity']],
                          mode='markers', marker=dict(size=15, color='gold', symbol='star'),
                          name='最適解')
        
        # 制約線の追加
        fig.add_hline(y=constraints['min_purity'], line_dash="dash", 
                     annotation_text=f"最低純度 {constraints['min_purity']}%")
        fig.add_vline(x=constraints['min_yield'], line_dash="dash",
                     annotation_text=f"最低収率 {constraints['min_yield']}%")
        
        fig.update_layout(height=500)
        st.plotly_chart(fig, use_container_width=True)
        
        # パレート最適解の特定（簡易版）
        if len(df_feasible) > 0:
            st.markdown("### 🏆 パレート最適解群の分析")
            
            # 制約条件を満たす解の上位解を表示
            top_solutions = df_feasible.nlargest(5, 'Weighted_Objective')
            
            st.markdown("#### トップ5解の比較")
            display_cols = ['Temp', 'Time', 'Catalyst', 'pH', 'Yield', 'Purity', 'Weighted_Objective']
            st.dataframe(top_solutions[display_cols].round(3))
            
            # 各目的関数での最適解
            col1, col2 = st.columns(2)
            
            with col1:
                yield_best = df_feasible.loc[df_feasible['Yield'].idxmax()]
                st.markdown("#### 🎯 収率最優先解")
                st.write(f"収率: {yield_best['Yield']:.2f}%")
                st.write(f"純度: {yield_best['Purity']:.2f}%")
                st.write(f"温度: {yield_best['Temp']:.1f}°C")
                st.write(f"時間: {yield_best['Time']:.1f}分")
            
            with col2:
                purity_best = df_feasible.loc[df_feasible['Purity'].idxmax()]
                st.markdown("#### 💎 純度最優先解")
                st.write(f"収率: {purity_best['Yield']:.2f}%")
                st.write(f"純度: {purity_best['Purity']:.2f}%")
                st.write(f"温度: {purity_best['Temp']:.1f}°C")
                st.write(f"時間: {purity_best['Time']:.1f}分")
        
        # 感度分析
        st.markdown("### 📈 重み設定の感度分析")
        
        # 異なる重み設定での結果を比較
        weight_scenarios = [
            {"yield": 0.8, "purity": 0.2, "name": "収率重視"},
            {"yield": 0.5, "purity": 0.5, "name": "バランス"},
            {"yield": 0.2, "purity": 0.8, "name": "純度重視"}
        ]
        
        sensitivity_results = []
        
        for scenario in weight_scenarios:
            w_y, w_p = scenario["yield"], scenario["purity"]
            df_temp = df_feasible.copy()
            df_temp['Scenario_Objective'] = w_y * (df_temp['Yield'] / 100) + w_p * (df_temp['Purity'] / 100)
            
            if len(df_temp) > 0:
                best_idx = df_temp['Scenario_Objective'].idxmax()
                best = df_temp.iloc[best_idx]
                
                sensitivity_results.append({
                    'シナリオ': scenario["name"],
                    '収率重み': w_y,
                    '純度重み': w_p,
                    '最適収率': best['Yield'],
                    '最適純度': best['Purity'],
                    '最適温度': best['Temp'],
                    '最適時間': best['Time']
                })
        
        if sensitivity_results:
            sensitivity_df = pd.DataFrame(sensitivity_results)
            st.dataframe(sensitivity_df.round(2))
    
    # 総合考察
    st.markdown("---")
    st.markdown("## 🤔 総合考察とエンジニアリング判断")
    
    if 'exercise5_feasible' in st.session_state and len(st.session_state.exercise5_feasible) > 0:
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("""
            ### 🏭 実用的観点での評価
            
            **経済性:**
            - 触媒コスト vs 収率向上効果
            - 運転コスト vs 品質向上価値
            - 設備投資 vs 長期収益性
            
            **操業性:**
            - 制御の容易さ
            - プロセスの安定性
            - メンテナンス性
            """)
        
        with col2:
            st.markdown("""
            ### 🎯 推奨決定プロセス
            
            **ステップ1:** 制約条件の妥当性確認
            **ステップ2:** 重み設定の経営判断
            **ステップ3:** リスク評価の実施
            **ステップ4:** パイロット実験での検証
            **ステップ5:** 段階的実装計画の策定
            """)
    
    # 学習の総括
    st.markdown("## 📚 実験計画法学習の総括")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### ✅ 習得した手法とスキル
        
        **基礎手法:**
        - 一因子実験による基本的因子効果調査
        - 分散分析による統計的判定
        
        **発展手法:**
        - 多因子実験による交互作用検出  
        - 応答曲面法による連続最適化
        
        **応用手法:**
        - タグチメソッドによるロバスト設計
        - 多目的最適化による実用的解決
        """)
    
    with col2:
        st.markdown("""
        ### 🚀 実務での活用場面
        
        **製品開発:**
        - 新製品の品質特性最適化
        - 製造プロセスの設計
        
        **プロセス改善:**
        - 既存プロセスの効率化
        - 品質ばらつきの低減
        
        **問題解決:**
        - 品質問題の要因解析
        - 総合的な最適化戦略立案
        """)
    
    st.success("""
    🎓 **学習完了おめでとうございます！**  
    
    実験計画法の各手法を統合的に活用することで、複雑なエンジニアリング問題に対しても
    系統的かつ効率的にアプローチできるようになりました。
    
    実際の業務では、問題の性質や制約条件に応じて適切な手法を選択・組み合わせることが重要です。
    この学習経験を活かして、データドリブンな意思決定と継続的改善に取り組んでください。
    """)