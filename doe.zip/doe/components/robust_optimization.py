import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
from utils.common import PROCESS_MODEL

def show_robust_optimization():
    st.markdown('<h1 class="section-header">🛡️ ロバスト最適化</h1>', unsafe_allow_html=True)
    
    st.markdown("## 📖 ロバスト最適化とは")
    st.markdown("""
    <div class="info-box">
    ロバスト最適化は、不確実性やばらつきが存在する環境下で、
    最悪の場合でも許容可能な性能を保証する最適化手法です。
    従来の最適化が期待値を最大化するのに対し、リスクを考慮した意思決定を行います。
    </div>
    """, unsafe_allow_html=True)
    
    # ロバスト最適化の概念
    st.markdown("## 🧮 基本概念")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 🎯 確定的最適化 vs ロバスト最適化
        
        **確定的最適化:**
        - パラメータが確定値
        - max f(x)
        - 最良条件での最適解
        
        **ロバスト最適化:**
        - パラメータに不確実性
        - max min f(x,ξ) または max E[f(x,ξ)]
        - 不確実性を考慮した最適解
        """)
    
    with col2:
        st.markdown("""
        ### 📊 ロバスト性の指標
        
        **平均-分散アプローチ:**
        - 目的関数: μ(x) - λσ²(x)
        - μ: 期待値, σ²: 分散, λ: リスク回避度
        
        **ミニマックスアプローチ:**
        - 目的関数: min max f(x,ξ)
        - 最悪ケースでの最適化
        """)
    
    # ロバスト最適化のアプローチ
    st.markdown("## 🔧 主なアプローチ")
    
    tab1, tab2, tab3 = st.tabs(["平均-分散最適化", "ミニマックス最適化", "シナリオベース最適化"])
    
    with tab1:
        st.markdown("""
        ### 📈 平均-分散最適化
        
        **目的関数:**
        ```
        Robust Objective = E[f(x,ξ)] - λ·Var[f(x,ξ)]
        ```
        
        **特徴:**
        - 期待性能とばらつきのトレードオフ
        - λでリスク選好度を調整
        - 計算が比較的容易
        """)
    
    with tab2:
        st.markdown("""
        ### ⚔️ ミニマックス最適化
        
        **目的関数:**
        ```
        Robust Objective = min max f(x,ξ)
                           x   ξ∈Ξ
        ```
        
        **特徴:**
        - 最悪ケースでの最適化
        - 保守的な解が得られる
        - 計算が困難な場合がある
        """)
    
    with tab3:
        st.markdown("""
        ### 🎭 シナリオベース最適化
        
        **目的関数:**
        ```
        Robust Objective = Σ pᵢ·f(x,ξᵢ)
                          i
        ```
        
        **特徴:**
        - 複数シナリオの重み付き平均
        - 実務的で理解しやすい
        - シナリオ設定が重要
        """)
    
    # シミュレーション部分
    st.markdown("## 🎮 ロバスト最適化シミュレーション")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### パラメータ設定")
        
        # 最適化アプローチ
        approach = st.selectbox(
            "最適化アプローチ",
            ["平均-分散最適化", "ミニマックス最適化", "シナリオベース最適化"]
        )
        
        # 問題設定（2次元最適化問題）
        st.markdown("#### 目的関数設定")
        st.markdown("f(x₁,x₂,ξ) = a₁x₁ + a₂x₂ + b₁x₁² + b₂x₂² + c₁₂x₁x₂ + ξ")
        
        # 係数設定
        a1 = st.number_input("a₁ (x₁の1次係数)", value=10.0, key="robust_a1")
        a2 = st.number_input("a₂ (x₂の1次係数)", value=8.0, key="robust_a2")
        b1 = st.number_input("b₁ (x₁の2次係数)", value=-2.0, key="robust_b1")
        b2 = st.number_input("b₂ (x₂の2次係数)", value=-1.5, key="robust_b2")
        c12 = st.number_input("c₁₂ (交互作用係数)", value=0.5, key="robust_c12")
        
        # 不確実性パラメータ
        st.markdown("#### 不確実性設定")
        
        if approach == "平均-分散最適化":
            noise_std = st.slider("ノイズ標準偏差 (σ)", 0.1, 5.0, 1.0)
            risk_aversion = st.slider("リスク回避度 (λ)", 0.0, 2.0, 0.5)
        elif approach == "ミニマックス最適化":
            noise_range = st.slider("ノイズ範囲 (±)", 0.1, 5.0, 2.0)
        else:  # シナリオベース
            n_scenarios = st.slider("シナリオ数", 3, 10, 5)
            scenario_range = st.slider("シナリオ範囲 (±)", 0.1, 5.0, 2.0)
        
        # 制約条件
        st.markdown("#### 制約条件")
        x1_min = st.number_input("x₁の下限", value=-5.0, key="robust_x1_min")
        x1_max = st.number_input("x₁の上限", value=5.0, key="robust_x1_max")
        x2_min = st.number_input("x₂の下限", value=-5.0, key="robust_x2_min")
        x2_max = st.number_input("x₂の上限", value=5.0, key="robust_x2_max")
        
        optimize_button = st.button("最適化実行", type="primary", key="robust_optimize")
    
    with col2:
        if optimize_button or 'robust_result' not in st.session_state:
            
            # 目的関数の定義
            def objective_function(x1, x2, noise=0):
                return a1*x1 + a2*x2 + b1*x1**2 + b2*x2**2 + c12*x1*x2 + noise
            
            # グリッド探索による最適化（簡単化）
            x1_grid = np.linspace(x1_min, x1_max, 50)
            x2_grid = np.linspace(x2_min, x2_max, 50)
            
            best_x1, best_x2 = None, None
            best_value = -np.inf
            
            # 結果保存用
            grid_results = []
            
            for x1 in x1_grid:
                for x2 in x2_grid:
                    if approach == "平均-分散最適化":
                        # モンテカルロシミュレーションで期待値と分散を計算
                        np.random.seed(42)
                        noises = np.random.normal(0, noise_std, 1000)
                        values = [objective_function(x1, x2, noise) for noise in noises]
                        
                        mean_val = np.mean(values)
                        var_val = np.var(values)
                        robust_value = mean_val - risk_aversion * var_val
                        
                    elif approach == "ミニマックス最適化":
                        # 最悪ケース（最小値）を計算
                        worst_case_noises = [-noise_range, noise_range]
                        values = [objective_function(x1, x2, noise) for noise in worst_case_noises]
                        robust_value = min(values)
                        mean_val = np.mean(values)
                        var_val = np.var(values)
                        
                    else:  # シナリオベース
                        # 等間隔のシナリオを生成
                        scenarios = np.linspace(-scenario_range, scenario_range, n_scenarios)
                        values = [objective_function(x1, x2, noise) for noise in scenarios]
                        robust_value = np.mean(values)  # 等重みで平均
                        mean_val = np.mean(values)
                        var_val = np.var(values)
                    
                    grid_results.append({
                        'x1': x1, 'x2': x2, 
                        'robust_value': robust_value,
                        'mean_value': mean_val,
                        'variance': var_val
                    })
                    
                    if robust_value > best_value:
                        best_value = robust_value
                        best_x1, best_x2 = x1, x2
            
            # 比較のため、確定的最適化も実行
            deterministic_best_value = -np.inf
            deterministic_best_x1, deterministic_best_x2 = None, None
            
            for x1 in x1_grid:
                for x2 in x2_grid:
                    det_value = objective_function(x1, x2, 0)  # ノイズなし
                    if det_value > deterministic_best_value:
                        deterministic_best_value = det_value
                        deterministic_best_x1, deterministic_best_x2 = x1, x2
            
            # 結果を保存
            results = {
                'approach': approach,
                'robust_optimal': (best_x1, best_x2, best_value),
                'deterministic_optimal': (deterministic_best_x1, deterministic_best_x2, deterministic_best_value),
                'grid_results': pd.DataFrame(grid_results),
                'parameters': {
                    'a1': a1, 'a2': a2, 'b1': b1, 'b2': b2, 'c12': c12,
                    'noise_std': noise_std if approach == "平均-分散最適化" else None,
                    'risk_aversion': risk_aversion if approach == "平均-分散最適化" else None,
                    'noise_range': noise_range if approach == "ミニマックス最適化" else None,
                    'n_scenarios': n_scenarios if approach == "シナリオベース最適化" else None
                }
            }
            
            st.session_state.robust_result = results
        
        if 'robust_result' in st.session_state:
            results = st.session_state.robust_result
            
            # 最適化結果の表示
            st.markdown("### 🎯 最適化結果")
            
            robust_x1, robust_x2, robust_val = results['robust_optimal']
            det_x1, det_x2, det_val = results['deterministic_optimal']
            
            col_a, col_b = st.columns(2)
            
            with col_a:
                st.markdown("#### 🛡️ ロバスト最適解")
                st.write(f"**x₁ = {robust_x1:.3f}**")
                st.write(f"**x₂ = {robust_x2:.3f}**")
                st.write(f"**目的関数値 = {robust_val:.3f}**")
            
            with col_b:
                st.markdown("#### 📊 確定的最適解")
                st.write(f"**x₁ = {det_x1:.3f}**")
                st.write(f"**x₂ = {det_x2:.3f}**")
                st.write(f"**目的関数値 = {det_val:.3f}**")
            
            # 目的関数の等高線プロット
            st.markdown("### 🗺️ 最適化結果の可視化")
            
            df_grid = results['grid_results']
            
            # 等高線図の作成
            fig = px.scatter(df_grid, x='x1', y='x2', color='robust_value',
                           title=f'{results["approach"]}による最適化結果',
                           color_continuous_scale='Viridis')
            
            # 最適点をマーク
            fig.add_scatter(x=[robust_x1], y=[robust_x2], 
                          mode='markers', marker_size=15, marker_color='red',
                          name='ロバスト最適点')
            fig.add_scatter(x=[det_x1], y=[det_x2], 
                          mode='markers', marker_size=15, marker_color='orange',
                          name='確定的最適点')
            
            fig.update_layout(height=500)
            st.plotly_chart(fig, use_container_width=True)
    
    # ロバスト性の評価
    if 'robust_result' in st.session_state:
        results = st.session_state.robust_result
        
        st.markdown("## 📊 ロバスト性の評価")
        
        # モンテカルロシミュレーションで性能を比較
        np.random.seed(42)
        n_simulations = 1000
        
        robust_x1, robust_x2, _ = results['robust_optimal']
        det_x1, det_x2, _ = results['deterministic_optimal']
        
        # 目的関数の定義（再定義）
        params = results['parameters']
        def objective_function(x1, x2, noise=0):
            return params['a1']*x1 + params['a2']*x2 + params['b1']*x1**2 + params['b2']*x2**2 + params['c12']*x1*x2 + noise
        
        # ノイズを発生させて性能を評価
        noises = np.random.normal(0, 2.0, n_simulations)  # 標準偏差2.0のノイズ
        
        robust_performances = []
        det_performances = []
        
        for noise in noises:
            robust_perf = objective_function(robust_x1, robust_x2, noise)
            det_perf = objective_function(det_x1, det_x2, noise)
            
            robust_performances.append(robust_perf)
            det_performances.append(det_perf)
        
        # 性能統計
        robust_stats = {
            '平均': np.mean(robust_performances),
            '標準偏差': np.std(robust_performances),
            '最小値': np.min(robust_performances),
            '最大値': np.max(robust_performances),
            '5%パーセンタイル': np.percentile(robust_performances, 5)
        }
        
        det_stats = {
            '平均': np.mean(det_performances),
            '標準偏差': np.std(det_performances),
            '最小値': np.min(det_performances),
            '最大値': np.max(det_performances),
            '5%パーセンタイル': np.percentile(det_performances, 5)
        }
        
        # 統計表の表示
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### 🛡️ ロバスト最適解の性能")
            robust_df = pd.DataFrame(list(robust_stats.items()), 
                                   columns=['統計量', '値'])
            st.dataframe(robust_df.round(3))
        
        with col2:
            st.markdown("#### 📊 確定的最適解の性能")
            det_df = pd.DataFrame(list(det_stats.items()), 
                                columns=['統計量', '値'])
            st.dataframe(det_df.round(3))
        
        # 性能分布の比較
        st.markdown("### 📈 性能分布の比較")
        
        performance_data = pd.DataFrame({
            'Performance': robust_performances + det_performances,
            'Method': ['ロバスト最適化'] * len(robust_performances) + 
                     ['確定的最適化'] * len(det_performances)
        })
        
        fig_hist = px.histogram(performance_data, x='Performance', color='Method',
                               marginal='box', nbins=50, opacity=0.7,
                               title='性能分布の比較')
        fig_hist.update_layout(height=500)
        st.plotly_chart(fig_hist, use_container_width=True)
        
        # データダウンロード
        st.markdown("### 💾 データダウンロード")
        csv_performance = performance_data.to_csv(index=False)
        st.download_button(
            label="性能データをダウンロード",
            data=csv_performance,
            file_name="robust_optimization_performance.csv",
            mime="text/csv"
        )