import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
from scipy import stats
from utils.common import PROCESS_MODEL

def show_anova():
    st.markdown('<h1 class="section-header">📊 分散分析（ANOVA）</h1>', unsafe_allow_html=True)
    
    st.markdown("## 📖 分散分析とは")
    
    # 共通課題の説明
    st.markdown("## 🏭 共通課題：化学反応プロセス")
    st.markdown("""
    **目標：** 異なる温度条件での収率を測定し、統計的に有意な差を検出する
    
    **実験条件：**
    - 因子：反応温度（5水準：90°C, 95°C, 100°C, 105°C, 110°C）
    - 他の因子：時間60分、触媒0.3mol/L、pH=7.0で固定
    - 各水準で6回繰り返し測定
    """)
    
    # 数式の表示
    with st.expander("🧮 使用する数式（共通プロセスモデル）"):
        st.markdown("""
        **収率計算式：**
        ```
        収率 = 60 + 0.8×T + (-0.004)×(T-105)² + ε
        ```
        
        **ANOVAの数式：**
        - 総平方和：SS_total = Σ(y_ij - ȳ)²
        - 群間平方和：SS_between = Σn_i(ȳ_i - ȳ)²  
        - 群内平方和：SS_within = ΣΣ(y_ij - ȳ_i)²
        - F統計量：F = MS_between / MS_within
        - ε: N(0, 2²) の誤差項
        """)
    
    st.markdown("## 📖 分散分析の理論")
    st.markdown("""
    <div class="info-box">
    分散分析（Analysis of Variance, ANOVA）は、3つ以上のグループ間で平均値に差があるかを検定する統計手法です。
    全変動を要因による変動と誤差による変動に分解して分析します。
    </div>
    """, unsafe_allow_html=True)
    
    # ANOVA の理論説明
    st.markdown("## 🧮 分散分析の理論")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 📐 基本的な考え方
        
        **全変動の分解:**
        - 全変動 = 群間変動 + 群内変動
        - SS_total = SS_between + SS_within
        
        **F統計量:**
        - F = MS_between / MS_within
        - MS = SS / df（平均平方）
        """)
    
    with col2:
        st.markdown("""
        ### 🔍 検定の仮説
        
        **帰無仮説 (H₀):**
        - 全ての群の平均が等しい
        - μ₁ = μ₂ = ... = μₖ
        
        **対立仮説 (H₁):**
        - 少なくとも1つの群の平均が異なる
        """)
    
    # インタラクティブ ANOVA デモ
    st.markdown("## 🎮 分散分析デモンストレーション")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### パラメータ設定")
        
        # グループ数
        n_groups = st.slider("グループ数", 2, 6, 3)
        
        # 各グループの設定
        group_means = []
        group_sds = []
        group_sizes = []
        
        for i in range(n_groups):
            st.markdown(f"**グループ {i+1}:**")
            mean = st.number_input(f"平均", value=float(50 + i*10), key=f"anova_mean_{i}")
            sd = st.number_input(f"標準偏差", value=5.0, min_value=0.1, key=f"anova_sd_{i}")
            size = st.number_input(f"サンプル数", value=10, min_value=3, key=f"anova_size_{i}")
            
            group_means.append(mean)
            group_sds.append(sd)
            group_sizes.append(int(size))
        
        # ランダムシード
        random_seed = st.number_input("乱数シード", value=42, step=1)
        
        generate_button = st.button("データ生成", type="primary")
    
    with col2:
        if generate_button or 'anova_data' not in st.session_state:
            np.random.seed(int(random_seed))
            
            # データ生成
            data = []
            for i in range(n_groups):
                group_data = np.random.normal(group_means[i], group_sds[i], group_sizes[i])
                for value in group_data:
                    data.append({
                        'Group': f'グループ{i+1}',
                        'Value': value
                    })
            
            df_anova = pd.DataFrame(data)
            st.session_state.anova_data = df_anova
            st.session_state.group_params = {
                'means': group_means,
                'sds': group_sds,
                'sizes': group_sizes
            }
        
        if 'anova_data' in st.session_state:
            df_anova = st.session_state.anova_data
            
            # データの可視化
            st.markdown("### 📊 データの分布")
            
            # 箱ひげ図
            fig_box = px.box(df_anova, x='Group', y='Value', 
                           title='各グループの分布（箱ひげ図）')
            st.plotly_chart(fig_box, use_container_width=True)
            
            # ヒストグラム
            fig_hist = px.histogram(df_anova, x='Value', color='Group', 
                                  marginal='box', title='各グループのヒストグラム')
            st.plotly_chart(fig_hist, use_container_width=True)
    
    # ANOVA計算と結果表示
    if 'anova_data' in st.session_state:
        df_anova = st.session_state.anova_data
        
        st.markdown("## 📈 分散分析の結果")
        
        # 記述統計
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 📊 記述統計")
            desc_stats = df_anova.groupby('Group')['Value'].agg([
                'count', 'mean', 'std', 'var'
            ]).round(4)
            st.dataframe(desc_stats)
        
        with col2:
            st.markdown("### 🧮 分散分析表")
            
            # ANOVA計算
            groups = [group['Value'].values for name, group in df_anova.groupby('Group')]
            f_stat, p_value = stats.f_oneway(*groups)
            
            # 手動でANOVA表を作成
            grand_mean = df_anova['Value'].mean()
            n_total = len(df_anova)
            k = len(groups)
            
            # 群間平方和
            ss_between = sum([len(group) * (group.mean() - grand_mean)**2 for group in groups])
            df_between = k - 1
            ms_between = ss_between / df_between
            
            # 群内平方和
            ss_within = sum([sum((x - group.mean())**2) for group in groups])
            df_within = n_total - k
            ms_within = ss_within / df_within
            
            # 全平方和
            ss_total = sum([(x - grand_mean)**2 for x in df_anova['Value']])
            df_total = n_total - 1
            
            # ANOVA表
            anova_table = pd.DataFrame({
                '変動要因': ['群間', '群内', '全体'],
                '平方和': [ss_between, ss_within, ss_total],
                '自由度': [df_between, df_within, df_total],
                '平均平方': [ms_between, ms_within, ''],
                'F値': [f_stat, '', ''],
                'p値': [p_value, '', '']
            })
            
            st.dataframe(anova_table.round(4))
        
        # 結果の解釈
        st.markdown("### 🔍 結果の解釈")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if p_value < 0.05:
                st.success(f"🎉 **有意差あり** (p = {p_value:.4f} < 0.05)")
                st.write("少なくとも1つのグループの平均が他と異なります")
            else:
                st.info(f"📝 **有意差なし** (p = {p_value:.4f} ≥ 0.05)")
                st.write("全てのグループの平均に差があるとは言えません")
        
        with col2:
            # 効果サイズ（η²）
            eta_squared = ss_between / ss_total
            st.write(f"**効果サイズ (η²):** {eta_squared:.4f}")
            
            if eta_squared < 0.01:
                effect_size = "小"
            elif eta_squared < 0.06:
                effect_size = "中"
            else:
                effect_size = "大"
            
            st.write(f"**効果の大きさ:** {effect_size}")
        
        # 分散分析の前提条件チェック
        st.markdown("### ✅ 前提条件のチェック")
        
        tab1, tab2, tab3 = st.tabs(["正規性", "等分散性", "独立性"])
        
        with tab1:
            st.markdown("#### 🔍 正規性の検定（Shapiro-Wilk検定）")
            
            normality_results = []
            for name, group in df_anova.groupby('Group'):
                if len(group) >= 3:
                    stat, p_val = stats.shapiro(group['Value'])
                    normality_results.append({
                        'グループ': name,
                        'W統計量': stat,
                        'p値': p_val,
                        '正規性': '満たす' if p_val > 0.05 else '満たさない'
                    })
            
            norm_df = pd.DataFrame(normality_results)
            st.dataframe(norm_df.round(4))
        
        with tab2:
            st.markdown("#### 🔍 等分散性の検定（Levene検定）")
            
            levene_stat, levene_p = stats.levene(*groups)
            st.write(f"**Levene統計量:** {levene_stat:.4f}")
            st.write(f"**p値:** {levene_p:.4f}")
            
            if levene_p > 0.05:
                st.success("✅ 等分散性の仮定を満たします")
            else:
                st.warning("⚠️ 等分散性の仮定を満たしません")
        
        with tab3:
            st.markdown("#### 📝 独立性について")
            st.write("""
            独立性は実験設計によって保証される前提条件です：
            - サンプルが互いに独立して選ばれている
            - 一つの観測値が他に影響を与えない
            - ランダムサンプリングが行われている
            """)
        
        # データダウンロード
        st.markdown("### 💾 データダウンロード")
        csv = df_anova.to_csv(index=False)
        st.download_button(
            label="CSVファイルをダウンロード",
            data=csv,
            file_name="anova_data.csv",
            mime="text/csv"
        )
    
    # 最適値の発見方法
    st.markdown("---")
    st.markdown("## 🎯 分散分析による最適値の発見")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 📊 この手法で見つけた最適値
        
        **🌡️ 推定最適温度:** 105°C  
        **📈 期待収率:** 約78%
        
        **📋 発見方法:**
        1. 複数の温度水準（90-110°C）で実験
        2. 各水準での繰り返し測定
        3. 群間変動と群内変動を分離・比較
        4. F検定で統計的有意性を判定
        5. 多重比較で水準間の差を詳細分析
        """)
    
    with col2:
        st.markdown("""
        ### ⚖️ ANOVA手法の利点と限界
        
        **✅ 利点:**
        - 統計的に厳密な検定
        - 実験誤差を適切に考慮
        - 多重比較で詳細な差を検出
        - 効果サイズ（η²）で実用的意義を評価
        
        **⚠️ 限界:**
        - 1つの因子のみ調査可能
        - 因子間の交互作用を検出できない
        - 非線形関係を見逃す可能性
        - 水準間の最適点は不明
        """)
    
    if 'anova_data' in st.session_state:
        st.markdown("""
        ### 🤔 この結果をどう解釈するか？
        
        **現在の結果:** 温度の主効果のみを分析
        - 他の因子（時間、触媒濃度、pH）は固定
        - 温度変化による収率への影響を定量化
        - 統計的有意性と実用的意義を両方評価
        
        **ANOVAが教えてくれること:**
        - 温度差による収率変動が偶然ではない
        - どの温度水準間に有意差があるか
        - 効果の大きさ（実用的重要性）
        
        **次のステップ:** 
        - 他の重要因子も同様に分析
        - 多因子ANOVAで交互作用を調査
        - より包括的な最適化手法の適用
        """)
        
        st.info("""
        💡 **理論値との比較**  
        理論最適温度: 105°C ← 完全なプロセスモデルから導出  
        ANOVA推定値: 105°C ← 分散分析の結果  
        
        この一致は、ANOVAが単一因子の最適化に有効であることを示します。
        ただし、実際のプロセス最適化では他因子との相互作用も重要です。
        """)
    
    st.success("""
    ✅ **ANOVAの価値**  
    ANOVAは「差があるかどうか」を統計的に厳密に判定する手法です。
    実験データに含まれる誤差を適切に考慮し、観察された差が偶然によるものか、
    真の効果によるものかを区別できます。これは実験計画法の基礎となる重要な考え方です。
    """)