import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
from itertools import product
from utils.common import PROCESS_MODEL

def show_taguchi():
    st.markdown('<h1 class="section-header">🎯 パラメータ設計（タグチメソッド）</h1>', unsafe_allow_html=True)
    
    st.markdown("## 📖 タグチメソッドとは")
    st.markdown("""
    <div class="info-box">
    タグチメソッド（品質工学）は、製品やプロセスのばらつきを最小化し、
    外的要因（ノイズ）に対してロバストな条件を見つける手法です。
    SN比（Signal-to-Noise ratio）を最大化することで品質の向上を図ります。
    </div>
    """, unsafe_allow_html=True)
    
    # タグチメソッドの基本概念
    st.markdown("## 🧮 基本概念")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 🎯 制御因子（Control Factors）
        - 設計者が制御できる因子
        - 製品の機能に影響する
        - 例：材料、寸法、工程条件
        
        ### 🌪️ ノイズ因子（Noise Factors）
        - 制御が困難または不経済な因子
        - ばらつきの原因となる
        - 例：環境条件、劣化、個体差
        """)
    
    with col2:
        st.markdown("""
        ### 📊 SN比（Signal-to-Noise Ratio）
        - 信号（有用な効果）とノイズ（ばらつき）の比
        - 品質の指標として使用
        - SN比が大きいほど頑健
        
        **主なSN比:**
        - 望目特性：η = -10log₁₀(σ²)
        - 望小特性：η = -10log₁₀(Σy²/n)
        - 望大特性：η = -10log₁₀(Σ(1/y²)/n)
        """)
    
    # シミュレーション部分
    st.markdown("## 🎮 タグチメソッドシミュレーション")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### パラメータ設定")
        
        # SN比の種類選択
        sn_type = st.selectbox(
            "SN比の種類",
            ["望目特性", "望小特性", "望大特性"]
        )
        
        # 制御因子数
        n_control = st.slider("制御因子数", 2, 4, 3)
        
        # 制御因子の設定
        control_effects = []
        control_names = []
        for i in range(n_control):
            name = st.text_input(f"制御因子{i+1}の名前", value=f"A{i+1}", key=f"control_{i}")
            effect = st.number_input(f"{name}の効果", value=float(2.0 + i), key=f"control_effect_{i}")
            control_names.append(name)
            control_effects.append(effect)
        
        # ノイズ因子数
        n_noise = st.slider("ノイズ因子数", 1, 3, 2)
        
        # ノイズ因子の設定
        noise_effects = []
        noise_names = []
        for i in range(n_noise):
            name = st.text_input(f"ノイズ因子{i+1}の名前", value=f"N{i+1}", key=f"noise_{i}")
            effect = st.number_input(f"{name}の効果", value=float(1.0 + i*0.5), key=f"noise_effect_{i}")
            noise_names.append(name)
            noise_effects.append(effect)
        
        # 目標値（望目特性の場合）
        if sn_type == "望目特性":
            target_value = st.number_input("目標値", value=100.0)
        
        # 基準応答値
        baseline = st.number_input("基準応答値", value=50.0, key="taguchi_baseline")
        
        # 誤差の標準偏差
        error_std = st.slider("誤差の標準偏差", 0.1, 5.0, 1.0, key="taguchi_error")
        
        # 反復数
        n_replicates = st.slider("反復数", 2, 5, 3, key="taguchi_reps")
        
        # ランダムシード
        random_seed = st.number_input("乱数シード", value=42, step=1, key="taguchi_seed")
        
        generate_button = st.button("実験実行", type="primary", key="taguchi_generate")
    
    with col2:
        if generate_button or 'taguchi_data' not in st.session_state:
            np.random.seed(int(random_seed))
            
            # L9直交配列（3因子、3水準）を簡単化してL4（2水準）を使用
            if n_control <= 3:
                # L4直交配列（3因子まで）
                orthogonal_array = [
                    [0, 0, 0],
                    [0, 1, 1],
                    [1, 0, 1],
                    [1, 1, 0]
                ]
            else:
                # L8直交配列（4因子）
                orthogonal_array = [
                    [0, 0, 0, 0],
                    [0, 0, 1, 1],
                    [0, 1, 0, 1],
                    [0, 1, 1, 0],
                    [1, 0, 0, 1],
                    [1, 0, 1, 0],
                    [1, 1, 0, 0],
                    [1, 1, 1, 1]
                ]
            
            # ノイズ条件の組み合わせ
            noise_combinations = list(product([0, 1], repeat=n_noise))
            
            data = []
            sn_ratios = []
            
            for exp_no, control_levels in enumerate(orthogonal_array[:2**n_control]):
                control_condition = control_levels[:n_control]
                
                # 各ノイズ条件での応答値を計算
                responses_per_noise = []
                
                for noise_levels in noise_combinations:
                    for rep in range(n_replicates):
                        # 応答値の計算
                        response = baseline
                        
                        # 制御因子の効果
                        for i, level in enumerate(control_condition):
                            if level == 1:  # 高水準
                                response += control_effects[i]
                        
                        # ノイズ因子の効果
                        for i, level in enumerate(noise_levels):
                            if level == 1:  # ノイズ発生条件
                                response += np.random.normal(0, noise_effects[i])
                        
                        # 誤差の追加
                        response += np.random.normal(0, error_std)
                        
                        responses_per_noise.append(max(response, 0.1))  # 負の値を避ける
                        
                        # データの記録
                        row = {
                            'Exp_No': exp_no + 1,
                            'Response': max(response, 0.1),
                            'Replicate': rep + 1
                        }
                        
                        # 制御因子の記録
                        for i, level in enumerate(control_condition):
                            row[control_names[i]] = '高' if level == 1 else '低'
                        
                        # ノイズ因子の記録
                        for i, level in enumerate(noise_levels):
                            row[f"{noise_names[i]}"] = 'ON' if level == 1 else 'OFF'
                        
                        data.append(row)
                
                # SN比の計算
                responses = responses_per_noise
                
                if sn_type == "望目特性":
                    # SN比 = 10*log10((平均-目標値)²/分散)の逆数
                    mean_resp = np.mean(responses)
                    var_resp = np.var(responses, ddof=1)
                    sn_ratio = -10 * np.log10(var_resp + (mean_resp - target_value)**2)
                elif sn_type == "望小特性":
                    # SN比 = -10*log10(平均(y²))
                    sn_ratio = -10 * np.log10(np.mean([y**2 for y in responses]))
                else:  # 望大特性
                    # SN比 = -10*log10(平均(1/y²))
                    sn_ratio = -10 * np.log10(np.mean([1/y**2 for y in responses]))
                
                sn_ratios.append({
                    'Exp_No': exp_no + 1,
                    'SN_Ratio': sn_ratio,
                    'Mean_Response': np.mean(responses),
                    **{control_names[i]: '高' if control_condition[i] == 1 else '低' 
                       for i in range(n_control)}
                })
            
            df_taguchi = pd.DataFrame(data)
            df_sn = pd.DataFrame(sn_ratios)
            
            st.session_state.taguchi_data = df_taguchi
            st.session_state.taguchi_sn = df_sn
            st.session_state.taguchi_params = {
                'control_names': control_names,
                'noise_names': noise_names,
                'sn_type': sn_type,
                'n_control': n_control
            }
        
        if 'taguchi_data' in st.session_state:
            df_taguchi = st.session_state.taguchi_data
            df_sn = st.session_state.taguchi_sn
            params = st.session_state.taguchi_params
            
            # 実験データの表示
            st.markdown("### 📊 実験データ")
            st.dataframe(df_taguchi.head(10))
            
            # SN比の表示
            st.markdown("### 📈 SN比の結果")
            st.dataframe(df_sn)
    
    # 解析結果の表示
    if 'taguchi_sn' in st.session_state:
        df_sn = st.session_state.taguchi_sn
        params = st.session_state.taguchi_params
        control_names = params['control_names']
        
        st.markdown("## 📈 解析結果")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 🎯 SN比による因子効果")
            
            # 各制御因子のSN比への効果を計算
            factor_effects = {}
            
            for factor in control_names:
                high_sn = df_sn[df_sn[factor] == '高']['SN_Ratio'].mean()
                low_sn = df_sn[df_sn[factor] == '低']['SN_Ratio'].mean()
                factor_effects[factor] = high_sn - low_sn
            
            effects_df = pd.DataFrame(list(factor_effects.items()), 
                                    columns=['因子', 'SN比効果'])
            effects_df = effects_df.sort_values('SN比効果', ascending=False)
            
            st.dataframe(effects_df.round(3))
            
            # 最適条件の推定
            st.markdown("### 🏆 推奨設定")
            optimal_settings = {}
            for factor in control_names:
                high_sn = df_sn[df_sn[factor] == '高']['SN_Ratio'].mean()
                low_sn = df_sn[df_sn[factor] == '低']['SN_Ratio'].mean()
                optimal_settings[factor] = '高' if high_sn > low_sn else '低'
            
            for factor, setting in optimal_settings.items():
                st.write(f"**{factor}:** {setting}水準")
        
        with col2:
            st.markdown("### 📊 因子効果の可視化")
            
            # 因子効果のグラフ
            fig, ax = plt.subplots(figsize=(8, 6))
            factors = list(factor_effects.keys())
            effects = list(factor_effects.values())
            
            colors = ['red' if e > 0 else 'blue' for e in effects]
            bars = ax.bar(factors, effects, color=colors, alpha=0.7)
            
            ax.set_xlabel('制御因子')
            ax.set_ylabel('SN比効果')
            ax.set_title('制御因子のSN比への効果')
            ax.axhline(y=0, color='black', linestyle='-', alpha=0.3)
            ax.grid(True, alpha=0.3)
            
            # 値をバーの上に表示
            for bar, effect in zip(bars, effects):
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height + 0.1 if height > 0 else height - 0.3,
                       f'{effect:.2f}', ha='center', va='bottom' if height > 0 else 'top')
            
            st.pyplot(fig)
            plt.close()
        
        # SN比と平均値の散布図
        st.markdown("### 🔍 SN比 vs 平均応答値")
        
        fig_scatter = px.scatter(df_sn, x='Mean_Response', y='SN_Ratio',
                               hover_data=['Exp_No'] + control_names,
                               title='SN比と平均応答値の関係')
        fig_scatter.update_layout(height=500)
        st.plotly_chart(fig_scatter, use_container_width=True)
        
        # データダウンロード
        st.markdown("### 💾 データダウンロード")
        col1, col2 = st.columns(2)
        
        with col1:
            csv_data = st.session_state.taguchi_data.to_csv(index=False)
            st.download_button(
                label="実験データをダウンロード",
                data=csv_data,
                file_name="taguchi_experiment_data.csv",
                mime="text/csv"
            )
        
        with col2:
            csv_sn = df_sn.to_csv(index=False)
            st.download_button(
                label="SN比データをダウンロード",
                data=csv_sn,
                file_name="taguchi_sn_ratio_data.csv",
                mime="text/csv"
            )