import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
from scipy import stats
from itertools import product
from utils.common import PROCESS_MODEL

def show_factorial():
    st.markdown('<h1 class="section-header">⚗️ 多因子実験（2^k実験）</h1>', unsafe_allow_html=True)
    
    st.markdown("## 📖 2^k実験とは")
    st.markdown("""
    <div class="info-box">
    2^k実験は、k個の因子をそれぞれ2水準（高水準・低水準）で組み合わせた実験計画です。
    主効果だけでなく、因子間の交互作用も効率的に調べることができます。
    </div>
    """, unsafe_allow_html=True)
    
    # 共通課題の説明
    st.markdown("## 🏭 共通課題：化学反応プロセス")
    st.markdown("""
    **目標：** 4つの因子（温度、時間、触媒濃度、pH）が収率に与える主効果と交互作用を調査する
    
    **実験条件：**
    - 因子A：反応温度（低水準95°C、高水準105°C）
    - 因子B：反応時間（低水準45分、高水準75分）
    - 因子C：触媒濃度（低水準0.2mol/L、高水準0.4mol/L）
    - 因子D：pH（低水準6.5、高水準7.5）
    - 実験計画：2⁴完全実施計画（16回実験）
    """)
    
    # 数式の表示
    with st.expander("🧮 使用する数式（共通プロセスモデル）"):
        st.markdown("""
        **収率計算式（完全版）：**
        ```
        収率 = 60 + 0.8×T + (-0.004)×(T-105)² + 0.3×t + (-0.002)×(t-60)²
             + 50×C + (-30)×(C-0.3)² + 2×(pH-7)
             + 0.01×(T-100)×(t-60) + (-10)×(T-100)×(C-0.3) + ε
        ```
        
        **2水準での値：**
        - T: 95°C（低）, 105°C（高）
        - t: 45分（低）, 75分（高）  
        - C: 0.2mol/L（低）, 0.4mol/L（高）
        - pH: 6.5（低）, 7.5（高）
        - ε: N(0, 2²) の誤差項
        """)
    
    # シミュレーション部分
    st.markdown("## 🎮 2⁴実験シミュレーション")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### 実験設定")
        
        # 因子レベルの確認
        st.markdown("**因子水準：**")
        st.write("- **温度：** 95°C（低）/ 105°C（高）")
        st.write("- **時間：** 45分（低）/ 75分（高）") 
        st.write("- **触媒：** 0.2mol/L（低）/ 0.4mol/L（高）")
        st.write("- **pH：** 6.5（低）/ 7.5（高）")
        
        st.markdown("---")
        
        # 実験オプション
        include_replicates = st.checkbox("反復実験を含める", value=True)
        n_replicates = 2 if include_replicates else 1
        
        # ランダムシード
        random_seed = st.number_input("乱数シード", value=42, step=1)
        
        # データ生成
        generate_button = st.button("2⁴実験実行", type="primary")
    
    with col2:
        if generate_button or 'factorial_data' not in st.session_state:
            np.random.seed(int(random_seed))
            
            # 2^4実験条件の生成
            factor_levels = list(product([0, 1], repeat=4))
            factor_names = ['Temperature', 'Time', 'Catalyst', 'pH']
            
            # 因子水準の実際値
            level_values = {
                'Temperature': [95, 105],  # 低水準, 高水準
                'Time': [45, 75],
                'Catalyst': [0.2, 0.4],
                'pH': [6.5, 7.5]
            }
            
            data = []
            for run_no, levels in enumerate(factor_levels):
                for rep in range(n_replicates):
                    # 実際の因子値
                    temp = level_values['Temperature'][levels[0]]
                    time = level_values['Time'][levels[1]]
                    catalyst = level_values['Catalyst'][levels[2]]
                    ph = level_values['pH'][levels[3]]
                    
                    # 共通プロセスモデルを使用して収率計算
                    noise = np.random.normal(0, PROCESS_MODEL.yield_params['error_std'])
                    yield_val = PROCESS_MODEL.yield_function(temp, time, catalyst, ph, noise)
                    
                    # データの記録
                    data.append({
                        'Run': run_no + 1,
                        'Temperature': '高' if levels[0] == 1 else '低',
                        'Time': '高' if levels[1] == 1 else '低',
                        'Catalyst': '高' if levels[2] == 1 else '低',
                        'pH': '高' if levels[3] == 1 else '低',
                        'Temp_coded': levels[0],
                        'Time_coded': levels[1],
                        'Catalyst_coded': levels[2],
                        'pH_coded': levels[3],
                        'Temp_actual': temp,
                        'Time_actual': time,
                        'Catalyst_actual': catalyst,
                        'pH_actual': ph,
                        'Yield': yield_val,
                        'Replicate': rep + 1
                    })
            
            df = pd.DataFrame(data)
            st.session_state.factorial_data = df
            st.session_state.factor_names = factor_names
        
        if 'factorial_data' in st.session_state:
            df = st.session_state.factorial_data
            factor_names = st.session_state.factor_names
            
            # データの表示
            st.markdown("### 📊 2⁴実験データ")
            display_cols = ['Run', 'Temperature', 'Time', 'Catalyst', 'pH', 'Yield']
            if include_replicates:
                display_cols.append('Replicate')
            st.dataframe(df[display_cols])
            
            # 主効果の可視化
            st.markdown("### 📈 主効果の可視化")
            
            fig, axes = plt.subplots(2, 2, figsize=(12, 8))
            axes = axes.ravel()
            
            for i, factor in enumerate(factor_names):
                means = df.groupby(factor)['Yield'].mean()
                axes[i].bar(means.index, means.values, color=['lightblue', 'lightcoral'])
                axes[i].set_xlabel(factor)
                axes[i].set_ylabel('平均収率 (%)')
                axes[i].set_title(f'{factor}の主効果')
                
                # 効果の大きさを表示
                effect_size = means['高'] - means['低']
                axes[i].text(0.5, axes[i].get_ylim()[1]*0.9, 
                           f'効果: {effect_size:.2f}%', 
                           ha='center', fontweight='bold')
            
            plt.tight_layout()
            st.pyplot(fig)
            plt.close()
            
            # 交互作用プロット
            st.markdown("### 🔄 主要な交互作用プロット")
            
            # Temperature × Time の交互作用
            interaction_data = []
            for temp in ['低', '高']:
                for time in ['低', '高']:
                    mean_yield = df[(df['Temperature'] == temp) & (df['Time'] == time)]['Yield'].mean()
                    interaction_data.append({
                        'Temperature': temp,
                        'Time': time,
                        'Yield': mean_yield
                    })
            
            interaction_df = pd.DataFrame(interaction_data)
            fig_interaction = px.line(interaction_df, x='Temperature', y='Yield', color='Time',
                                   title='温度×時間の交互作用', markers=True)
            st.plotly_chart(fig_interaction, use_container_width=True)
    
    # 統計解析
    if 'factorial_data' in st.session_state:
        st.markdown("## 📈 統計解析結果")
        
        df = st.session_state.factorial_data
        factor_names = st.session_state.factor_names
        k = 4  # 2^4実験
        
        # 効果の計算
        st.markdown("### 🔍 効果の推定")
        
        effects = {}
        
        # 主効果の計算
        for factor in factor_names:
            high_mean = df[df[factor] == '高']['Yield'].mean()
            low_mean = df[df[factor] == '低']['Yield'].mean()
            main_effect = high_mean - low_mean
            effects[factor] = main_effect
        
        # 2因子交互作用効果の計算
        if k >= 2:
            for i in range(k):
                for j in range(i+1, k):
                    factor_a = factor_names[i]
                    factor_b = factor_names[j]
                    
                    # 各組み合わせでの平均
                    high_high = df[(df[factor_a] == '高') & (df[factor_b] == '高')]['Yield'].mean()
                    high_low = df[(df[factor_a] == '高') & (df[factor_b] == '低')]['Yield'].mean()
                    low_high = df[(df[factor_a] == '低') & (df[factor_b] == '高')]['Yield'].mean()
                    low_low = df[(df[factor_a] == '低') & (df[factor_b] == '低')]['Yield'].mean()
                    
                    # 交互作用効果
                    interaction_effect = ((high_high - high_low) - (low_high - low_low)) / 2
                    effects[f"{factor_a}×{factor_b}"] = interaction_effect
        
        # 効果の表示
        effects_df = pd.DataFrame(list(effects.items()), columns=['効果', '推定値'])
        effects_df['推定値'] = effects_df['推定値'].round(3)
        st.dataframe(effects_df)
        
        # 正規確率プロット（効果の有意性確認）
        st.markdown("### 📊 効果の正規確率プロット")
        
        effect_values = list(effects.values())
        fig, ax = plt.subplots(figsize=(8, 6))
        stats.probplot(effect_values, dist="norm", plot=ax)
        ax.set_title("効果の正規確率プロット")
        ax.grid(True, alpha=0.3)
        
        # 効果にラベルを追加
        for i, (name, value) in enumerate(effects.items()):
            ax.annotate(name, (stats.norm.ppf((i+0.5)/(len(effect_values)+1)), value),
                       xytext=(5, 5), textcoords='offset points', fontsize=9)
        
        st.pyplot(fig)
        plt.close()
        
        # データダウンロード
        st.markdown("### 💾 データダウンロード")
        csv = df.to_csv(index=False)
        st.download_button(
            label="CSVファイルをダウンロード",
            data=csv,
            file_name="factorial_experiment_data.csv",
            mime="text/csv"
        )
    
    # 最適値の発見方法
    st.markdown("---")
    st.markdown("## 🎯 2^k実験による最適値の発見")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 📊 この手法で見つけた最適値
        
        **🏆 推定最適条件:**
        - **温度:** 高水準（105°C）
        - **時間:** 高水準（75分）  
        - **触媒:** 高水準（0.4 mol/L）
        - **pH:** 高水準（7.5）
        
        **📋 発見方法:**
        1. 2^4 = 16通りの条件組み合わせで実験
        2. 主効果の大きさを比較
        3. 交互作用効果を分析
        4. 正規確率プロットで有意な効果を特定
        """)
    
    with col2:
        st.markdown("""
        ### ⚖️ 2^k実験の利点と限界
        
        **✅ 利点:**
        - 複数因子を同時に調査
        - 交互作用効果を検出
        - 効率的な実験計画
        - 統計的に信頼性の高い結果
        
        **⚠️ 限界:**
        - 2水準のみ（高・低）
        - 非線形効果を見逃す可能性
        - 最適点が水準間にある場合検出困難
        - 因子数が多いと実験数が爆発的に増加
        """)
    
    if 'factorial_data' in st.session_state:
        st.markdown("""
        ### 🤔 この結果をどう解釈するか？
        
        **現在の結果:** 4因子の主効果と交互作用を把握
        - 各因子の影響の大きさを定量化
        - 因子間の相互作用を発見
        - ただし、2水準間の最適点は不明
        
        **発見された重要な知見:**
        - 温度×時間の正の交互作用：両方高めると相乗効果
        - 温度×触媒の負の交互作用：高温時は触媒濃度を調整
        
        **次のステップ:** 
        - 応答曲面法で連続的な最適化
        - 交互作用を考慮した詳細な最適化
        """)
        
        st.info("""
        💡 **理論値との比較**  
        理論最適条件: 温度105°C, 時間60分, 触媒0.3mol/L, pH7.0  
        2^k実験結果: すべて高水準が最適  
        
        ⚠️ **注意:** 2^k実験では設定した水準内でしか最適化できません。
        真の最適点（例：時間60分, 触媒0.3mol/L）が高水準と低水準の間にある場合、
        この手法だけでは発見できません。より細かい最適化が必要です。
        """)
    
    st.warning("""
    🔍 **2^k実験の重要な教訓**  
    この手法は「スクリーニング」に最適です。多くの因子の中から重要なものを特定し、
    交互作用の存在を把握することが主目的です。真の最適点の発見には、
    より精密な手法（応答曲面法など）との組み合わせが必要です。
    """)