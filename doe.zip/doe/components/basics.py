import streamlit as st
import numpy as np
import matplotlib.pyplot as plt

def show_basics():
    st.markdown('<h1 class="section-header">📚 実験計画法の基本</h1>', unsafe_allow_html=True)
    
    # 基本概念
    st.markdown("## 🎯 実験計画法とは")
    st.markdown("""
    <div class="info-box">
    実験計画法（Design of Experiments, DOE）は、効率的で信頼性の高い実験を設計し、
    得られたデータから最大限の情報を抽出するための統計的手法です。
    </div>
    """, unsafe_allow_html=True)
    
    # 基本用語
    st.markdown("## 📖 基本用語")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        **🎯 応答変数（Response Variable）**
        - 実験で測定する目的変数
        - 例：反応収率、強度、時間
        
        **⚙️ 因子（Factor）**
        - 応答に影響を与える可能性のある変数
        - 例：温度、圧力、濃度
        
        **📊 水準（Level）**
        - 因子が取り得る値
        - 例：温度100°C, 150°C, 200°C
        """)
    
    with col2:
        st.markdown("""
        **🔬 処理（Treatment）**
        - 因子の水準の組み合わせ
        - 実験の一つの条件設定
        
        **🔄 反復（Replication）**
        - 同一条件での実験の繰り返し
        - 実験誤差の推定に必要
        
        **🎲 ランダム化（Randomization）**
        - 実験順序の無作為化
        - 系統誤差を防ぐ
        """)
    
    # 実験計画の種類
    st.markdown("## 🏗️ 実験計画の種類")
    
    tab1, tab2, tab3, tab4 = st.tabs(["一因子実験", "多因子実験", "応答曲面法", "その他の計画"])
    
    with tab1:
        st.markdown("""
        ### 🔬 一因子実験（One-Factor Experiment）
        
        **特徴：**
        - 1つの因子のみを変化させる
        - 最も基本的な実験計画
        - 因子の主効果を調べる
        
        **適用例：**
        - 温度が化学反応収率に与える影響
        - 肥料の量が植物の成長に与える影響
        """)
        
        # 一因子実験の図示
        fig, ax = plt.subplots(figsize=(8, 4))
        levels = ['低', '中', '高']
        responses = [20, 35, 45]
        ax.bar(levels, responses, color=['lightblue', 'lightgreen', 'lightcoral'])
        ax.set_xlabel('因子の水準')
        ax.set_ylabel('応答値')
        ax.set_title('一因子実験の例')
        st.pyplot(fig)
        plt.close()
    
    with tab2:
        st.markdown("""
        ### ⚗️ 多因子実験（Multi-Factor Experiment）
        
        **特徴：**
        - 複数の因子を同時に変化させる
        - 因子間の交互作用を調べられる
        - 効率的な実験が可能
        
        **2^k実験：**
        - k個の因子、各2水準
        - 2^k回の実験で完全実施
        """)
        
        # 2因子実験の図示
        fig, ax = plt.subplots(figsize=(8, 6))
        x = np.array([1, 2, 1, 2])
        y = np.array([1, 1, 2, 2])
        responses = np.array([10, 15, 20, 30])
        
        scatter = ax.scatter(x, y, s=responses*10, c=responses, cmap='viridis', alpha=0.7)
        ax.set_xlabel('因子A')
        ax.set_ylabel('因子B')
        ax.set_title('2因子実験の応答')
        ax.set_xticks([1, 2])
        ax.set_xticklabels(['低水準', '高水準'])
        ax.set_yticks([1, 2])
        ax.set_yticklabels(['低水準', '高水準'])
        plt.colorbar(scatter, label='応答値')
        st.pyplot(fig)
        plt.close()
    
    with tab3:
        st.markdown("""
        ### 📈 応答曲面法（Response Surface Methodology）
        
        **特徴：**
        - 因子と応答の関係を曲面で表現
        - 最適条件の探索に有効
        - 2次モデルを使用
        
        **手順：**
        1. スクリーニング実験
        2. 最急上昇法
        3. 応答曲面実験
        4. 最適化
        """)
    
    with tab4:
        st.markdown("""
        ### 🎯 その他の実験計画
        
        **ラテン方格法：**
        - ブロック因子が2つある場合
        - 行と列でブロック化
        
        **分割実験：**
        - 因子の実施の難易度が異なる場合
        - 主区と副区に分割
        
        **直交配列実験：**
        - 多因子実験の部分実施
        - 直交性を保持して実験数を削減
        """)