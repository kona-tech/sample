import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
from utils.common import PROCESS_MODEL

def show_home():
    st.markdown('<h1 class="main-header">🧪 実験計画法学習サイト</h1>', unsafe_allow_html=True)
    
    st.markdown("""
    <div class="info-box">
        <h3>🎯 このサイトについて</h3>
        <p>実験計画法（Design of Experiments, DOE）を対話的に学習できるウェブアプリケーションです。
        理論的な説明とシミュレーション機能を組み合わせて、実践的な理解を深めることができます。</p>
    </div>
    """, unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        ### 📚 学習内容
        - 実験計画法の基本概念
        - 一因子実験の設計と分析
        - 多因子実験（2^k実験）
        - 分散分析（ANOVA）
        - 応答曲面法
        """)
    
    with col2:
        st.markdown("""
        ### 🔧 機能
        - 対話的なシミュレーション
        - リアルタイムグラフ表示
        - パラメータ調整機能
        - 統計的解析結果の表示
        - データのダウンロード機能
        """)
    
    with col3:
        st.markdown("""
        ### 🎓 学習効果
        - 理論と実践の結合
        - 視覚的理解の促進
        - パラメータ変化の影響確認
        - 統計的解釈力の向上
        - 実務への応用準備
        """)
    
    st.markdown("---")
    
    # 共通プロセスモデルの説明
    st.markdown("## 🏭 共通課題：化学反応プロセス最適化")
    st.markdown("""
    <div class="info-box">
    すべての学習モジュールで、統一された化学反応プロセス最適化問題を扱います。
    これにより、異なる実験計画手法が同じエンジニアリング問題にどう適用されるかを理解できます。
    </div>
    """, unsafe_allow_html=True)
    
    # 数式の詳細説明
    with st.expander("🧮 共通プロセスモデルの数式と特性（詳細）"):
        st.markdown("""
        ### 📐 収率計算式（完全版）
        
        ```
        収率(%) = 78 + (-0.008)×(T-105)² + (-0.005)×(t-60)²
                + (-200)×(C-0.3)² + 2×(pH-7)
                + 0.02×(T-105)×(t-60) + (-15)×(T-105)×(C-0.3) + ε
        ```
        
        **各項の説明：**
        - **基準収率：** 78% （すべての因子が最適値の時のベース収率）
        - **温度効果：** -0.008×(T-105)² （105°Cで最大となる上に凸の2次関数）
        - **時間効果：** -0.005×(t-60)² （60分で最大となる上に凸の2次関数）
        - **触媒効果：** -200×(C-0.3)² （0.3mol/Lで最大となる上に凸の2次関数）
        - **pH効果：** 2×(pH-7) （7.0を基準とした1次関数）
        - **温度×時間交互作用：** 0.02×(T-105)×(t-60)
        - **温度×触媒交互作用：** -15×(T-105)×(C-0.3)
        - **実験誤差：** ε ~ N(0, 2²)
        """)
        
        st.markdown("""
        ### 📊 関数の特性と極値
        
        **🎯 理論最適条件：**
        - **温度：** 105°C （2次項の係数が負なので上に凸、最大値を持つ）
        - **時間：** 60分 （2次項の係数が負なので上に凸、最大値を持つ）
        - **触媒濃度：** 0.3 mol/L （2次項の係数が負なので上に凸、最大値を持つ）
        - **pH：** 7.5 （1次項の係数が正なので高い方が良い）
        
        **📈 各因子の感度：**
        1. **触媒濃度** → 最も影響大（最大効果 ±50%）
        2. **温度** → 2番目に影響大（最大効果 ±8%）
        3. **時間** → 3番目に影響（最大効果 ±5%）
        4. **pH** → 最も影響小（最大効果 ±1%）
        
        **🔄 交互作用効果：**
        - **温度×時間：** 正の交互作用（両方高いとさらに収率向上）
        - **温度×触媒：** 負の交互作用（高温時は触媒濃度を下げる方が良い）
        
        **📐 数学的性質：**
        - **関数型：** 多変数2次関数（上に凸関数）
        - **大域最適解：** 1つのみ存在（最大値）
        - **局所最適解：** なし（上に凸関数のため）
        - **実験領域内での最大収率：** 約78%（理論最大値、ノイズにより±4%変動）
        """)
        
        st.markdown("""
        ### 🔬 実験設計上の特徴
        
        **👥 因子の役割分担：**
        - **主効果因子：** 温度、時間、触媒濃度（大きな効果を持つ）
        - **調整因子：** pH（小さいが安定した効果）
        - **交互作用因子：** 温度×時間、温度×触媒（因子間の相互作用）
        
        **🎲 実験誤差の設定：**
        - **分布：** 正規分布 N(0, 2²)
        - **変動係数：** 約3-4%（現実的な実験誤差レベル）
        - **再現性：** 同条件での実験でも±4%程度のばらつき
        
        **🏭 工業的現実性：**
        - 化学反応プロセスの典型的な特性を反映
        - 温度・時間・触媒の最適条件が存在
        - 実際の製造プロセスで観察される交互作用を模擬
        - 現実的な実験誤差レベルを設定
        """)
    
    # グラフによる視覚的説明
    st.markdown("## 📊 共通プロセスモデルの視覚的理解")
    
    # 各因子の効果をグラフで表示
    tab1, tab2, tab3, tab4 = st.tabs(["🌡️ 温度効果", "⏰ 時間効果", "⚗️ 触媒効果", "🔄 交互作用効果"])
    
    with tab1:
        st.markdown("### 温度と収率の関係（他因子を最適値で固定）")
        
        # 温度範囲のデータ生成
        temp_range = np.linspace(90, 120, 100)
        time_opt = 60  # 最適時間
        catalyst_opt = 0.3  # 最適触媒濃度
        ph_opt = 7.0  # 最適pH
        
        yields_temp = []
        for temp in temp_range:
            yield_val = PROCESS_MODEL.yield_function(temp, time_opt, catalyst_opt, ph_opt, 0)  # ノイズなし
            yields_temp.append(yield_val)
        
        # 理論最適値での収率を計算
        theoretical_max_yield = PROCESS_MODEL.yield_function(105, time_opt, catalyst_opt, ph_opt, 0)
        
        fig_temp = plt.figure(figsize=(10, 6))
        plt.plot(temp_range, yields_temp, 'b-', linewidth=2, label='収率')
        plt.axvline(x=105, color='r', linestyle='--', alpha=0.7, label='理論最適温度 (105°C)')
        plt.axhline(y=theoretical_max_yield, color='r', linestyle=':', alpha=0.5, label=f'理論最大収率 ({theoretical_max_yield:.1f}%)')
        plt.xlabel('温度 (°C)')
        plt.ylabel('収率 (%)')
        plt.title('温度効果：2次関数（上に凸）で105°Cに最大値')
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        st.pyplot(fig_temp)
        plt.close()
        
        st.markdown("""
        **📈 観察ポイント：**
        - 105°Cで明確な最大値を持つ上に凸の2次関数
        - 最適温度から離れると収率が急激に低下
        - 実験範囲（95-115°C）内では単峰性
        """)
    
    with tab2:
        st.markdown("### 時間と収率の関係（他因子を最適値で固定）")
        
        # 時間範囲のデータ生成
        time_range = np.linspace(30, 90, 100)
        temp_opt = 105  # 最適温度
        
        yields_time = []
        for time_val in time_range:
            yield_val = PROCESS_MODEL.yield_function(temp_opt, time_val, catalyst_opt, ph_opt, 0)
            yields_time.append(yield_val)
        
        # 理論最適値での収率を計算
        theoretical_max_yield_time = PROCESS_MODEL.yield_function(temp_opt, 60, catalyst_opt, ph_opt, 0)
        
        fig_time = plt.figure(figsize=(10, 6))
        plt.plot(time_range, yields_time, 'g-', linewidth=2, label='収率')
        plt.axvline(x=60, color='r', linestyle='--', alpha=0.7, label='理論最適時間 (60分)')
        plt.axhline(y=theoretical_max_yield_time, color='r', linestyle=':', alpha=0.5, label=f'理論最大収率 ({theoretical_max_yield_time:.1f}%)')
        plt.xlabel('時間 (分)')
        plt.ylabel('収率 (%)')
        plt.title('時間効果：2次関数（上に凸）で60分に最大値')
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        st.pyplot(fig_time)
        plt.close()
        
        st.markdown("""
        **📈 観察ポイント：**
        - 60分で最大値を持つ上に凸の2次関数
        - 時間が短すぎても長すぎても収率低下
        - 温度効果より緩やかな変化
        """)
    
    with tab3:
        st.markdown("### 触媒濃度と収率の関係（他因子を最適値で固定）")
        
        # 触媒濃度範囲のデータ生成（最適値周辺を重点的に）
        catalyst_range = np.linspace(0.15, 0.45, 100)
        
        yields_catalyst = []
        for catalyst_val in catalyst_range:
            yield_val = PROCESS_MODEL.yield_function(temp_opt, time_opt, catalyst_val, ph_opt, 0)
            yields_catalyst.append(yield_val)
        
        # 理論最適値での収率を計算
        theoretical_max_yield_catalyst = PROCESS_MODEL.yield_function(temp_opt, time_opt, 0.3, ph_opt, 0)
        
        fig_catalyst = plt.figure(figsize=(10, 6))
        plt.plot(catalyst_range, yields_catalyst, 'm-', linewidth=2, label='収率')
        plt.axvline(x=0.3, color='r', linestyle='--', alpha=0.7, label='理論最適濃度 (0.3 mol/L)')
        plt.axhline(y=theoretical_max_yield_catalyst, color='r', linestyle=':', alpha=0.5, label=f'理論最大収率 ({theoretical_max_yield_catalyst:.1f}%)')
        plt.xlabel('触媒濃度 (mol/L)')
        plt.ylabel('収率 (%)')
        plt.title('触媒効果：2次関数（上に凸）で0.3 mol/Lに最大値')
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        st.pyplot(fig_catalyst)
        plt.close()
        
        st.markdown("""
        **📈 観察ポイント：**
        - 最も急峻な変化を示す（感度最大）
        - 0.3 mol/Lで明確な最大値を持つ上に凸の2次関数
        - 濃度過多では触媒阻害効果で収率低下
        """)
    
    with tab4:
        st.markdown("### 交互作用効果の3D可視化")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### 温度×時間の交互作用（正の交互作用）")
            
            # 3Dプロット用のデータ生成
            temp_3d = np.linspace(95, 115, 20)
            time_3d = np.linspace(45, 75, 20)
            temp_mesh, time_mesh = np.meshgrid(temp_3d, time_3d)
            
            yield_mesh = np.zeros_like(temp_mesh)
            for i in range(len(temp_3d)):
                for j in range(len(time_3d)):
                    yield_mesh[j, i] = PROCESS_MODEL.yield_function(temp_mesh[j, i], time_mesh[j, i], catalyst_opt, ph_opt, 0)
            
            fig_3d1 = plt.figure(figsize=(10, 8))
            ax1 = fig_3d1.add_subplot(111, projection='3d')
            surf1 = ax1.plot_surface(temp_mesh, time_mesh, yield_mesh, cmap='viridis', alpha=0.8)
            ax1.set_xlabel('温度 (°C)')
            ax1.set_ylabel('時間 (分)')
            ax1.set_zlabel('収率 (%)')
            ax1.set_title('温度×時間の正の交互作用\n（両方高いと相乗効果）')
            fig_3d1.colorbar(surf1)
            st.pyplot(fig_3d1)
            plt.close()
        
        with col2:
            st.markdown("#### 温度×触媒の交互作用（負の交互作用）")
            
            # 温度×触媒の3Dプロット
            catalyst_3d = np.linspace(0.2, 0.4, 20)
            temp_mesh2, catalyst_mesh = np.meshgrid(temp_3d, catalyst_3d)
            
            yield_mesh2 = np.zeros_like(temp_mesh2)
            for i in range(len(temp_3d)):
                for j in range(len(catalyst_3d)):
                    yield_mesh2[j, i] = PROCESS_MODEL.yield_function(temp_mesh2[j, i], time_opt, catalyst_mesh[j, i], ph_opt, 0)
            
            fig_3d2 = plt.figure(figsize=(10, 8))
            ax2 = fig_3d2.add_subplot(111, projection='3d')
            surf2 = ax2.plot_surface(temp_mesh2, catalyst_mesh, yield_mesh2, cmap='plasma', alpha=0.8)
            ax2.set_xlabel('温度 (°C)')
            ax2.set_ylabel('触媒濃度 (mol/L)')
            ax2.set_zlabel('収率 (%)')
            ax2.set_title('温度×触媒の負の交互作用\n（高温時は触媒濃度を下げる）')
            fig_3d2.colorbar(surf2)
            st.pyplot(fig_3d2)
            plt.close()
        
        st.markdown("""
        **🔄 交互作用の特徴：**
        - **正の交互作用（温度×時間）：** 両因子を高水準にすると相乗効果で収率がさらに向上
        - **負の交互作用（温度×触媒）：** 高温時は触媒濃度を下げた方が収率が高くなる
        - これらの交互作用により、単純な主効果だけでは最適化できない複雑な応答曲面が形成される
        """)
    
    # 最適条件での収率分布
    st.markdown("### 🎯 最適条件での収率分布（実験誤差を含む）")
    
    # 理論最適値（ノイズなし）を表示
    theoretical_optimum_yield = PROCESS_MODEL.yield_function(105, 60, 0.3, 7.0, 0)
    st.info(f"""
    🎯 **理論最適条件での収率**  
    温度105°C, 時間60分, 触媒0.3mol/L, pH7.0  
    **理論最大収率: {theoretical_optimum_yield:.1f}%** （実験誤差なし）
    """)
    
    # 最適条件でのシミュレーション（ノイズあり）
    np.random.seed(42)
    n_simulations = 1000
    optimal_yields = []
    
    for _ in range(n_simulations):
        noise = np.random.normal(0, PROCESS_MODEL.yield_params['error_std'])
        yield_val = PROCESS_MODEL.yield_function(105, 60, 0.3, 7.0, noise)
        optimal_yields.append(yield_val)
    
    fig_dist = plt.figure(figsize=(12, 6))
    
    # ヒストグラム
    plt.subplot(1, 2, 1)
    plt.hist(optimal_yields, bins=50, alpha=0.7, color='skyblue', edgecolor='black')
    plt.axvline(x=np.mean(optimal_yields), color='red', linestyle='--', 
                label=f'平均: {np.mean(optimal_yields):.2f}%')
    plt.axvline(x=np.mean(optimal_yields) + 2*np.std(optimal_yields), color='orange', linestyle=':', 
                label=f'+2σ: {np.mean(optimal_yields) + 2*np.std(optimal_yields):.2f}%')
    plt.axvline(x=np.mean(optimal_yields) - 2*np.std(optimal_yields), color='orange', linestyle=':', 
                label=f'-2σ: {np.mean(optimal_yields) - 2*np.std(optimal_yields):.2f}%')
    plt.xlabel('収率 (%)')
    plt.ylabel('頻度')
    plt.title('最適条件での収率分布')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # 累積分布
    plt.subplot(1, 2, 2)
    sorted_yields = np.sort(optimal_yields)
    plt.plot(sorted_yields, np.arange(1, len(sorted_yields) + 1) / len(sorted_yields), 'b-', linewidth=2)
    plt.axvline(x=np.mean(optimal_yields), color='red', linestyle='--', label='平均')
    plt.axhline(y=0.5, color='gray', linestyle=':', alpha=0.5)
    plt.xlabel('収率 (%)')
    plt.ylabel('累積確率')
    plt.title('収率の累積分布関数')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    st.pyplot(fig_dist)
    plt.close()
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("理論最適収率", f"{np.mean(optimal_yields):.2f}%", f"±{2*np.std(optimal_yields):.2f}%")
    with col2:
        st.metric("95%信頼区間", f"{np.percentile(optimal_yields, 2.5):.1f}% - {np.percentile(optimal_yields, 97.5):.1f}%")
    with col3:
        st.metric("変動係数", f"{100*np.std(optimal_yields)/np.mean(optimal_yields):.1f}%")
    
    st.markdown("### 🚀 使い方")
    st.markdown("""
    1. **左側のメニュー**から学習したい項目を選択
    2. **理論説明**を読んで基本概念を理解
    3. **シミュレーション**でパラメータを調整して実験
    4. **結果を解釈**して統計的な理解を深める
    5. **共通課題**で統合的な学習効果を確認
    """)