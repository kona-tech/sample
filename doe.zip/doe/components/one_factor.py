import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
from scipy import stats
from utils.common import PROCESS_MODEL

def show_one_factor():
    st.markdown('<h1 class="section-header">🔬 一因子実験</h1>', unsafe_allow_html=True)
    
    st.markdown("## 📖 一因子実験とは")
    st.markdown("""
    <div class="info-box">
    一因子実験は、1つの因子（独立変数）が応答変数（従属変数）に与える影響を調べる最も基本的な実験計画です。
    因子の異なる水準（レベル）における応答の違いを統計的に検定します。
    </div>
    """, unsafe_allow_html=True)
    
    # 共通課題の説明
    st.markdown("## 🏭 共通課題：化学反応プロセス")
    st.markdown("""
    **目標：** 反応温度が収率に与える影響を調査し、最適な温度範囲を特定する
    
    **実験条件：**
    - 因子：反応温度（80-120°C）
    - 応答：収率（%）
    - その他固定条件：反応時間60分、触媒濃度0.3mol/L、pH7.0
    """)
    
    # 数式の表示
    with st.expander("🧮 使用する数式（共通プロセスモデル）"):
        st.markdown("""
        **収率計算式：**
        ```
        収率 = 60 + 0.8×T + (-0.004)×(T-105)² + 0.3×t + (-0.002)×(t-60)² 
             + 50×C + (-30)×(C-0.3)² + 2×(pH-7) 
             + 0.01×(T-100)×(t-60) + (-10)×(T-100)×(C-0.3) + ε
        ```
        ここで：
        - T: 温度 (°C)
        - t: 時間 (分) = 60 (固定)
        - C: 触媒濃度 (mol/L) = 0.3 (固定)
        - pH = 7.0 (固定)
        - ε: N(0, 2²) の誤差項
        """)
    
    # シミュレーション部分
    st.markdown("## 🎮 一因子実験シミュレーション")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### パラメータ設定")
        
        # 温度水準の設定
        st.markdown("**温度水準の設定:**")
        min_temp = st.number_input("最低温度 (°C)", value=80, min_value=80, max_value=110)
        max_temp = st.number_input("最高温度 (°C)", value=120, min_value=90, max_value=120)
        n_levels = st.slider("水準数", 3, 6, 5)
        
        temperatures = np.linspace(min_temp, max_temp, n_levels)
        st.write("**使用する温度水準:**", [f"{t:.0f}°C" for t in temperatures])
        
        # 各水準のサンプル数
        n_samples = st.slider("各水準のサンプル数", 3, 10, 4)
        
        # ランダムシード
        random_seed = st.number_input("乱数シード", value=42, step=1)
        
        # データ生成
        generate_button = st.button("実験実行", type="primary")
    
    with col2:
        if generate_button or 'one_factor_data' not in st.session_state:
            np.random.seed(int(random_seed))
            
            # 共通モデルを使用してデータ生成
            data = []
            for temp in temperatures:
                for rep in range(n_samples):
                    # 共通プロセスモデルを使用
                    noise = np.random.normal(0, PROCESS_MODEL.yield_params['error_std'])
                    yield_val = PROCESS_MODEL.yield_function(temp, noise=noise)
                    
                    data.append({
                        'Temperature': f"{temp:.0f}°C",
                        'Temperature_Value': temp,
                        'Yield': yield_val,
                        'Replicate': rep + 1
                    })
            
            df = pd.DataFrame(data)
            st.session_state.one_factor_data = df
        
        if 'one_factor_data' in st.session_state:
            df = st.session_state.one_factor_data
            
            # データの表示
            st.markdown("### 📊 実験結果")
            st.dataframe(df)
            
            # 箱ひげ図
            fig_box = px.box(df, x='Temperature', y='Yield', 
                           title='温度水準別収率の分布')
            fig_box.update_layout(height=400)
            st.plotly_chart(fig_box, use_container_width=True)
            
            # 散布図
            fig_scatter = px.strip(df, x='Temperature', y='Yield', 
                                 title='温度と収率の関係')
            fig_scatter.update_layout(height=400)
            st.plotly_chart(fig_scatter, use_container_width=True)
    
    # 統計解析
    if 'one_factor_data' in st.session_state:
        st.markdown("## 📈 統計解析結果")
        
        df = st.session_state.one_factor_data
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 📊 記述統計")
            desc_stats = df.groupby('Temperature')['Yield'].agg(['count', 'mean', 'std', 'min', 'max']).round(3)
            st.dataframe(desc_stats)
        
        with col2:
            st.markdown("### 🔍 一元配置分散分析（ANOVA）")
            
            # ANOVAの実行
            groups = [group['Yield'].values for name, group in df.groupby('Temperature')]
            f_stat, p_value = stats.f_oneway(*groups)
            
            # 効果サイズ（η²）の計算
            grand_mean = df['Yield'].mean()
            ss_between = sum([len(group) * (group.mean() - grand_mean)**2 for group in groups])
            ss_total = sum([(x - grand_mean)**2 for x in df['Yield']])
            eta_squared = ss_between / ss_total
            
            st.write(f"**F統計量:** {f_stat:.4f}")
            st.write(f"**p値:** {p_value:.4f}")
            st.write(f"**効果サイズ (η²):** {eta_squared:.4f}")
            
            if p_value < 0.05:
                st.success("🎉 温度効果は有意です（p < 0.05）")
            else:
                st.info("📝 温度効果は有意ではありません（p ≥ 0.05）")
        
        # 多重比較
        st.markdown("### 🔀 多重比較（Tukey HSD検定）")
        
        if len(set(df['Temperature'])) > 2:
            from scipy.stats import tukey_hsd
            
            try:
                # Tukey HSD検定
                groups_for_tukey = [group['Yield'].values for name, group in df.groupby('Temperature')]
                tukey_result = tukey_hsd(*groups_for_tukey)
                
                # 結果の表示
                temp_names = sorted(df['Temperature'].unique())
                comparison_results = []
                
                for i in range(len(temp_names)):
                    for j in range(i+1, len(temp_names)):
                        comparison_results.append({
                            '比較': f"{temp_names[i]} vs {temp_names[j]}",
                            'p値': tukey_result.pvalue[i, j],
                            '有意差': '有' if tukey_result.pvalue[i, j] < 0.05 else '無'
                        })
                
                comparison_df = pd.DataFrame(comparison_results)
                st.dataframe(comparison_df)
                
            except Exception as e:
                st.warning("多重比較の計算でエラーが発生しました。")
        
        # 最適温度の推定
        st.markdown("### 🎯 最適温度の推定")
        temp_means = df.groupby('Temperature_Value')['Yield'].mean()
        optimal_temp = temp_means.idxmax()
        max_yield = temp_means.max()
        
        st.success(f"**推定最適温度:** {optimal_temp:.0f}°C")
        st.info(f"**期待収率:** {max_yield:.2f}%")
        
        # 理論値との比較
        theoretical_optimum = PROCESS_MODEL.yield_params['temp_center']  # 105°C
        st.write(f"**理論最適温度:** {theoretical_optimum}°C")
        
        # データダウンロード
        st.markdown("### 💾 データダウンロード")
        csv = df.to_csv(index=False)
        st.download_button(
            label="CSVファイルをダウンロード",
            data=csv,
            file_name="one_factor_experiment_data.csv",
            mime="text/csv"
        )
    
    # 最適値の発見方法
    st.markdown("---")
    st.markdown("## 🎯 一因子実験による最適値の発見")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 📊 この手法で見つけた最適値
        
        **🌡️ 推定最適温度:** 105°C  
        **📈 期待収率:** 約78%
        
        **📋 発見方法:**
        1. 複数の温度水準で実験実施
        2. 各水準の平均収率を比較
        3. 最も高い収率を示す水準を特定
        4. ANOVAで統計的有意性を確認
        """)
    
    with col2:
        st.markdown("""
        ### ⚖️ 一因子実験の利点と限界
        
        **✅ 利点:**
        - シンプルで理解しやすい
        - 統計的検定が明確
        - 実施が容易
        
        **⚠️ 限界:**
        - 1つの因子しか調査できない
        - 交互作用を見つけられない
        - 他因子の影響を考慮できない
        - 真の最適値を見逃す可能性
        """)
    
    if 'one_factor_data' in st.session_state:
        st.markdown("""
        ### 🤔 この結果をどう解釈するか？
        
        **現在の結果:** 温度単独での最適化
        - 他の因子（時間、触媒濃度、pH）は固定値
        - 実際の最適条件は他因子との組み合わせで決まる
        
        **次のステップ:** 
        - 多因子実験で因子間の交互作用を調査
        - 応答曲面法で連続的な最適化を実施
        - より包括的な最適化戦略が必要
        """)
        
        # 理論値との比較
        st.info(f"""
        💡 **理論値との比較**  
        理論最適温度: 105°C ← 完全なプロセスモデルから導出  
        実験推定値: {optimal_temp:.0f}°C ← 一因子実験の結果  
        
        この一致は、温度が主要な最適化因子であることを示しています。
        ただし、他因子との相互作用により、実際の最適条件はより複雑です。
        """)