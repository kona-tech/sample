import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
from utils.common import PROCESS_MODEL

def show_exercise4():
    st.markdown('<h1 class="section-header">📋 演習4: ロバスト設計</h1>', unsafe_allow_html=True)
    
    st.markdown("## 🎯 演習の目的")
    st.markdown("""
    <div class="info-box">
    **目的:** ノイズ因子の影響を考慮し、外部環境の変動に対してロバストな操業条件を決定する
    
    **使用する手法:** タグチメソッド（品質工学）によるロバスト設計
    
    **想定シナリオ:** 実際の製造環境では、原料品質、環境条件、装置劣化などの
    ノイズ因子が存在する。これらの影響を最小化する頑健な操業条件を見つける。
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("## 🔧 ロバスト設計の概念")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 🎯 制御因子 vs ノイズ因子
        
        **制御因子（管理可能）:**
        - 反応温度: 95°C ↔ 105°C  
        - 反応時間: 45分 ↔ 75分
        - 触媒濃度: 0.2 ↔ 0.4 mol/L
        
        **ノイズ因子（管理困難）:**
        - 原料純度: 98% ↔ 100%
        - 環境温度: 20°C ↔ 30°C
        - 装置劣化: 新品 ↔ 5年使用
        """)
    
    with col2:
        st.markdown("""
        ### 📊 SN比による評価
        
        **望大特性（収率最大化）:**
        ```
        SN比 = -10×log₁₀(平均(1/y²))
        ```
        
        **目標:**
        - 高い平均性能（収率）
        - 低いばらつき（安定性）
        - ノイズに対する頑健性
        """)
    
    # ロバスト実験の実行
    st.markdown("## 🎮 ロバスト実験の実行")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### 実験設定")
        
        # SN比の種類
        sn_type = st.selectbox("特性の種類", ["望大特性（収率最大化）"])
        
        # 制御因子の組み合わせ数
        st.markdown("**制御因子実験（L4直交配列）:**")
        st.write("- 4つの実験条件")  
        st.write("- 各条件で複数のノイズ条件をテスト")
        
        # ノイズ因子の設定
        n_noise_levels = st.slider("各ノイズ因子の水準数", 2, 3, 2)
        n_replicates = st.slider("各条件の繰り返し数", 2, 4, 3)
        
        random_seed = st.number_input("乱数シード", value=42, step=1)
        
        run_robust = st.button("ロバスト実験実行", type="primary")
    
    with col2:
        if run_robust or 'exercise4_data' not in st.session_state:
            np.random.seed(int(random_seed))
            
            # L4直交配列（3因子、2水準）
            control_matrix = [
                [0, 0, 0],  # 低温度、短時間、低濃度
                [0, 1, 1],  # 低温度、長時間、高濃度  
                [1, 0, 1],  # 高温度、短時間、高濃度
                [1, 1, 0]   # 高温度、長時間、低濃度
            ]
            
            control_levels = {
                'temp': [95, 105],
                'time': [45, 75], 
                'catalyst': [0.2, 0.4]
            }
            
            # ノイズ因子の組み合わせ
            noise_combinations = [
                {'purity': 98, 'env_temp': 20, 'degradation': 0},    # ノイズ小
                {'purity': 100, 'env_temp': 30, 'degradation': 0.1}  # ノイズ大
            ]
            
            data = []
            sn_results = []
            
            for exp_no, control_setting in enumerate(control_matrix):
                temp = control_levels['temp'][control_setting[0]]
                time = control_levels['time'][control_setting[1]]
                catalyst = control_levels['catalyst'][control_setting[2]]
                ph = 7.0  # 固定
                
                # 各ノイズ条件での収率データ収集
                yield_data_per_noise = []
                
                for noise_condition in noise_combinations:
                    for rep in range(n_replicates):
                        # ノイズ因子の影響をシミュレーション
                        purity_factor = noise_condition['purity'] / 100
                        env_temp_factor = 1 + (noise_condition['env_temp'] - 25) * 0.002  
                        degradation_factor = 1 - noise_condition['degradation'] * 0.1
                        
                        # 基本収率計算
                        base_noise = np.random.normal(0, PROCESS_MODEL.yield_params['error_std'])
                        base_yield = PROCESS_MODEL.yield_function(temp, time, catalyst, ph, base_noise)
                        
                        # ノイズ因子の影響を適用
                        final_yield = base_yield * purity_factor * env_temp_factor * degradation_factor
                        final_yield = max(final_yield, 10)  # 最小値制限
                        
                        yield_data_per_noise.append(final_yield)
                        
                        # 詳細データの記録
                        data.append({
                            'Exp_No': exp_no + 1,
                            'Temp': f"{temp}°C",
                            'Time': f"{time}分", 
                            'Catalyst': f"{catalyst}mol/L",
                            'Temp_level': '高' if control_setting[0] == 1 else '低',
                            'Time_level': '高' if control_setting[1] == 1 else '低',
                            'Catalyst_level': '高' if control_setting[2] == 1 else '低',
                            'Noise_Condition': f"Noise_{noise_combinations.index(noise_condition)+1}",
                            'Yield': final_yield,
                            'Replicate': rep + 1
                        })
                
                # SN比の計算（望大特性）
                if sn_type == "望大特性（収率最大化）":
                    sn_ratio = -10 * np.log10(np.mean([1/y**2 for y in yield_data_per_noise]))
                
                mean_yield = np.mean(yield_data_per_noise)
                std_yield = np.std(yield_data_per_noise)
                
                sn_results.append({
                    'Exp_No': exp_no + 1,
                    'Temp_level': '高' if control_setting[0] == 1 else '低',
                    'Time_level': '高' if control_setting[1] == 1 else '低', 
                    'Catalyst_level': '高' if control_setting[2] == 1 else '低',
                    'Mean_Yield': mean_yield,
                    'Std_Yield': std_yield,
                    'SN_Ratio': sn_ratio
                })
            
            df_robust = pd.DataFrame(data)
            df_sn = pd.DataFrame(sn_results)
            
            st.session_state.exercise4_data = df_robust
            st.session_state.exercise4_sn = df_sn
        
        if 'exercise4_data' in st.session_state:
            df_robust = st.session_state.exercise4_data
            df_sn = st.session_state.exercise4_sn
            
            st.markdown("### 📊 実験結果（一部）")
            st.dataframe(df_robust.head(8))
            
            st.markdown("### 📈 SN比分析結果")
            st.dataframe(df_sn.round(3))
    
    # SN比による最適化
    if 'exercise4_sn' in st.session_state:
        df_sn = st.session_state.exercise4_sn
        
        st.markdown("## 📈 SN比による最適化分析")
        
        # 各因子のSN比への効果を計算
        factors = ['Temp_level', 'Time_level', 'Catalyst_level']
        factor_effects_sn = {}
        factor_effects_mean = {}
        
        for factor in factors:
            high_sn = df_sn[df_sn[factor] == '高']['SN_Ratio'].mean()
            low_sn = df_sn[df_sn[factor] == '低']['SN_Ratio'].mean()
            factor_effects_sn[factor] = high_sn - low_sn
            
            high_mean = df_sn[df_sn[factor] == '高']['Mean_Yield'].mean() 
            low_mean = df_sn[df_sn[factor] == '低']['Mean_Yield'].mean()
            factor_effects_mean[factor] = high_mean - low_mean
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 🎯 SN比への因子効果")
            
            effects_sn_df = pd.DataFrame(list(factor_effects_sn.items()), 
                                       columns=['因子', 'SN比効果'])
            effects_sn_df = effects_sn_df.sort_values('SN比効果', ascending=False)
            st.dataframe(effects_sn_df.round(3))
            
            # SN比最適化の推奨設定
            st.markdown("### 🛡️ ロバスト性重視の推奨設定")
            for factor in factors:
                optimal_level = '高' if factor_effects_sn[factor] > 0 else '低'
                st.write(f"**{factor}:** {optimal_level}水準")
        
        with col2:
            st.markdown("### 📊 平均収率への因子効果") 
            
            effects_mean_df = pd.DataFrame(list(factor_effects_mean.items()),
                                         columns=['因子', '平均効果'])
            effects_mean_df = effects_mean_df.sort_values('平均効果', ascending=False)
            st.dataframe(effects_mean_df.round(3))
            
            # 平均最適化の推奨設定
            st.markdown("### 📈 収率重視の推奨設定")
            for factor in factors:
                optimal_level = '高' if factor_effects_mean[factor] > 0 else '低'
                st.write(f"**{factor}:** {optimal_level}水準")
        
        # 効果の比較可視化
        st.markdown("### 📊 効果の比較可視化")
        
        # SN比効果のプロット
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
        
        # SN比効果
        factors_short = ['温度', '時間', '触媒']
        sn_effects = list(factor_effects_sn.values())
        colors_sn = ['red' if e > 0 else 'blue' for e in sn_effects]
        
        ax1.bar(factors_short, sn_effects, color=colors_sn, alpha=0.7)
        ax1.set_ylabel('SN比効果')
        ax1.set_title('各因子のSN比（ロバスト性）への効果')
        ax1.axhline(y=0, color='black', linestyle='-', alpha=0.3)
        ax1.grid(True, alpha=0.3)
        
        # 平均効果
        mean_effects = list(factor_effects_mean.values())
        colors_mean = ['red' if e > 0 else 'blue' for e in mean_effects]
        
        ax2.bar(factors_short, mean_effects, color=colors_mean, alpha=0.7)
        ax2.set_ylabel('平均収率効果 (%)')
        ax2.set_title('各因子の平均収率への効果')
        ax2.axhline(y=0, color='black', linestyle='-', alpha=0.3)
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        st.pyplot(fig)
        plt.close()
        
        # 最終推奨条件の決定
        st.markdown("## 🎯 最終推奨条件の決定")
        
        # SN比が最も高い実験条件を特定
        best_sn_idx = df_sn['SN_Ratio'].idxmax()
        best_sn_condition = df_sn.loc[best_sn_idx]
        
        # 平均収率が最も高い実験条件を特定  
        best_mean_idx = df_sn['Mean_Yield'].idxmax()
        best_mean_condition = df_sn.loc[best_mean_idx]
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### 🛡️ ロバスト性最優先の条件")
            st.success(f"""
            **推奨条件:**
            - **温度:** {best_sn_condition['Temp_level']}水準
            - **時間:** {best_sn_condition['Time_level']}水準  
            - **触媒:** {best_sn_condition['Catalyst_level']}水準
            
            **性能指標:**
            - **SN比:** {best_sn_condition['SN_Ratio']:.2f} dB
            - **平均収率:** {best_sn_condition['Mean_Yield']:.2f}%
            - **標準偏差:** {best_sn_condition['Std_Yield']:.2f}%
            """)
        
        with col2:
            st.markdown("#### 📈 収率最優先の条件")
            st.info(f"""
            **推奨条件:**
            - **温度:** {best_mean_condition['Temp_level']}水準
            - **時間:** {best_mean_condition['Time_level']}水準
            - **触媒:** {best_mean_condition['Catalyst_level']}水準
            
            **性能指標:**
            - **SN比:** {best_mean_condition['SN_Ratio']:.2f} dB
            - **平均収率:** {best_mean_condition['Mean_Yield']:.2f}%
            - **標準偏差:** {best_mean_condition['Std_Yield']:.2f}%
            """)
        
        # トレードオフ分析
        st.markdown("### ⚖️ ロバスト性と平均性能のトレードオフ")
        
        fig_scatter = px.scatter(df_sn, x='Mean_Yield', y='SN_Ratio',
                               hover_data=['Temp_level', 'Time_level', 'Catalyst_level'],
                               title='ロバスト性（SN比）vs 平均性能（収率）')
        fig_scatter.update_layout(
            xaxis_title='平均収率 (%)',
            yaxis_title='SN比 (dB)',
            height=500
        )
        st.plotly_chart(fig_scatter, use_container_width=True)
    
    # 学習ポイント
    st.markdown("---")
    st.markdown("## 📚 学習ポイント")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### ✅ ロバスト設計の価値
        
        **ノイズ因子への対応:**
        - 制御困難な要因の影響を最小化
        - 安定した製品品質の実現
        - 製造コストの削減
        
        **SN比による最適化:**
        - 平均性能とばらつきの同時最適化
        - 客観的なロバスト性評価指標
        - 実用的な品質管理手法
        """)
    
    with col2:
        st.markdown("""
        ### 🏭 実際の製造業での価値
        
        **品質の安定化:**
        - 外的要因による品質ばらつきの抑制
        - クレーム率の低減
        - 顧客満足度の向上
        
        **コスト削減:**
        - 不良品率の低下
        - 工程調整頻度の削減
        - 原材料ロスの最小化
        """)
    
    st.success("""
    🛡️ **ロバスト設計の本質**  
    ロバスト設計は単なる最適化を超えて、「どんな条件下でも安定して良い性能を発揮する」
    条件を見つけることです。これは製造業において、品質の安定性と経済性を両立させる
    極めて実用的なアプローチです。
    """)