import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from sklearn.linear_model import LinearRegression
from utils.common import PROCESS_MODEL

def show_exercise3():
    st.markdown('<h1 class="section-header">📋 演習3: 連続最適化</h1>', unsafe_allow_html=True)
    
    st.markdown("## 🎯 演習の目的")
    st.markdown("""
    <div class="info-box">
    **目的:** 応答曲面法を用いて、連続的な最適化を実行し、真の最適条件を発見する
    
    **使用する手法:** 応答曲面法（RSM）+ 中心複合計画（CCD）
    
    **想定シナリオ:** 演習2で重要と判明した因子について、より精密な最適化を実施し、
    収率を最大化する連続的な最適条件を決定する。
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("## 🔧 応答曲面実験の設計")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 📐 中心複合計画（CCD）
        **対象因子（2因子に焦点）:**
        - **温度 (T)**: 95-115°C
        - **時間 (t)**: 45-75分
        
        **固定因子:**
        - 触媒濃度: 0.3 mol/L
        - pH: 7.0
        
        **実験点構成:**
        - 2²要因点: 4点
        - 軸点: 4点
        - 中心点: 3点（繰り返し）
        """)
        
        # パラメータ設定
        alpha = st.slider("軸点の位置 (α)", 1.0, 2.0, 1.414, 0.1)
        n_center = st.slider("中心点の繰り返し数", 3, 6, 3)
        random_seed = st.number_input("乱数シード", value=42, step=1)
        
        run_rsm = st.button("応答曲面実験実行", type="primary")
    
    with col2:
        if run_rsm or 'exercise3_data' not in st.session_state:
            np.random.seed(int(random_seed))
            
            # CCD実験点の生成
            # コード化変数: x1 = (T - 105)/10, x2 = (t - 60)/15
            design_points = [
                # 2^2要因点
                (-1, -1), (1, -1), (-1, 1), (1, 1),
                # 軸点
                (-alpha, 0), (alpha, 0), (0, -alpha), (0, alpha)
            ] + [(0, 0)] * n_center  # 中心点
            
            data = []
            for i, (x1_coded, x2_coded) in enumerate(design_points):
                # コード化値から実際値への変換
                temp = 105 + 10 * x1_coded  # 温度
                time = 60 + 15 * x2_coded   # 時間
                catalyst = 0.3              # 固定
                ph = 7.0                   # 固定
                
                # 収率計算
                noise = np.random.normal(0, PROCESS_MODEL.yield_params['error_std'])
                yield_val = PROCESS_MODEL.yield_function(temp, time, catalyst, ph, noise)
                
                point_type = "中心点" if (x1_coded == 0 and x2_coded == 0) else \
                           "軸点" if (x1_coded == 0 or x2_coded == 0) and (abs(x1_coded) > 1 or abs(x2_coded) > 1) else \
                           "要因点"
                
                data.append({
                    'Run': i + 1,
                    'Type': point_type,
                    'Temp_coded': x1_coded,
                    'Time_coded': x2_coded,
                    'Temp_actual': temp,
                    'Time_actual': time,
                    'Yield': yield_val
                })
            
            df_rsm = pd.DataFrame(data)
            st.session_state.exercise3_data = df_rsm
        
        if 'exercise3_data' in st.session_state:
            df_rsm = st.session_state.exercise3_data
            
            st.markdown("### 📊 CCD実験データ")
            st.dataframe(df_rsm.round(3))
    
    # 2次回帰モデルの構築
    if 'exercise3_data' in st.session_state:
        df_rsm = st.session_state.exercise3_data
        
        st.markdown("## 📈 2次回帰モデルの構築")
        
        # 回帰用のデータ準備
        X = df_rsm[['Temp_coded', 'Time_coded']].copy()
        X['Temp_squared'] = X['Temp_coded'] ** 2
        X['Time_squared'] = X['Time_coded'] ** 2
        X['Temp_Time'] = X['Temp_coded'] * X['Time_coded']
        X['intercept'] = 1
        
        y = df_rsm['Yield']
        
        # 回帰分析
        model = LinearRegression(fit_intercept=False)
        model.fit(X, y)
        
        # 予測値
        y_pred = model.predict(X)
        r2_score = model.score(X, y)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 🧮 回帰係数")
            coef_names = ['切片', 'T', 't', 'T²', 't²', 'T×t']
            coef_df = pd.DataFrame({
                '項': coef_names,
                '係数': model.coef_
            }).round(4)
            st.dataframe(coef_df)
            
            st.write(f"**決定係数 (R²):** {r2_score:.4f}")
            
            # 2次モデル式の表示
            b0, b1, b2, b11, b22, b12 = model.coef_
            st.markdown(f"""
            **構築されたモデル:**
            ```
            収率 = {b0:.2f} + {b1:.3f}×T + {b2:.3f}×t 
                 + {b11:.3f}×T² + {b22:.3f}×t² + {b12:.3f}×T×t
            ```
            （T, t はコード化変数）
            """)
        
        with col2:
            st.markdown("### 🎯 最適化結果")
            
            # 最適点の計算（解析的解法）
            # ∇f = 0 の連立方程式を解く
            A = np.array([[2*b11, b12], [b12, 2*b22]])
            b_vec = np.array([-b1, -b2])
            
            try:
                optimal_coded = np.linalg.solve(A, b_vec)
                t_opt_coded, time_opt_coded = optimal_coded
                
                # 実際の値に変換
                temp_optimal = 105 + 10 * t_opt_coded
                time_optimal = 60 + 15 * time_opt_coded
                
                # 最適応答値
                yield_optimal = model.coef_[0] + b1*t_opt_coded + b2*time_opt_coded + \
                              b11*t_opt_coded**2 + b22*time_opt_coded**2 + b12*t_opt_coded*time_opt_coded
                
                # 最適点の性質（最大・最小・鞍点）
                hessian = np.array([[2*b11, b12], [b12, 2*b22]])
                eigenvalues = np.linalg.eigvals(hessian)
                
                if all(ev > 0 for ev in eigenvalues):
                    nature = "最小点 ⚠️"
                    color = "error"
                elif all(ev < 0 for ev in eigenvalues):
                    nature = "最大点 🎯"
                    color = "success"
                else:
                    nature = "鞍点 ⚡"
                    color = "warning"
                
                if color == "success":
                    st.success(f"""
                    **最適条件:**
                    - **温度:** {temp_optimal:.1f}°C
                    - **時間:** {time_optimal:.1f}分
                    - **予測収率:** {yield_optimal:.2f}%
                    - **最適点の性質:** {nature}
                    """)
                else:
                    st.warning(f"""
                    **特異点:**
                    - **温度:** {temp_optimal:.1f}°C
                    - **時間:** {time_optimal:.1f}分
                    - **予測収率:** {yield_optimal:.2f}%
                    - **点の性質:** {nature}
                    """)
                
            except np.linalg.LinAlgError:
                st.error("最適点の計算ができませんでした（特異行列）")
        
        # 応答曲面の可視化
        st.markdown("### 🎨 応答曲面の3D可視化")
        
        # 格子点の生成
        temp_coded_range = np.linspace(-2, 2, 30)
        time_coded_range = np.linspace(-2, 2, 30)
        T_grid, Time_grid = np.meshgrid(temp_coded_range, time_coded_range)
        
        # 予測値の計算
        grid_points = np.column_stack([
            T_grid.ravel(),
            Time_grid.ravel(),
            T_grid.ravel()**2,
            Time_grid.ravel()**2,
            T_grid.ravel() * Time_grid.ravel(),
            np.ones(T_grid.size)
        ])
        
        Y_pred_grid = model.predict(grid_points).reshape(T_grid.shape)
        
        # 実際の温度・時間値に変換
        Temp_actual_grid = 105 + 10 * T_grid
        Time_actual_grid = 60 + 15 * Time_grid
        
        # 3D表面プロット
        fig_3d = go.Figure(data=[go.Surface(
            x=Temp_actual_grid, y=Time_actual_grid, z=Y_pred_grid,
            colorscale='Viridis',
            name='予測応答曲面',
            showscale=True
        )])
        
        # 実験点の追加
        fig_3d.add_trace(go.Scatter3d(
            x=df_rsm['Temp_actual'],
            y=df_rsm['Time_actual'],
            z=df_rsm['Yield'],
            mode='markers',
            marker=dict(size=8, color='red'),
            name='実験点'
        ))
        
        # 最適点の追加（計算できた場合）
        try:
            fig_3d.add_trace(go.Scatter3d(
                x=[temp_optimal],
                y=[time_optimal], 
                z=[yield_optimal],
                mode='markers',
                marker=dict(size=12, color='gold', symbol='diamond'),
                name='最適点'
            ))
        except:
            pass
        
        fig_3d.update_layout(
            title='応答曲面（温度 × 時間）',
            scene=dict(
                xaxis_title='温度 (°C)',
                yaxis_title='時間 (分)',
                zaxis_title='収率 (%)'
            ),
            height=600
        )
        
        st.plotly_chart(fig_3d, use_container_width=True)
        
        # 等高線プロット
        st.markdown("### 🗺️ 等高線プロット")
        
        fig_contour = go.Figure(data=go.Contour(
            x=temp_coded_range,
            y=time_coded_range,
            z=Y_pred_grid,
            colorscale='Viridis',
            contours=dict(showlabels=True, labelfont=dict(size=12))
        ))
        
        # 実験点の追加
        fig_contour.add_trace(go.Scatter(
            x=df_rsm['Temp_coded'],
            y=df_rsm['Time_coded'],
            mode='markers',
            marker=dict(size=10, color='red', symbol='circle'),
            name='実験点'
        ))
        
        # 最適点の追加
        try:
            fig_contour.add_trace(go.Scatter(
                x=[t_opt_coded],
                y=[time_opt_coded],
                mode='markers',
                marker=dict(size=15, color='gold', symbol='star'),
                name='最適点'
            ))
        except:
            pass
        
        fig_contour.update_layout(
            title='等高線プロット（コード化変数）',
            xaxis_title='温度（コード化）',
            yaxis_title='時間（コード化）',
            height=500
        )
        
        st.plotly_chart(fig_contour, use_container_width=True)
    
    # 学習ポイント
    st.markdown("---")
    st.markdown("## 📚 学習ポイント")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### ✅ 応答曲面法の特徴
        
        **連続最適化:**
        - 離散的な水準設定から解放
        - 滑らかな応答曲面による最適化
        - 数学的最適化手法の適用可能
        
        **2次モデル:**
        - 非線形関係の近似
        - 交互作用効果の組み込み
        - 曲率効果の表現
        """)
    
    with col2:
        st.markdown("""
        ### 🎯 実用的価値
        
        **精密な最適化:**
        - 連続変数空間での最適探索
        - 最適点周辺の挙動理解
        - 感度分析の実施可能
        
        **工学的応用:**
        - プロセス条件の微調整
        - 品質特性の向上
        - 運転効率の最大化
        """)
    
    st.success("""
    🎯 **応答曲面法の価値**  
    応答曲面法により、離散的な実験点から連続的な最適化が可能となります。
    これは実際の製造プロセスで、運転条件を微調整して性能を最大化する際に、
    極めて実用的なアプローチとなります。
    """)