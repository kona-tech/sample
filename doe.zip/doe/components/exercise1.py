import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
from scipy import stats
from utils.common import PROCESS_MODEL

def show_exercise1():
    st.markdown('<h1 class="section-header">📋 演習1: 初期スクリーニング</h1>', unsafe_allow_html=True)
    
    st.markdown("## 🎯 演習の目的")
    st.markdown("""
    <div class="info-box">
    **目的:** 化学反応プロセスにおいて、収率に最も大きな影響を与える因子を特定する
    
    **使用する手法:** 一因子実験 + 分散分析(ANOVA)
    
    **想定シナリオ:** プロセス開発の初期段階で、4つの制御因子（温度、時間、触媒濃度、pH）の中から
    最も重要な因子を特定し、後続の詳細実験の方向性を決定する。
    </div>
    """, unsafe_allow_html=True)
    
    # 課題設定
    st.markdown("## 📋 課題設定")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 🔬 実験条件
        **制御因子:**
        1. **反応温度:** 80, 90, 100, 110, 120°C
        2. **反応時間:** 30, 45, 60, 75, 90分
        3. **触媒濃度:** 0.1, 0.2, 0.3, 0.4, 0.5 mol/L
        4. **pH:** 6.0, 6.5, 7.0, 7.5, 8.0
        
        **固定条件:**
        - 各水準で4回の繰り返し実験
        - 調査対象外の因子は中央値で固定
        """)
    
    with col2:
        st.markdown("""
        ### 📊 目標
        **主要目標:**
        - 各因子の主効果を定量化
        - 統計的有意性を検定
        - 最も影響の大きい因子を特定
        
        **成功基準:**
        - 収率80%以上を達成可能な因子を発見
        - F検定でp < 0.05の有意差を検出
        """)
    
    # インタラクティブ実験
    st.markdown("## 🎮 一因子実験の実行")
    
    # 因子の選択
    selected_factor = st.selectbox(
        "調査する因子を選択してください:",
        ["反応温度", "反応時間", "触媒濃度", "pH"]
    )
    
    # 因子に応じた設定
    factor_settings = {
        "反応温度": {
            "levels": [80, 90, 100, 110, 120],
            "unit": "°C",
            "fixed": {"time": 60, "catalyst": 0.3, "ph": 7.0}
        },
        "反応時間": {
            "levels": [30, 45, 60, 75, 90],
            "unit": "分",
            "fixed": {"temp": 100, "catalyst": 0.3, "ph": 7.0}
        },
        "触媒濃度": {
            "levels": [0.1, 0.2, 0.3, 0.4, 0.5],
            "unit": "mol/L",
            "fixed": {"temp": 100, "time": 60, "ph": 7.0}
        },
        "pH": {
            "levels": [6.0, 6.5, 7.0, 7.5, 8.0],
            "unit": "",
            "fixed": {"temp": 100, "time": 60, "catalyst": 0.3}
        }
    }
    
    settings = factor_settings[selected_factor]
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### パラメータ設定")
        n_replicates = st.slider("各水準の繰り返し数", 3, 8, 4)
        random_seed = st.number_input("乱数シード", value=42, step=1)
        
        st.markdown(f"### {selected_factor}の水準")
        for level in settings["levels"]:
            st.write(f"- {level}{settings['unit']}")
        
        generate_button = st.button("実験実行", type="primary")
    
    with col2:
        if generate_button or f'exercise1_data_{selected_factor}' not in st.session_state:
            np.random.seed(int(random_seed))
            
            # 実験データの生成
            data = []
            for level in settings["levels"]:
                for rep in range(n_replicates):
                    # パラメータ設定
                    if selected_factor == "反応温度":
                        temp, time, catalyst, ph = level, 60, 0.3, 7.0
                    elif selected_factor == "反応時間":
                        temp, time, catalyst, ph = 100, level, 0.3, 7.0
                    elif selected_factor == "触媒濃度":
                        temp, time, catalyst, ph = 100, 60, level, 7.0
                    else:  # pH
                        temp, time, catalyst, ph = 100, 60, 0.3, level
                    
                    # 収率計算（ノイズ付き）
                    noise = np.random.normal(0, PROCESS_MODEL.yield_params['error_std'])
                    yield_val = PROCESS_MODEL.yield_function(temp, time, catalyst, ph, noise)
                    
                    data.append({
                        'Level': f"{level}{settings['unit']}",
                        'Level_Value': level,
                        'Yield': yield_val,
                        'Replicate': rep + 1
                    })
            
            df_exp1 = pd.DataFrame(data)
            st.session_state[f'exercise1_data_{selected_factor}'] = df_exp1
        
        if f'exercise1_data_{selected_factor}' in st.session_state:
            df_exp1 = st.session_state[f'exercise1_data_{selected_factor}']
            
            # データの表示
            st.markdown("### 📊 実験データ")
            st.dataframe(df_exp1)
            
            # 箱ひげ図
            fig_box = px.box(df_exp1, x='Level', y='Yield', 
                           title=f'{selected_factor}と収率の関係')
            st.plotly_chart(fig_box, use_container_width=True)
    
    # 統計解析
    if f'exercise1_data_{selected_factor}' in st.session_state:
        df_exp1 = st.session_state[f'exercise1_data_{selected_factor}']
        
        st.markdown("## 📈 統計解析結果")
        
        # ANOVA実行
        groups = [group['Yield'].values for name, group in df_exp1.groupby('Level')]
        f_stat, p_value = stats.f_oneway(*groups)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 📊 記述統計")
            desc_stats = df_exp1.groupby('Level')['Yield'].agg([
                'count', 'mean', 'std', 'min', 'max'
            ]).round(3)
            st.dataframe(desc_stats)
        
        with col2:
            st.markdown("### 🔍 分散分析結果")
            st.write(f"**F統計量:** {f_stat:.4f}")
            st.write(f"**p値:** {p_value:.4f}")
            
            if p_value < 0.05:
                st.success("🎉 統計的有意差あり (p < 0.05)")
                st.write("この因子は収率に有意な影響を与えます")
            else:
                st.info("📝 統計的有意差なし (p ≥ 0.05)")
                st.write("この因子の影響は統計的に有意ではありません")
        
        # 最適水準の特定
        st.markdown("### 🎯 最適水準の特定")
        level_means = df_exp1.groupby('Level_Value')['Yield'].mean()
        optimal_level = level_means.idxmax()
        max_yield = level_means.max()
        
        st.success(f"**最適{selected_factor}:** {optimal_level}{settings['unit']}")
        st.info(f"**期待収率:** {max_yield:.2f}%")
        
        # 結果の解釈
        st.markdown("### 🤔 結果の解釈と考察")
        
        if p_value < 0.05:
            st.markdown(f"""
            **統計的結論:**
            - {selected_factor}は収率に統計的に有意な影響を与えている
            - 最適水準は{optimal_level}{settings['unit']}
            - この水準で期待される収率は{max_yield:.1f}%
            
            **工学的考察:**
            - この因子は今後の最適化で重要な制御変数となる
            - 他の因子との交互作用も調査が必要
            - 実用的な運転条件として検討価値が高い
            """)
        else:
            st.markdown(f"""
            **統計的結論:**
            - {selected_factor}は収率への影響が統計的に有意でない
            - 設定した水準範囲では大きな差は見られない
            - 他の因子の影響がより大きい可能性
            
            **工学的考察:**
            - この因子の優先度は他因子より低い
            - より広い範囲での調査が必要かもしれない
            - 経済性を考慮して中央値での運転を推奨
            """)
    
    # 学習ポイント
    st.markdown("---")
    st.markdown("## 📚 学習ポイント")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### ✅ この演習で学んだこと
        
        **一因子実験の特徴:**
        - 1つの因子のみを変化させる基本的な実験
        - 主効果を明確に把握できる
        - 統計的検定により客観的判断が可能
        
        **ANOVAの活用:**
        - F検定による有意性の判定
        - 実験誤差を考慮した統計的推論
        - p値による科学的根拠の提供
        """)
    
    with col2:
        st.markdown("""
        ### 🔄 次のステップ
        
        **この結果を受けて:**
        - 有意な因子を他の演習でさらに詳しく調査
        - 複数因子の同時調査（演習2）
        - 交互作用効果の有無を確認
        
        **実際の現場では:**
        - 複数因子を同時に調査して効率化
        - 経済性も考慮した総合判断
        - 段階的な最適化戦略の立案
        """)
    
    st.warning("""
    ⚠️ **重要な注意事項**  
    一因子実験は基本的な手法ですが、因子間の交互作用は検出できません。
    実際の最適化では、複数因子の同時最適化（多因子実験、応答曲面法など）が必要です。
    """)