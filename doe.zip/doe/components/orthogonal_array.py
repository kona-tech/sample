import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from itertools import product, combinations
import plotly.graph_objects as go
import plotly.express as px
from utils.common import PROCESS_MODEL

def show_orthogonal_array():
    st.markdown('<h1 class="section-header">📊 直交表実験</h1>', unsafe_allow_html=True)
    
    # 基本概念
    st.markdown("## 🎯 直交表とは")
    st.markdown("""
    <div class="info-box">
    直交表（Orthogonal Array）は、多因子実験を効率的に実施するための実験計画法です。
    すべての因子の組み合わせを実験せずに、各因子の主効果を独立して評価できます。
    </div>
    """, unsafe_allow_html=True)
    
    # 基本説明
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 🔍 直交表の特徴
        
        **主な利点:**
        - **実験数削減**: 全組み合わせの一部のみで実験
        - **因子独立性**: 各因子の効果を独立して評価
        - **バランス性**: すべての水準が均等に現れる
        - **解析の簡便性**: 主効果の計算が容易
        
        **適用場面:**
        - スクリーニング実験
        - 多因子の影響調査
        - 品質改善活動
        - 工程最適化
        """)
    
    with col2:
        st.markdown("""
        ### 📋 表記法と構造
        
        **L8(2^7)の例:**
        - **L**: ラテン方格（Latin Square）の略
        - **8**: 実験回数
        - **2**: 各因子の水準数
        - **7**: 最大割り当て可能因子数
        
        **直交性の条件:**
        - 任意の2列で、水準の組み合わせが等頻度
        - 各列で各水準が等回数出現
        - 列間の相関が0
        """)
    
    # 直交表の種類
    st.markdown("## 📊 代表的な直交表")
    
    tab1, tab2, tab3, tab4 = st.tabs(["L4(2^3)", "L8(2^7)", "L9(3^4)", "L16(2^15)"])
    
    with tab1:
        st.markdown("### L4(2^3) 直交表")
        st.markdown("**用途**: 3因子以下、各2水準の実験")
        
        # L4直交表の作成
        l4_array = np.array([
            [1, 1, 1],
            [1, 2, 2],
            [2, 1, 2],
            [2, 2, 1]
        ])
        
        l4_df = pd.DataFrame(l4_array, 
                           columns=['因子A', '因子B', '因子C'],
                           index=[f'実験{i+1}' for i in range(4)])
        
        st.dataframe(l4_df)
        
        # 直交性の確認
        st.markdown("**直交性の確認:**")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("**A×B組み合わせ:**")
            ab_combinations = pd.crosstab(l4_df['因子A'], l4_df['因子B'])
            st.dataframe(ab_combinations)
        
        with col2:
            st.markdown("**A×C組み合わせ:**")
            ac_combinations = pd.crosstab(l4_df['因子A'], l4_df['因子C'])
            st.dataframe(ac_combinations)
        
        with col3:
            st.markdown("**B×C組み合わせ:**")
            bc_combinations = pd.crosstab(l4_df['因子B'], l4_df['因子C'])
            st.dataframe(bc_combinations)
        
        st.success("各組み合わせがすべて1回ずつ現れており、直交性が保たれています。")
    
    with tab2:
        st.markdown("### L8(2^7) 直交表")
        st.markdown("**用途**: 7因子以下、各2水準の実験")
        
        # L8直交表の作成
        l8_array = np.array([
            [1, 1, 1, 1, 1, 1, 1],
            [1, 1, 1, 2, 2, 2, 2],
            [1, 2, 2, 1, 1, 2, 2],
            [1, 2, 2, 2, 2, 1, 1],
            [2, 1, 2, 1, 2, 1, 2],
            [2, 1, 2, 2, 1, 2, 1],
            [2, 2, 1, 1, 2, 2, 1],
            [2, 2, 1, 2, 1, 1, 2]
        ])
        
        l8_df = pd.DataFrame(l8_array,
                           columns=['因子A', '因子B', '因子C', '因子D', '因子E', '因子F', '因子G'],
                           index=[f'実験{i+1}' for i in range(8)])
        
        st.dataframe(l8_df)
        
        # 各因子の水準分布
        fig, ax = plt.subplots(1, 2, figsize=(12, 5))
        
        # 各因子の水準1と水準2の出現回数
        level_counts = []
        factors = l8_df.columns
        for factor in factors:
            level1_count = (l8_df[factor] == 1).sum()
            level2_count = (l8_df[factor] == 2).sum()
            level_counts.append([level1_count, level2_count])
        
        level_counts = np.array(level_counts)
        
        ax[0].bar(range(len(factors)), level_counts[:, 0], alpha=0.7, label='水準1', color='lightblue')
        ax[0].bar(range(len(factors)), level_counts[:, 1], alpha=0.7, label='水準2', color='lightcoral', bottom=level_counts[:, 0])
        ax[0].set_xlabel('因子')
        ax[0].set_ylabel('出現回数')
        ax[0].set_title('各因子の水準別出現回数')
        ax[0].set_xticks(range(len(factors)))
        ax[0].set_xticklabels(factors)
        ax[0].legend()
        ax[0].grid(True, alpha=0.3)
        
        # 相関行列の計算と表示
        correlation_matrix = np.corrcoef(l8_array.T)
        im = ax[1].imshow(correlation_matrix, cmap='RdBu_r', vmin=-1, vmax=1)
        ax[1].set_title('因子間の相関行列')
        ax[1].set_xticks(range(len(factors)))
        ax[1].set_yticks(range(len(factors)))
        ax[1].set_xticklabels(factors)
        ax[1].set_yticklabels(factors)
        
        # 相関係数を表示
        for i in range(len(factors)):
            for j in range(len(factors)):
                text = ax[1].text(j, i, f'{correlation_matrix[i, j]:.2f}',
                                ha="center", va="center", color="black", fontsize=8)
        
        plt.colorbar(im, ax=ax[1])
        plt.tight_layout()
        st.pyplot(fig)
        plt.close()
        
        st.info("対角線以外の相関係数がすべて0であることが直交性を示しています。")
    
    with tab3:
        st.markdown("### L9(3^4) 直交表")
        st.markdown("**用途**: 4因子以下、各3水準の実験")
        
        # L9直交表の作成
        l9_array = np.array([
            [1, 1, 1, 1],
            [1, 2, 2, 2],
            [1, 3, 3, 3],
            [2, 1, 2, 3],
            [2, 2, 3, 1],
            [2, 3, 1, 2],
            [3, 1, 3, 2],
            [3, 2, 1, 3],
            [3, 3, 2, 1]
        ])
        
        l9_df = pd.DataFrame(l9_array,
                           columns=['因子A', '因子B', '因子C', '因子D'],
                           index=[f'実験{i+1}' for i in range(9)])
        
        st.dataframe(l9_df)
        
        # 各水準の出現回数確認
        st.markdown("**各因子の水準別出現回数:**")
        level_summary = pd.DataFrame()
        for factor in l9_df.columns:
            level_counts = l9_df[factor].value_counts().sort_index()
            level_summary[factor] = level_counts
        
        st.dataframe(level_summary)
        st.success("各因子のすべての水準が3回ずつ現れており、バランスが保たれています。")
    
    with tab4:
        st.markdown("### L16(2^15) 直交表")
        st.markdown("**用途**: 15因子以下、各2水準の実験")
        
        # L16直交表の一部を表示（実際には15列すべて作成可能）
        st.markdown("**実験回数**: 16回")
        st.markdown("**最大因子数**: 15因子")
        st.markdown("**各水準の出現回数**: 各因子で水準1が8回、水準2が8回")
        
        # 簡略版の表示（最初の5因子のみ）
        l16_partial = np.array([
            [1, 1, 1, 1, 1],
            [1, 1, 1, 2, 2],
            [1, 1, 2, 1, 2],
            [1, 1, 2, 2, 1],
            [1, 2, 1, 1, 2],
            [1, 2, 1, 2, 1],
            [1, 2, 2, 1, 1],
            [1, 2, 2, 2, 2],
            [2, 1, 1, 1, 2],
            [2, 1, 1, 2, 1],
            [2, 1, 2, 1, 1],
            [2, 1, 2, 2, 2],
            [2, 2, 1, 1, 1],
            [2, 2, 1, 2, 2],
            [2, 2, 2, 1, 2],
            [2, 2, 2, 2, 1]
        ])
        
        l16_df = pd.DataFrame(l16_partial,
                            columns=['因子A', '因子B', '因子C', '因子D', '因子E'],
                            index=[f'実験{i+1}' for i in range(16)])
        
        st.markdown("**L16直交表の一部（最初の5因子）:**")
        st.dataframe(l16_df)
    
    # シミュレーション実験
    st.markdown("## 🧪 直交表を使った実験シミュレーション")
    st.markdown("化学反応プロセスを例に、L8直交表を使った実験を体験してみましょう。")
    
    # 実験条件設定
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### 実験設定")
        
        # 使用する直交表の選択
        array_choice = st.selectbox(
            "使用する直交表",
            ["L4(2^3)", "L8(2^7)", "L9(3^4)"]
        )
        
        # 因子の選択
        if array_choice == "L4(2^3)":
            max_factors = 3
            levels = 2
            experiments = 4
        elif array_choice == "L8(2^7)":
            max_factors = 7
            levels = 2
            experiments = 8
        else:  # L9(3^4)
            max_factors = 4
            levels = 3
            experiments = 9
        
        n_factors = st.slider("実験に使用する因子数", 2, max_factors, min(4, max_factors))
        
        # 因子の水準設定
        factor_settings = {}
        factor_names = ['温度', '時間', '触媒濃度', 'pH', '圧力', '撹拌速度', '濃度'][:n_factors]
        
        for i, factor in enumerate(factor_names):
            st.markdown(f"**{factor}**")
            if levels == 2:
                low = st.number_input(f"{factor}_低水準", value=80.0 if factor=='温度' else 30.0 if factor=='時間' else 0.1 if factor=='触媒濃度' else 6.0, key=f"low_{i}")
                high = st.number_input(f"{factor}_高水準", value=120.0 if factor=='温度' else 90.0 if factor=='時間' else 0.5 if factor=='触媒濃度' else 8.0, key=f"high_{i}")
                factor_settings[factor] = [low, high]
            else:  # 3水準
                low = st.number_input(f"{factor}_低水準", value=80.0 if factor=='温度' else 30.0, key=f"low_{i}")
                mid = st.number_input(f"{factor}_中水準", value=100.0 if factor=='温度' else 60.0, key=f"mid_{i}")
                high = st.number_input(f"{factor}_高水準", value=120.0 if factor=='温度' else 90.0, key=f"high_{i}")
                factor_settings[factor] = [low, mid, high]
    
    with col2:
        st.markdown("### 実験計画")
        
        # 選択された直交表に基づく実験計画の作成
        if array_choice == "L4(2^3)":
            design_matrix = l4_array[:, :n_factors]
        elif array_choice == "L8(2^7)":
            design_matrix = l8_array[:, :n_factors]
        else:  # L9(3^4)
            design_matrix = l9_array[:, :n_factors]
        
        # 実験計画表の作成
        experiment_plan = pd.DataFrame(design_matrix, columns=factor_names)
        
        # 水準を実際の値に変換
        actual_plan = experiment_plan.copy()
        for i, factor in enumerate(factor_names):
            for exp_idx in range(len(experiment_plan)):
                level = experiment_plan.iloc[exp_idx, i]
                actual_plan.iloc[exp_idx, i] = factor_settings[factor][level-1]
        
        st.markdown(f"**{array_choice} 実験計画表:**")
        display_plan = actual_plan.copy()
        display_plan.index = [f'実験{i+1}' for i in range(len(display_plan))]
        st.dataframe(display_plan)
    
    # 実験実行ボタン
    if st.button("🚀 実験実行", type="primary"):
        st.markdown("### 🔬 実験結果")
        
        # シミュレーション実験の実行
        results = []
        np.random.seed(42)
        
        for exp_idx in range(len(actual_plan)):
            # 実験条件の取得
            temp = actual_plan.iloc[exp_idx, 0] if len(factor_names) > 0 else 100
            time = actual_plan.iloc[exp_idx, 1] if len(factor_names) > 1 else 60
            catalyst = actual_plan.iloc[exp_idx, 2] if len(factor_names) > 2 else 0.3
            ph = actual_plan.iloc[exp_idx, 3] if len(factor_names) > 3 else 7.0
            
            # 実験誤差の追加
            noise = np.random.normal(0, PROCESS_MODEL.yield_params['error_std'])
            
            # 収率計算
            yield_result = PROCESS_MODEL.yield_function(temp, time, catalyst, ph, noise)
            results.append(yield_result)
        
        # 結果をデータフレームに格納
        results_df = actual_plan.copy()
        results_df['収率(%)'] = results
        results_df.index = [f'実験{i+1}' for i in range(len(results_df))]
        
        st.dataframe(results_df.round(2))
        
        # 結果の可視化
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # 1. 実験順序vs収率
        axes[0, 0].plot(range(1, len(results)+1), results, 'bo-', markersize=8)
        axes[0, 0].set_xlabel('実験番号')
        axes[0, 0].set_ylabel('収率 (%)')
        axes[0, 0].set_title('実験順序と収率の関係')
        axes[0, 0].grid(True, alpha=0.3)
        axes[0, 0].set_xticks(range(1, len(results)+1))
        
        # 2. 各因子の主効果
        factor_effects = {}
        for i, factor in enumerate(factor_names):
            factor_levels = sorted(actual_plan.iloc[:, i].unique())
            level_means = []
            for level in factor_levels:
                level_results = [results[j] for j in range(len(results)) if actual_plan.iloc[j, i] == level]
                level_means.append(np.mean(level_results))
            factor_effects[factor] = (factor_levels, level_means)
        
        if len(factor_names) >= 1:
            factor = factor_names[0]
            levels, means = factor_effects[factor]
            axes[0, 1].plot(levels, means, 'ro-', markersize=8, linewidth=2)
            axes[0, 1].set_xlabel(f'{factor}')
            axes[0, 1].set_ylabel('平均収率 (%)')
            axes[0, 1].set_title(f'{factor}の主効果')
            axes[0, 1].grid(True, alpha=0.3)
        
        # 3. 要因効果図（すべての因子）
        if len(factor_names) >= 2:
            for i, factor in enumerate(factor_names[:4]):  # 最大4因子まで表示
                levels, means = factor_effects[factor]
                axes[1, 0].plot(range(len(levels)), means, 'o-', markersize=6, label=factor)
            
            axes[1, 0].set_xlabel('水準番号')
            axes[1, 0].set_ylabel('平均収率 (%)')
            axes[1, 0].set_title('各因子の主効果比較')
            axes[1, 0].legend()
            axes[1, 0].grid(True, alpha=0.3)
        
        # 4. 収率のヒストグラム
        axes[1, 1].hist(results, bins=max(3, len(results)//2), alpha=0.7, color='skyblue', edgecolor='black')
        axes[1, 1].axvline(x=np.mean(results), color='red', linestyle='--', linewidth=2, 
                          label=f'平均: {np.mean(results):.2f}%')
        axes[1, 1].set_xlabel('収率 (%)')
        axes[1, 1].set_ylabel('頻度')
        axes[1, 1].set_title('収率の分布')
        axes[1, 1].legend()
        axes[1, 1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        st.pyplot(fig)
        plt.close()
        
        # 統計的分析
        st.markdown("### 📈 統計的分析")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("平均収率", f"{np.mean(results):.2f}%")
            st.metric("標準偏差", f"{np.std(results):.2f}%")
        
        with col2:
            st.metric("最大収率", f"{np.max(results):.2f}%")
            st.metric("最小収率", f"{np.min(results):.2f}%")
        
        with col3:
            st.metric("収率範囲", f"{np.max(results)-np.min(results):.2f}%")
            st.metric("変動係数", f"{100*np.std(results)/np.mean(results):.1f}%")
        
        # 因子効果の定量評価
        st.markdown("### 🔍 因子効果の定量評価")
        
        effects_summary = []
        for factor in factor_names:
            levels, means = factor_effects[factor]
            max_effect = max(means) - min(means)
            effects_summary.append({
                '因子': factor,
                '最大効果': f"{max_effect:.2f}%",
                '最適水準': f"{levels[means.index(max(means))]}",
                '最適時収率': f"{max(means):.2f}%"
            })
        
        effects_df = pd.DataFrame(effects_summary)
        st.dataframe(effects_df)
        
        # 推奨条件の表示
        st.markdown("### 🎯 推奨実験条件")
        
        recommended_conditions = {}
        for factor in factor_names:
            levels, means = factor_effects[factor]
            optimal_level = levels[means.index(max(means))]
            recommended_conditions[factor] = optimal_level
        
        st.info(f"""
        **最適化推奨条件:**  
        {' | '.join([f'{k}: {v}' for k, v in recommended_conditions.items()])}
        
        **予想収率:** {max([max(means) for _, means in factor_effects.values()]):.2f}%
        """)
        
        # CSV ダウンロード
        csv = results_df.to_csv(index=True)
        st.download_button(
            label="📄 実験結果をCSVでダウンロード",
            data=csv,
            file_name=f'{array_choice}_experiment_results.csv',
            mime='text/csv'
        )
    
    # 直交表の利点と限界
    st.markdown("## ⚖️ 直交表の利点と限界")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### ✅ 利点
        
        **効率性:**
        - 実験回数を大幅削減
        - コストと時間の節約
        - 多因子の同時検討が可能
        
        **統計的妥当性:**
        - 直交性により因子効果が独立
        - バランス設計による偏りの除去
        - 主効果の高精度推定
        
        **実用性:**
        - 計算が簡単
        - 結果の解釈が容易
        - 品質管理への応用が豊富
        """)
    
    with col2:
        st.markdown("""
        ### ⚠️ 限界
        
        **交互作用の検出:**
        - 高次の交互作用は検出困難
        - 因子間の相互作用を見落とす可能性
        - 複雑な関係を単純化
        
        **非線形関係:**
        - 2次以上の効果を捉えにくい
        - 最適点が実験範囲外の場合に対応困難
        - 応答曲面の詳細情報が不足
        
        **前提条件:**
        - 加法性の仮定が必要
        - 実験誤差の同分散性を要求
        - 因子の水準設定が重要
        """)
    
    # 実践のポイント
    st.markdown("## 💡 直交表実験の実践ポイント")
    
    with st.expander("🔧 直交表の選択と設計"):
        st.markdown("""
        ### 直交表の選択基準
        
        1. **因子数と水準数の確認**
           - 調査したい因子の数
           - 各因子の適切な水準数
           - 実験回数の制約
        
        2. **直交表の種類**
           - L4, L8, L16: 2水準系直交表
           - L9, L27: 3水準系直交表
           - 混合水準直交表: 異なる水準数の因子を含む
        
        3. **因子の割り付け**
           - 重要因子は相互作用の少ない列に配置
           - 交互作用が予想される因子のペアに注意
           - ダミー因子による交互作用の評価
        """)
    
    with st.expander("📊 データ解析の要点"):
        st.markdown("""
        ### 主効果の計算方法
        
        ```
        因子Aの主効果 = (A高水準の平均応答) - (A低水準の平均応答)
        ```
        
        ### 分散分析（ANOVA）
        1. **全変動の分解**
           - 因子による変動
           - 誤差による変動
        
        2. **F検定による有意性判定**
           - 因子の効果が有意かどうかの判定
           - p値による統計的判断
        
        3. **寄与率の計算**
           - 各因子が全体の変動に占める割合
           - 重要因子の特定
        """)
    
    with st.expander("🎯 結果の解釈と次のステップ"):
        st.markdown("""
        ### 結果の解釈
        
        1. **主効果の評価**
           - 各因子の影響度の比較
           - 最適水準の特定
           - 効果の方向性の確認
        
        2. **有意性の確認**
           - 統計的に有意な因子の特定
           - 実用的に意味のある効果の判定
        
        3. **予測と確認**
           - 最適条件での予測値計算
           - 確認実験の計画
        
        ### 次のステップ
        - **スクリーニング完了後**: 応答曲面法による詳細最適化
        - **交互作用の疑い**: より詳細な要因実験
        - **確認実験**: 推奨条件での実験実施
        """)
    
    st.markdown("### 📚 参考資料")
    st.markdown("""
    - 田口玄一「実験計画法」
    - JIS Z 8815「実験計画法―直交表による実験方法」
    - 品質管理検定（QC検定）関連テキスト
    """)