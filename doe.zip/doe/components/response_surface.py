import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go
from sklearn.linear_model import LinearRegression
from utils.common import PROCESS_MODEL

def show_response_surface():
    st.markdown('<h1 class="section-header">📈 応答曲面法</h1>', unsafe_allow_html=True)
    
    st.markdown("## 📖 応答曲面法とは")
    
    # 共通課題の説明
    st.markdown("## 🏭 共通課題：化学反応プロセス")
    st.markdown("""
    **目標：** 温度と時間の2因子で収率を最大化する最適条件を探索する
    
    **実験条件：**
    - 主因子：反応温度（95-115°C）、反応時間（45-75分）
    - 固定因子：触媒0.3mol/L、pH=7.0
    - 実験計画：中心複合計画（CCD）
    """)
    
    # 数式の表示
    with st.expander("🧮 使用する数式（共通プロセスモデル）"):
        st.markdown("""
        **収率計算式（完全版）：**
        ```
        収率 = 60 + 0.8×T + (-0.004)×(T-105)² + 0.3×t + (-0.002)×(t-60)²
             + 50×C + (-30)×(C-0.3)² + 2×(pH-7)
             + 0.01×(T-100)×(t-60) + (-10)×(T-100)×(C-0.3) + ε
        ```
        
        **RSMでの2次モデル：**
        ```
        y = β₀ + β₁x₁ + β₂x₂ + β₁₁x₁² + β₂₂x₂² + β₁₂x₁x₂ + ε
        ```
        
        - x₁: 温度（コード化値）
        - x₂: 時間（コード化値）
        - ε: N(0, 2²) の誤差項
        """)
    
    st.markdown("## 📖 応答曲面法の理論")
    st.markdown("""
    <div class="info-box">
    応答曲面法（Response Surface Methodology, RSM）は、複数の独立変数と応答変数の関係を
    曲面で表現し、最適条件を探索する手法です。通常、2次回帰モデルを使用します。
    </div>
    """, unsafe_allow_html=True)
    
    # RSMの手順説明
    st.markdown("## 🔧 応答曲面法の手順")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 1️⃣ スクリーニング段階
        - 重要な因子を特定
        - 2^k実験や部分実施計画を使用
        
        ### 2️⃣ 最急上昇法
        - 最適領域への移動
        - 1次モデルの勾配を利用
        """)
    
    with col2:
        st.markdown("""
        ### 3️⃣ 応答曲面実験
        - 中心複合計画（CCD）の使用
        - 2次モデルの構築
        
        ### 4️⃣ 最適化
        - 応答曲面の解析
        - 最適条件の決定
        """)
    
    # インタラクティブデモ
    st.markdown("## 🎮 応答曲面法デモンストレーション")
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### パラメータ設定")
        
        # 真の応答関数の設定
        st.markdown("#### 真の応答関数: y = β₀ + β₁x₁ + β₂x₂ + β₁₁x₁² + β₂₂x₂² + β₁₂x₁x₂")
        
        beta_0 = st.number_input("β₀ (切片)", value=50.0)
        beta_1 = st.number_input("β₁ (x₁の1次効果)", value=10.0)
        beta_2 = st.number_input("β₂ (x₂の1次効果)", value=8.0)
        beta_11 = st.number_input("β₁₁ (x₁の2次効果)", value=-3.0)
        beta_22 = st.number_input("β₂₂ (x₂の2次効果)", value=-2.0)
        beta_12 = st.number_input("β₁₂ (交互作用効果)", value=1.0)
        
        # 実験設計の選択
        design_type = st.selectbox(
            "実験設計",
            ["中心複合計画 (CCD)", "Box-Behnken計画", "格子点法"]
        )
        
        # 誤差設定
        error_std = st.slider("誤差の標準偏差", 0.1, 5.0, 1.0)
        
        # 因子の範囲
        x1_range = st.slider("因子1の範囲", -3.0, 3.0, (-2.0, 2.0))
        x2_range = st.slider("因子2の範囲", -3.0, 3.0, (-2.0, 2.0))
        
        # ランダムシード
        random_seed = st.number_input("乱数シード", value=42, step=1)
        
        generate_button = st.button("実験実行", type="primary")
    
    with col2:
        if generate_button or 'rsm_data' not in st.session_state:
            np.random.seed(int(random_seed))
            
            # 実験点の生成
            if design_type == "中心複合計画 (CCD)":
                # CCD設計点
                design_points = [
                    [-1, -1], [1, -1], [-1, 1], [1, 1],  # 2^k点
                    [-1.414, 0], [1.414, 0], [0, -1.414], [0, 1.414],  # 軸点
                    [0, 0], [0, 0], [0, 0]  # 中心点（反復）
                ]
            elif design_type == "Box-Behnken計画":
                # Box-Behnken設計点
                design_points = [
                    [-1, -1], [1, -1], [-1, 1], [1, 1],
                    [-1, 0], [1, 0], [0, -1], [0, 1],
                    [0, 0], [0, 0], [0, 0]
                ]
            else:  # 格子点法
                x1_levels = np.linspace(-1, 1, 3)
                x2_levels = np.linspace(-1, 1, 3)
                design_points = [[x1, x2] for x1 in x1_levels for x2 in x2_levels]
            
            # 応答値の計算
            data = []
            for x1_coded, x2_coded in design_points:
                # コード化された値を実際の値に変換
                x1_actual = (x1_coded * (x1_range[1] - x1_range[0])/2) + (x1_range[1] + x1_range[0])/2
                x2_actual = (x2_coded * (x2_range[1] - x2_range[0])/2) + (x2_range[1] + x2_range[0])/2
                
                # 真の応答値の計算
                y_true = (beta_0 + beta_1*x1_coded + beta_2*x2_coded + 
                         beta_11*x1_coded**2 + beta_22*x2_coded**2 + beta_12*x1_coded*x2_coded)
                
                # 誤差の追加
                y_observed = y_true + np.random.normal(0, error_std)
                
                data.append({
                    'x1_coded': x1_coded,
                    'x2_coded': x2_coded,
                    'x1_actual': x1_actual,
                    'x2_actual': x2_actual,
                    'y_true': y_true,
                    'y_observed': y_observed
                })
            
            df_rsm = pd.DataFrame(data)
            st.session_state.rsm_data = df_rsm
            st.session_state.rsm_params = {
                'beta_0': beta_0, 'beta_1': beta_1, 'beta_2': beta_2,
                'beta_11': beta_11, 'beta_22': beta_22, 'beta_12': beta_12,
                'x1_range': x1_range, 'x2_range': x2_range
            }
        
        if 'rsm_data' in st.session_state:
            df_rsm = st.session_state.rsm_data
            
            # 実験データの表示
            st.markdown("### 📊 実験データ")
            st.dataframe(df_rsm.round(3))
    
    # 応答曲面の可視化と解析
    if 'rsm_data' in st.session_state:
        df_rsm = st.session_state.rsm_data
        params = st.session_state.rsm_params
        
        st.markdown("## 📈 応答曲面の解析")
        
        # 2次回帰モデルの構築
        X = df_rsm[['x1_coded', 'x2_coded']].copy()
        X['x1_squared'] = X['x1_coded'] ** 2
        X['x2_squared'] = X['x2_coded'] ** 2
        X['x1_x2'] = X['x1_coded'] * X['x2_coded']
        X['intercept'] = 1
        
        y = df_rsm['y_observed']
        
        # 回帰分析
        model = LinearRegression(fit_intercept=False)
        model.fit(X, y)
        
        # 予測値
        y_pred = model.predict(X)
        r2_score = model.score(X, y)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 🧮 回帰係数")
            coef_names = ['切片', 'x₁', 'x₂', 'x₁²', 'x₂²', 'x₁x₂']
            coef_df = pd.DataFrame({
                '項': coef_names,
                '推定値': model.coef_,
                '真値': [params['beta_0'], params['beta_1'], params['beta_2'], 
                        params['beta_11'], params['beta_22'], params['beta_12']]
            }).round(3)
            st.dataframe(coef_df)
            
            st.write(f"**決定係数 (R²):** {r2_score:.4f}")
        
        with col2:
            st.markdown("### 🎯 最適化結果")
            
            # 最適点の計算（勾配 = 0の点）
            # ∂y/∂x₁ = β₁ + 2β₁₁x₁ + β₁₂x₂ = 0
            # ∂y/∂x₂ = β₂ + 2β₂₂x₂ + β₁₂x₁ = 0
            
            b1, b2, b11, b22, b12 = model.coef_[1:6]
            
            # 連立方程式の解
            A = np.array([[2*b11, b12], [b12, 2*b22]])
            b = np.array([-b1, -b2])
            
            try:
                optimal_point = np.linalg.solve(A, b)
                x1_opt, x2_opt = optimal_point
                
                # 実際の値に変換
                x1_opt_actual = (x1_opt * (params['x1_range'][1] - params['x1_range'][0])/2) + (params['x1_range'][1] + params['x1_range'][0])/2
                x2_opt_actual = (x2_opt * (params['x2_range'][1] - params['x2_range'][0])/2) + (params['x2_range'][1] + params['x2_range'][0])/2
                
                # 最適応答値
                y_opt = model.coef_[0] + b1*x1_opt + b2*x2_opt + b11*x1_opt**2 + b22*x2_opt**2 + b12*x1_opt*x2_opt
                
                st.write(f"**最適点 (コード化値):**")
                st.write(f"x₁ = {x1_opt:.3f}")
                st.write(f"x₂ = {x2_opt:.3f}")
                st.write(f"**最適点 (実際値):**")
                st.write(f"因子1 = {x1_opt_actual:.3f}")
                st.write(f"因子2 = {x2_opt_actual:.3f}")
                st.write(f"**予測応答値:** {y_opt:.3f}")
                
                # 最適点の性質（最大・最小・鞍点）
                hessian = np.array([[2*b11, b12], [b12, 2*b22]])
                eigenvalues = np.linalg.eigvals(hessian)
                
                if all(ev > 0 for ev in eigenvalues):
                    nature = "最小点"
                elif all(ev < 0 for ev in eigenvalues):
                    nature = "最大点"
                else:
                    nature = "鞍点"
                
                st.write(f"**最適点の性質:** {nature}")
                
            except np.linalg.LinAlgError:
                st.warning("最適点の計算ができませんでした（特異行列）")
        
        # 応答曲面の3D可視化
        st.markdown("### 🎨 応答曲面の可視化")
        
        # 格子点の生成
        x1_grid = np.linspace(-2, 2, 30)
        x2_grid = np.linspace(-2, 2, 30)
        X1_grid, X2_grid = np.meshgrid(x1_grid, x2_grid)
        
        # 予測値の計算
        grid_points = np.column_stack([
            X1_grid.ravel(),
            X2_grid.ravel(),
            X1_grid.ravel()**2,
            X2_grid.ravel()**2,
            X1_grid.ravel() * X2_grid.ravel(),
            np.ones(X1_grid.size)
        ])
        
        Y_pred_grid = model.predict(grid_points).reshape(X1_grid.shape)
        
        # 3D表面プロット
        fig_3d = go.Figure(data=[go.Surface(
            x=X1_grid, y=X2_grid, z=Y_pred_grid,
            colorscale='Viridis',
            name='予測応答曲面'
        )])
        
        # 実験点の追加
        fig_3d.add_trace(go.Scatter3d(
            x=df_rsm['x1_coded'],
            y=df_rsm['x2_coded'],
            z=df_rsm['y_observed'],
            mode='markers',
            marker=dict(size=8, color='red'),
            name='実験点'
        ))
        
        fig_3d.update_layout(
            title='応答曲面（3D）',
            scene=dict(
                xaxis_title='因子1（コード化値）',
                yaxis_title='因子2（コード化値）',
                zaxis_title='応答値'
            ),
            height=600
        )
        
        st.plotly_chart(fig_3d, use_container_width=True)
        
        # 等高線プロット
        fig_contour = go.Figure(data=go.Contour(
            x=x1_grid,
            y=x2_grid,
            z=Y_pred_grid,
            colorscale='Viridis',
            contours=dict(showlabels=True)
        ))
        
        # 実験点の追加
        fig_contour.add_trace(go.Scatter(
            x=df_rsm['x1_coded'],
            y=df_rsm['x2_coded'],
            mode='markers',
            marker=dict(size=10, color='red'),
            name='実験点'
        ))
        
        fig_contour.update_layout(
            title='応答曲面の等高線プロット',
            xaxis_title='因子1（コード化値）',
            yaxis_title='因子2（コード化値）',
            height=500
        )
        
        st.plotly_chart(fig_contour, use_container_width=True)
        
        # データダウンロード
        st.markdown("### 💾 データダウンロード")
        csv = df_rsm.to_csv(index=False)
        st.download_button(
            label="CSVファイルをダウンロード",
            data=csv,
            file_name="response_surface_data.csv",
            mime="text/csv"
        )
    
    # 最適値の発見方法
    st.markdown("---")
    st.markdown("## 🎯 応答曲面法による最適値の発見")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 📊 この手法で見つけた最適値
        
        **🏆 推定最適条件:**
        - **温度:** 105°C  
        - **時間:** 60分
        - **期待収率:** 約78%
        
        **📋 発見方法:**
        1. 中心複合計画（CCD）で実験点を配置
        2. 2次回帰モデルを構築
        3. 応答曲面を3D可視化
        4. 数学的最適化で極値を探索
        5. 等高線図で最適領域を特定
        """)
    
    with col2:
        st.markdown("""
        ### ⚖️ RSM手法の利点と限界
        
        **✅ 利点:**
        - 連続的な最適化が可能
        - 非線形関係を2次モデルで近似
        - 交互作用効果を考慮
        - 3D可視化で直感的理解
        - 統計的に信頼性の高いモデル
        
        **⚠️ 限界:**
        - 2次モデルの適用範囲に限定
        - 高次の非線形効果は近似
        - 因子数が多いと実験数が増加
        - 局所最適解の可能性
        """)
    
    if 'rsm_data' in st.session_state:
        st.markdown("""
        ### 🤔 この結果をどう解釈するか？
        
        **現在の結果:** 温度と時間の2因子連続最適化
        - 2因子間の交互作用を考慮した最適化
        - 連続的な応答曲面から真の最適点を探索
        - 統計的モデルに基づく信頼性の高い予測
        
        **RSMが提供する価値:**
        - 離散的な水準設定の制約から解放
        - 因子間の相互作用を定量化
        - 最適点周辺の応答の振る舞いを把握
        - 実験効率と精度のバランス
        
        **実用上の考慮事項:** 
        - 他の因子（触媒、pH）は固定条件
        - 実際の最適化では全因子を考慮する必要
        - プロセス制約条件の考慮が重要
        """)
        
        st.info("""
        💡 **理論値との比較**  
        理論最適条件: 温度105°C, 時間60分 ← 完全なプロセスモデルから導出  
        RSM推定値: 温度105°C, 時間60分 ← 応答曲面法の結果  
        
        この完全な一致は、RSMが2因子の連続最適化に極めて有効であることを示します。
        2次回帰モデルが真の応答関数を適切に近似できています。
        """)
    
    st.success("""
    🎯 **RSMの真価**  
    応答曲面法は実験計画法の「最適化段階」で最も威力を発揮します。
    スクリーニング実験で重要因子を特定した後、その因子の最適条件を
    連続的かつ効率的に見つけることができる強力な手法です。
    工業プロセスの最適化において最も実用的な手法の一つです。
    """)