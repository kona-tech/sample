# -*- coding: utf-8 -*-
import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from itertools import combinations, product
import warnings

# 警告を非表示
warnings.filterwarnings('ignore')

# matplotlib の日本語フォント設定
plt.rcParams['font.family'] = ['DejaVu Sans', 'Hiragino Sans', 'Yu Gothic', 'Meiryo', 'Takao', 'IPAexGothic', 'IPAPGothic', 'VL PGothic', 'Noto Sans CJK JP']
plt.rcParams['axes.unicode_minus'] = False

class ChemicalProcessModel:
    """化学反応プロセスの共通モデル"""
    
    def __init__(self):
        # 制御因子の範囲
        self.temp_range = (80, 120)      # 温度 °C
        self.time_range = (30, 90)       # 時間 分
        self.catalyst_range = (0.1, 0.5) # 触媒濃度 mol/L
        self.ph_range = (6.0, 8.0)       # pH
        
        # 基準値（中央値）
        self.temp_center = 100
        self.time_center = 60
        self.catalyst_center = 0.3
        self.ph_center = 7.0
        
        # モデルパラメータ
        self.yield_params = {
            'intercept': 78,  # 最適条件での最大収率を高めに設定
            'temp_coef': 0.0,  # 1次項を0にして純粋な2次関数にする
            'temp_center': 105,
            'temp_quad': -0.008,  # 2次項の係数を大きくしてより明確な凸性を表現
            'time_coef': 0.0,  # 1次項を0にして純粋な2次関数にする
            'time_quad': -0.005,  # 2次項の係数を大きくしてより明確な凸性を表現
            'catalyst_coef': 0.0,  # 1次項を0にして純粋な2次関数にする
            'catalyst_quad': -200,  # 触媒効果をさらに強調して明確な凸性を表現
            'ph_coef': 2,  # pHは1次効果のまま維持
            'interaction_temp_time': 0.02,  # 交互作用を少し強めに
            'interaction_temp_catalyst': -15,  # 負の交互作用を強めに
            'error_std': 2.0
        }
        
        self.purity_params = {
            'intercept': 90,
            'temp_coef': 0.15,
            'temp_quad': -0.001,
            'time_coef': 0.08,
            'time_quad': -0.0005,
            'catalyst_coef': 8,
            'catalyst_quad': -5,
            'ph_coef': 1.5,
            'interaction_temp_time': 0.005,
            'error_std': 1.0
        }
    
    def yield_function(self, temp, time=None, catalyst=None, ph=None, noise=0):
        """収率計算の共通関数"""
        if time is None:
            time = self.time_center
        if catalyst is None:
            catalyst = self.catalyst_center
        if ph is None:
            ph = self.ph_center
        
        p = self.yield_params
        
        yield_val = (p['intercept'] +
                    p['temp_coef'] * temp +
                    p['temp_quad'] * (temp - p['temp_center'])**2 +
                    p['time_coef'] * time +
                    p['time_quad'] * (time - self.time_center)**2 +
                    p['catalyst_coef'] * catalyst +
                    p['catalyst_quad'] * (catalyst - self.catalyst_center)**2 +
                    p['ph_coef'] * (ph - self.ph_center) +
                    p['interaction_temp_time'] * (temp - self.temp_center) * (time - self.time_center) +
                    p['interaction_temp_catalyst'] * (temp - self.temp_center) * (catalyst - self.catalyst_center) +
                    noise)
        
        return max(yield_val, 0)
    
    def purity_function(self, temp, time=None, catalyst=None, ph=None, noise=0):
        """純度計算の共通関数"""
        if time is None:
            time = self.time_center
        if catalyst is None:
            catalyst = self.catalyst_center
        if ph is None:
            ph = self.ph_center
            
        p = self.purity_params
        
        purity_val = (p['intercept'] +
                     p['temp_coef'] * temp +
                     p['temp_quad'] * (temp - self.temp_center)**2 +
                     p['time_coef'] * time +
                     p['time_quad'] * (time - self.time_center)**2 +
                     p['catalyst_coef'] * catalyst +
                     p['catalyst_quad'] * (catalyst - self.catalyst_center)**2 +
                     p['ph_coef'] * (ph - self.ph_center) +
                     p['interaction_temp_time'] * (temp - self.temp_center) * (time - self.time_center) +
                     noise)
        
        return min(max(purity_val, 85), 100)
    
    def add_noise_effect(self, base_value, noise_conditions):
        """ノイズ因子の効果を追加"""
        # 原料純度の影響 (98-100%)
        purity_factor = noise_conditions.get('purity_factor', 1.0)
        
        # 環境温度の影響 (20-30°C)
        env_temp_factor = noise_conditions.get('env_temp_factor', 1.0)
        
        # 装置劣化の影響
        degradation_factor = noise_conditions.get('degradation_factor', 1.0)
        
        return base_value * purity_factor * env_temp_factor * degradation_factor

# グローバルインスタンス
PROCESS_MODEL = ChemicalProcessModel()

def setup_custom_css():
    """カスタムCSSの設定"""
    st.markdown("""
    <style>
        .main-header {
            font-size: 3rem;
            color: #1f77b4;
            text-align: center;
            margin-bottom: 2rem;
        }
        .section-header {
            font-size: 2rem;
            color: #ff7f0e;
            margin-bottom: 1rem;
        }
        .info-box {
            background-color: #f0f2f6;
            padding: 1rem;
            border-radius: 10px;
            margin: 1rem 0;
        }
        .highlight {
            background-color: #fffacd;
            padding: 0.5rem;
            border-radius: 5px;
        }
    </style>
    """, unsafe_allow_html=True)